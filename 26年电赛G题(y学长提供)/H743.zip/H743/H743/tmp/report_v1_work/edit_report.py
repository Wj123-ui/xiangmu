from copy import deepcopy
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt
from docx.table import Table


SOURCE = Path(r"C:\Users\dell\Downloads\报告v1.docx")
OUTPUT = Path(r"C:\Users\dell\Downloads\报告v2_算法与仿真完善版.docx")
ASSETS = Path(__file__).resolve().parent


def clear_paragraph(paragraph):
    p = paragraph._p
    for child in list(p):
        if child.tag != qn("w:pPr"):
            p.remove(child)


def replace_text(paragraph, text, *, bold=False, font_name=None,
                 font_size=None, align=None):
    clear_paragraph(paragraph)
    run = paragraph.add_run(text)
    run.bold = bold
    if font_name:
        run.font.name = font_name
        run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), font_name)
    if font_size:
        run.font.size = Pt(font_size)
    if align is not None:
        paragraph.alignment = align
    return run


def replace_picture(paragraph, path, width_inches):
    clear_paragraph(paragraph)
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.add_run().add_picture(str(path), width=Inches(width_inches))


def insert_paragraph_before(paragraph, text, style="Normal"):
    new_p = paragraph.insert_paragraph_before(text, style=style)
    return new_p


def remove_paragraph(paragraph):
    element = paragraph._element
    element.getparent().remove(element)


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    header = OxmlElement("w:tblHeader")
    header.set(qn("w:val"), "true")
    tr_pr.append(header)


def set_cell_margins(cell, top=70, start=90, bottom=70, end=90):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for edge, value in (("top", top), ("start", start),
                        ("bottom", bottom), ("end", end)):
        tag = tc_mar.find(qn(f"w:{edge}"))
        if tag is None:
            tag = OxmlElement(f"w:{edge}")
            tc_mar.append(tag)
        tag.set(qn("w:w"), str(value))
        tag.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths):
    total = sum(widths)
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.first_child_found_in("w:tblW")
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(total))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.first_child_found_in("w:tblInd")
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "90")
    tbl_ind.set(qn("w:type"), "dxa")
    table.autofit = False

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)

    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.first_child_found_in("w:tcW")
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(widths[idx]))
            tc_w.set(qn("w:type"), "dxa")
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)


def fill_table(table, rows, widths, font_size=8.5):
    while len(table.rows) < len(rows):
        table.add_row()
    while len(table.rows) > len(rows):
        table._tbl.remove(table.rows[-1]._tr)
    for r_idx, values in enumerate(rows):
        for c_idx, value in enumerate(values):
            cell = table.cell(r_idx, c_idx)
            cell.text = value
            for paragraph in cell.paragraphs:
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                paragraph.paragraph_format.space_before = Pt(0)
                paragraph.paragraph_format.space_after = Pt(0)
                paragraph.paragraph_format.line_spacing = 1.0
                for run in paragraph.runs:
                    run.font.name = "宋体"
                    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "宋体")
                    run.font.size = Pt(font_size)
                    if r_idx == 0:
                        run.bold = True
    set_repeat_table_header(table.rows[0])
    set_table_geometry(table, widths)


doc = Document(SOURCE)
p = doc.paragraphs

# Abstract and scheme description.
replace_text(
    p[21],
    "本设计以STM32H743VGT6为主控，实现周期信号高速采集、数字滤波、频谱分析、"
    "基波及最多两组谐波参数检测，并支持单周期、三周期和离散频谱显示。ADC1与ADC2"
    "采用12位双重交错模式，ADC有效时钟24 MHz，合并采样率6 MSPS。每轮DMA采集"
    "16512点，单级89抽头线性相位FIR预热128点后保留16384点进行实数FFT，频点间隔"
    "366.211 Hz；连续完成18轮采集，共分析294912个有效样本。算法结合四项"
    "Blackman-Harris窗、亚频点插值、谐波联合估频和相干统计，并利用赛题500 Hz频率"
    "步进进行带保护校准。最终峰峰值与真有效值由18轮平均后的有效正弦分量和相对相位"
    "统一重构，避免噪声尖峰和带外干扰进入显示结果。USART2负责触摸屏通信，命令9可用"
    "500 kHz标准正弦信号标定增益与偏置，参数经CRC校验写入W25Q64。数值仿真表明，"
    "系统在10~500 kHz有效带内可准确分离基波与谐波，并对1~2.4 MHz干扰保持较强抑制。",
)

replace_text(
    p[44],
    "数字滤波的首要任务是在不削弱10~500 kHz有效基波和谐波的前提下，补充抑制"
    "1~2.4 MHz带外干扰；超过3 MHz后可能发生混叠，仍须由前级硬件抗混叠滤波承担。"
    "由于峰峰值重构依赖谐波间相对相位，软件滤波器还必须保持线性相位。",
)
replace_text(
    p[45],
    "IIR方案运算量较低，但其非线性相位会使不同阶次谐波产生不同群延迟，破坏合成"
    "波形的峰值位置；两级FIR加抽取方案又会增加状态管理和参数耦合，并压缩完整时域"
    "数据。因此两者均不作为最终实现。",
)
replace_text(
    p[46],
    "最终采用全速单级FIR：抽取因子为1，6 MSPS样点全部保留，滤波后直接进入"
    "16384点FFT。相比原513抽头和两级滤波结构，当前89抽头方案显著减少重复滤波与"
    "缓存搬运，乘加量降低82.65%，同时保留谐波检测所需的相位一致性。",
)
replace_text(
    p[47],
    "滤波器使用四项Blackman-Harris窗设计，截止频率800 kHz，群延迟固定为44个采样点。"
    "10~500 kHz内250 mVpp信号的理论幅值误差不超过0.000853 mV；对200 mVpp干扰，"
    "1 MHz处为最坏边界，残留约0.363 mVpp，1.2~2.4 MHz范围内抑制进一步增强。",
)
replace_text(
    p[48],
    "硬件前级首先衰减更高频率成分，软件FIR负责1~2.4 MHz过渡带兜底，两者在"
    "3 MHz奈奎斯特频率之前完成无缝衔接。整体信号链如图1所示。",
)
replace_picture(p[49], ASSETS / "overall_flow.png", 6.15)
replace_text(p[50], "图1  系统信号链与数据处理流程", bold=True,
             align=WD_ALIGN_PARAGRAPH.CENTER)

# Theory section and formulas.
replace_text(p[52], "89抽头线性相位FIR")
replace_text(p[53], "FIR系数由理想低通冲激响应与四项Blackman-Harris窗相乘后归一化：")
replace_text(p[54], "h[n] = h_d[n]w[n] / ∑ₖ₌₀⁸⁸ h_d[k]w[k]",
             font_name="Cambria Math", font_size=12,
             align=WD_ALIGN_PARAGRAPH.CENTER)
replace_text(p[55], "w[n] = a₀ − a₁cos(2πn/88) + a₂cos(4πn/88) − a₃cos(6πn/88)",
             font_name="Cambria Math", font_size=12,
             align=WD_ALIGN_PARAGRAPH.CENTER)
replace_text(p[56], "其中a₀=0.35875、a₁=0.48829、a₂=0.14128、a₃=0.01168。"
                       "89抽头对称FIR的群延迟为：")
replace_text(p[57], "τ_g = (89−1)/2 = 44 samples = 7.333 μs",
             font_name="Cambria Math", font_size=12,
             align=WD_ALIGN_PARAGRAPH.CENTER)
replace_text(p[58], "恒定群延迟只使所有分量整体平移，不改变谐波相对于基波的相位关系，"
                       "因此可直接用于复合波形、峰峰值和真有效值重构。")
replace_picture(p[59], ASSETS / "filter_response.png", 6.05)
replace_text(p[60], "图2  单级89抽头FIR幅频响应", bold=True,
             align=WD_ALIGN_PARAGRAPH.CENTER)
replace_text(p[63], "Δf = 6×10⁶ / 16384 = 366.2109375 Hz",
             font_name="Cambria Math", font_size=12,
             align=WD_ALIGN_PARAGRAPH.CENTER)
replace_text(p[64], "该频点间隔满足题目不大于500 Hz的要求。实数FFT利用偶、奇序列分解"
                       "减少复数运算，其合成关系为：")
replace_text(p[65], "X[k] = E[k] + e^(−j2πk/N)O[k]，N = 16384",
             font_name="Cambria Math", font_size=12,
             align=WD_ALIGN_PARAGRAPH.CENTER)
replace_text(p[66], "Blackman-Harris窗降低谱泄漏，对数抛物线插值给出亚频点估计；18轮"
                       "频率平均后，仅当结果距离赛题规定的500 Hz网格不超过100 Hz时才"
                       "校准到网格点，从而使最终显示频差小于20 Hz，同时不会掩盖异常估计。")
replace_text(p[67], "峰峰值与真有效值重构")
replace_text(p[68], "每轮均对基波及可能的谐波进行同步投影。18轮幅值取算术平均，相位通过"
                       "复数相干平均得到；高次分量还需通过出现次数、信噪比与相干度门限。"
                       "最终只保留基波和最多两组有效谐波，再统一重构一个完整周期。")
replace_text(p[69], "设确认分量的峰值、阶次和相对相位分别为Aᵢ、mᵢ和φᵢ，重构序列为：")
replace_text(p[70], "u[k] = ∑ᵢ₌₁ᴹ Aᵢsin(2πmᵢk/N + φᵢ)，N = 32768",
             font_name="Cambria Math", font_size=12,
             align=WD_ALIGN_PARAGRAPH.CENTER)
replace_text(p[71], "真有效值严格按平方平均的定义计算；峰峰值是完整复合波形的最大值减"
                       "最小值，不等于两倍基波幅值，也不等于各分量幅值的简单相加。")
replace_text(p[72], "U_rms = √[(1/N)∑u²[k]]，V_pp = max(u[k]) − min(u[k])",
             font_name="Cambria Math", font_size=12,
             align=WD_ALIGN_PARAGRAPH.CENTER)

# Hardware and software flow.
replace_text(p[74], "模拟前端与采样接口")
hardware_para = insert_paragraph_before(
    p[75],
    "模拟前端按“前级低通滤波→偏置与增益→ADC输入”连接。前级滤波重点衰减"
    "2.4 MHz以上、尤其3 MHz奈奎斯特频率以上的信号，软件FIR继续抑制1~2.4 MHz"
    "漏入成分。偏置初值取1.65 V，增益建议约6倍；当250 mVpp有效信号与200 mVpp"
    "干扰同相叠加时，输入总峰值为225 mV，ADC端约为0.30~3.00 V，仍保留约300 mV"
    "电源轨余量。最终增益和偏置由命令9实测标定并保存到W25Q64。",
    style="Normal",
)
hardware_para.paragraph_format.first_line_indent = p[26].paragraph_format.first_line_indent
replace_picture(p[76], ASSETS / "program_flow.png", 4.35)
replace_text(p[77], "图3  主程序测量与标定流程", bold=True,
             align=WD_ALIGN_PARAGRAPH.CENTER)

# Test method.
replace_text(p[80], "验证分为四层：")
replace_text(p[81], "1、静态配置检查：核对ADC时钟、交错延迟、DMA打包、MPU、6 MSPS"
                       "采样率、16384点FFT、USART2和参考电压模式；")
replace_text(p[82], "2、MCU同路径仿真：生成不同频率、幅值和相位的正弦叠加信号，经过"
                       "推荐前端模型、12位量化、89抽头FIR、FFT和18轮相干统计，与理论值比较；")
replace_text(p[83], "3、算法与存储检查：验证实数FFT分解、谐波确认、500 Hz网格保护校准、"
                       "W25Q64增益/偏置持久化和HMI帧格式；")
replace_text(p[84], "4、实板阶段性测试：函数发生器驱动PA6，使用ST-Link观察内部状态，"
                       "并由USART2触摸屏或PC读取数值及1024点波形。")
replace_text(p[85], "仿真数据不是直接写入结果变量，而是先换算为推荐模拟前端输出，再量化为"
                       "12位ADC码，写入与真实DMA相同的16512点缓冲区；之后完整执行FIR、"
                       "FFT、18轮统计、Vpp/RMS重构和结果锁存流程。")
replace_text(p[86], "仿真与数值验证结果")
replace_text(p[87], "表1  纯正弦全链路仿真结果", bold=True,
             align=WD_ALIGN_PARAGRAPH.CENTER)

table1_rows = [
    ["输入信号", "原始频差/Hz", "校准后频差/Hz", "峰值误差/mV", "Vpp误差/mV"],
    ["10 kHz，50 mVpp", "1.1616", "0", "0.000354", "0.00122"],
    ["100 kHz，250 mVpp", "0.3891", "0", "0.000641", "0.00089"],
    ["200 kHz，250 mVpp", "0.7629", "0", "0.000879", "0.00086"],
    ["500 kHz，250 mVpp", "1.0681", "0", "0.002965", "0.00985"],
]
table1 = doc.tables[1]
fill_table(table1, table1_rows, [2500, 1650, 1750, 1580, 1580])

heading_after_tables = p[88]
caption2 = insert_paragraph_before(
    heading_after_tables,
    "表2  1.2 MHz、200 mVpp干扰下的谐波分离结果",
    style="表注",
)
caption2.alignment = WD_ALIGN_PARAGRAPH.CENTER
for run in caption2.runs:
    run.bold = True

new_tbl_xml = deepcopy(table1._tbl)
caption2._p.addnext(new_tbl_xml)
table2 = Table(new_tbl_xml, table1._parent)
table2_rows = [
    ["有效分量", "原始频差/Hz", "校准后频差/Hz", "理论峰值/mV", "幅值误差/mV"],
    ["基波 100 kHz", "0.3738", "0", "50", "0.262066"],
    ["二次 200 kHz", "0.7477", "0", "20", "0.280282"],
    ["三次 300 kHz", "1.1292", "0", "10", "0.107618"],
]
fill_table(table2, table2_rows, [2450, 1650, 1750, 1550, 1660])

replace_text(p[88], "典型干扰与谐波分离仿真")
replace_picture(p[89], ASSETS / "simulation_validation.png", 6.05)
replace_text(p[90], "图4  带外干扰条件下的波形恢复与谐波识别", bold=True,
             align=WD_ALIGN_PARAGRAPH.CENTER)
replace_text(
    p[91],
    "典型输入由100 kHz基波、200 kHz二次谐波和300 kHz三次谐波组成，并叠加"
    "1.2 MHz、200 mVpp正弦干扰。经12位量化和89抽头FIR后，三条有效分量的峰值"
    "绝对误差分别为0.262、0.280和0.108 mV；原始估频误差最大1.129 Hz，经带保护"
    "网格校准后最终显示频差为0。干扰不参与Vpp、真有效值和谐波字段的重构。",
)

# Remove three obsolete/redundant figure blocks and use the space for conclusions.
for idx in [97, 96, 95, 94, 93, 92]:
    remove_paragraph(p[idx])
replace_text(p[98], "总结")
replace_text(
    p[99],
    "本设计以6 MSPS双ADC交错采样和16384点FFT为基础，采用单级89抽头线性相位"
    "FIR完成1~2.4 MHz软件抑制，并由硬件前级承担更高频率的抗混叠。相较旧版513"
    "抽头及两级滤波结构，当前方案减少82.65%的FIR乘加量，且不改变10~500 kHz有效"
    "谐波的相对相位。18轮相干平均、最多两组谐波确认、500 Hz网格保护校准以及统一"
    "Vpp/RMS重构，使模拟测试中的分量幅值误差保持在1 mV以内、最终显示频率误差"
    "保持在20 Hz以内。后续实板精度主要取决于前端增益/偏置标定、频响校准和3 MHz"
    "以上抗混叠衰减，串口协议与W25Q64存储流程保持不变。",
)
remove_paragraph(p[100])

# Conservative formatting cleanup for new/modified body content.
for paragraph in doc.paragraphs[19:]:
    if paragraph.style.name == "Normal":
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.line_spacing = 1.25
    for run in paragraph.runs:
        if run.font.name is None and paragraph.style.name != "MTDisplayEquation":
            r_pr = run._element.get_or_add_rPr()
            r_fonts = r_pr.rFonts
            if r_fonts is None:
                r_fonts = OxmlElement("w:rFonts")
                r_pr.insert(0, r_fonts)
            r_fonts.set(qn("w:eastAsia"), "宋体")

doc.save(OUTPUT)
print(OUTPUT)
