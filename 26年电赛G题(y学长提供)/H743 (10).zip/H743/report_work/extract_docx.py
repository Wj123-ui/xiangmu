from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

from docx import Document
from docx.document import Document as DocumentType
from docx.table import Table
from docx.text.paragraph import Paragraph


def iter_blocks(parent):
    element = parent.element.body if isinstance(parent, DocumentType) else parent._tc
    for child in element.iterchildren():
        if child.tag.endswith("}p"):
            yield Paragraph(child, parent)
        elif child.tag.endswith("}tbl"):
            yield Table(child, parent)


def paragraph_images(paragraph: Paragraph) -> list[str]:
    result = []
    for blip in paragraph._p.xpath(".//*[local-name()='blip']"):
        rel_id = blip.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed")
        if rel_id:
            result.append(rel_id)
    return result


def extract(input_path: Path, output_path: Path, media_dir: Path) -> None:
    document = Document(input_path)
    media_dir.mkdir(parents=True, exist_ok=True)
    lines = [f"SOURCE: {input_path}", f"SHA256: {hashlib.sha256(input_path.read_bytes()).hexdigest()}"]
    lines.append(f"SECTIONS: {len(document.sections)}")

    with zipfile.ZipFile(input_path) as archive:
        for name in archive.namelist():
            if name.startswith("word/media/") and not name.endswith("/"):
                target = media_dir / Path(name).name
                target.write_bytes(archive.read(name))

    for index, block in enumerate(iter_blocks(document), start=1):
        if isinstance(block, Paragraph):
            text = block.text.strip()
            images = paragraph_images(block)
            if text or images:
                lines.append(
                    f"P{index:04d} [{block.style.name}] {text}" +
                    (f" [IMAGES:{','.join(images)}]" if images else "")
                )
        else:
            lines.append(f"TABLE{index:04d} rows={len(block.rows)} cols={len(block.columns)}")
            for row in block.rows:
                cells = [" ".join(cell.text.split()) for cell in row.cells]
                lines.append(" | ".join(cells))
            lines.append("ENDTABLE")

    for section_index, section in enumerate(document.sections, start=1):
        header = " ".join(p.text.strip() for p in section.header.paragraphs if p.text.strip())
        footer = " ".join(p.text.strip() for p in section.footer.paragraphs if p.text.strip())
        lines.append(f"SECTION{section_index}_HEADER: {header}")
        lines.append(f"SECTION{section_index}_FOOTER: {footer}")

    summary = {
        "paragraphs": len(document.paragraphs),
        "tables": len(document.tables),
        "sections": len(document.sections),
        "inline_shapes": len(document.inline_shapes),
        "media": sorted(path.name for path in media_dir.iterdir()),
    }
    lines.append("SUMMARY: " + json.dumps(summary, ensure_ascii=False))
    output_path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("media", type=Path)
    args = parser.parse_args()
    extract(args.input, args.output, args.media)


if __name__ == "__main__":
    main()
