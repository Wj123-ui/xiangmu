#include "signal_filter.h"

#include "arm_math.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

/*
 * Two-stage linear-phase low-pass chain:
 *
 *   1. 449-tap FIR at the selected 6.000 or 4.800 MSPS rate with no
 *      sample-rate reduction.  Its 575 kHz midpoint keeps the user-selected
 *      550 kHz measurement boundary flat while placing the dual-rate
 *      worst-case 600 kHz alias in the stopband.
 *
 *   2. The former post-decimation FIR is compiled only when the configured
 *      decimation factor is greater than one.  At 1:1 it is bypassed so it
 *      cannot introduce needless passband loss or computation.
 *
 * Both stages are symmetric FIRs, so their phase delay is linear. Relative
 * harmonic phase, and therefore the reconstructed waveform shape, is
 * preserved. An analog anti-alias filter before PA6 is still mandatory for
 * signals that can alias during the initial 6.000 MSPS ADC acquisition.
 */
#define SIGNAL_FILTER_TWO_PI 6.28318530717958647692f
#define SIGNAL_FILTER_KAISER_BETA 5.65f

static float32_t signal_filter_coefficients[SIGNAL_FILTER_TAP_COUNT];
#if SIGNAL_DECIMATION_FACTOR > 1U
static float32_t signal_post_filter_coefficients[
    SIGNAL_POST_FILTER_TAP_COUNT];
#endif

static arm_fir_decimate_instance_f32 signal_filter_instance;
#if SIGNAL_DECIMATION_FACTOR > 1U
static arm_fir_instance_f32 signal_post_filter_instance;
#endif
static float32_t signal_filter_state[
    SIGNAL_FILTER_TAP_COUNT + SIGNAL_FILTER_MAX_BLOCK_SIZE - 1U];
#if SIGNAL_DECIMATION_FACTOR > 1U
static float32_t signal_post_filter_state[
    SIGNAL_POST_FILTER_TAP_COUNT +
    SIGNAL_FILTER_OUTPUT_BLOCK_SIZE - 1U];
#endif
static float32_t signal_filter_decimated_block[
    SIGNAL_FILTER_OUTPUT_BLOCK_SIZE];
static bool signal_filter_initialized;

static float32_t Signal_Filter_BesselI0(float32_t value)
{
    const float32_t scaled = 0.25f * value * value;
    float32_t term = 1.0f;
    float32_t sum = 1.0f;
    uint32_t order;

    for (order = 1U; order <= 16U; order++)
    {
        const float32_t divisor = (float32_t)(order * order);

        term *= scaled / divisor;
        sum += term;
    }

    return sum;
}

static void Signal_Filter_GenerateLowPass(float32_t *coefficients,
                                          uint32_t tap_count,
                                          float cutoff_hz,
                                          float sample_rate_hz)
{
    const uint32_t last_index = tap_count - 1U;
    const uint32_t center_index = last_index / 2U;
    const float normalized_cutoff =
        cutoff_hz / sample_rate_hz;
    const float kaiser_denominator =
        Signal_Filter_BesselI0(SIGNAL_FILTER_KAISER_BETA);
    float coefficient_sum = 0.0f;
    uint32_t index;

    for (index = 0U; index < tap_count; index++)
    {
        const float offset =
            (float)((int32_t)index - (int32_t)center_index);
        const float normalized_position =
            2.0f * (float)index / (float)last_index - 1.0f;
        const float window_argument =
            SIGNAL_FILTER_KAISER_BETA *
            sqrtf(fmaxf(0.0f,
                        1.0f -
                        normalized_position * normalized_position));
        const float window =
            Signal_Filter_BesselI0(window_argument) /
            kaiser_denominator;
        float ideal_response;

        if (index == center_index)
        {
            ideal_response = 2.0f * normalized_cutoff;
        }
        else
        {
            ideal_response =
                sinf(SIGNAL_FILTER_TWO_PI *
                     normalized_cutoff * offset) /
                ((SIGNAL_FILTER_TWO_PI * 0.5f) * offset);
        }

        coefficients[index] = ideal_response * window;
        coefficient_sum += coefficients[index];
    }

    for (index = 0U; index < tap_count; index++)
    {
        coefficients[index] /= coefficient_sum;
    }
}

bool Signal_Filter_Init(void)
{
    return Signal_Filter_InitForSampleRate(
        SIGNAL_FILTER_SAMPLE_RATE_HZ);
}

bool Signal_Filter_InitForSampleRate(float sample_rate_hz)
{
    if ((!isfinite(sample_rate_hz)) ||
        (sample_rate_hz <= (2.0f * SIGNAL_FILTER_CUTOFF_HZ)))
    {
        signal_filter_initialized = false;
        return false;
    }

    Signal_Filter_GenerateLowPass(signal_filter_coefficients,
                                  SIGNAL_FILTER_TAP_COUNT,
                                  SIGNAL_FILTER_CUTOFF_HZ,
                                  sample_rate_hz);
    if (arm_fir_decimate_init_f32(
            &signal_filter_instance,
            SIGNAL_FILTER_TAP_COUNT,
            SIGNAL_DECIMATION_FACTOR,
            signal_filter_coefficients,
            signal_filter_state,
            SIGNAL_FILTER_MAX_BLOCK_SIZE) != ARM_MATH_SUCCESS)
    {
        signal_filter_initialized = false;
        return false;
    }

#if SIGNAL_DECIMATION_FACTOR > 1U
    Signal_Filter_GenerateLowPass(signal_post_filter_coefficients,
                                  SIGNAL_POST_FILTER_TAP_COUNT,
                                  SIGNAL_POST_FILTER_CUTOFF_HZ,
                                  sample_rate_hz /
                                      (float)SIGNAL_DECIMATION_FACTOR);
    arm_fir_init_f32(&signal_post_filter_instance,
                     SIGNAL_POST_FILTER_TAP_COUNT,
                     signal_post_filter_coefficients,
                     signal_post_filter_state,
                     SIGNAL_FILTER_OUTPUT_BLOCK_SIZE);
#endif

    signal_filter_initialized = true;
    return true;
}

void Signal_Filter_Reset(void)
{
    memset(signal_filter_state, 0, sizeof(signal_filter_state));
#if SIGNAL_DECIMATION_FACTOR > 1U
    memset(signal_post_filter_state,
           0,
           sizeof(signal_post_filter_state));
#endif
}

bool Signal_Filter_ProcessDecimate(const float *input,
                                   float *output,
                                   uint32_t input_sample_count)
{
    if ((!signal_filter_initialized) ||
        (input == NULL) ||
        (output == NULL) ||
        (input_sample_count == 0U) ||
        (input_sample_count > SIGNAL_FILTER_MAX_BLOCK_SIZE) ||
        ((input_sample_count % SIGNAL_DECIMATION_FACTOR) != 0U))
    {
        return false;
    }

    arm_fir_decimate_f32(&signal_filter_instance,
                         input,
                         signal_filter_decimated_block,
                         input_sample_count);
#if SIGNAL_DECIMATION_FACTOR > 1U
    arm_fir_f32(&signal_post_filter_instance,
                signal_filter_decimated_block,
                output,
                input_sample_count / SIGNAL_DECIMATION_FACTOR);
#else
    memcpy(output,
           signal_filter_decimated_block,
           input_sample_count * sizeof(*output));
#endif
    return true;
}

float Signal_Filter_AdcToFloat(const uint16_t *adc_samples,
                               float *output,
                               uint32_t sample_count,
                               float units_per_adc_code)
{
    float mean_code = 0.0f;
    uint32_t index;

    if ((adc_samples == NULL) ||
        (output == NULL) ||
        (sample_count == 0U))
    {
        return 0.0f;
    }

    for (index = 0U; index < sample_count; index++)
    {
        mean_code += (float)adc_samples[index];
    }

    mean_code /= (float)sample_count;

    for (index = 0U; index < sample_count; index++)
    {
        output[index] =
            ((float)adc_samples[index] - mean_code) * units_per_adc_code;
    }

    return mean_code;
}

float Signal_Filter_RemoveDc(float *samples, uint32_t sample_count)
{
    float mean = 0.0f;
    uint32_t index;

    if ((samples == NULL) || (sample_count == 0U))
    {
        return 0.0f;
    }

    for (index = 0U; index < sample_count; index++)
    {
        mean += samples[index];
    }

    mean /= (float)sample_count;

    for (index = 0U; index < sample_count; index++)
    {
        samples[index] -= mean;
    }

    return mean;
}

float Signal_Filter_CalculateRms(const float *samples,
                                 uint32_t sample_count)
{
    float sum_of_squares = 0.0f;
    uint32_t index;

    if ((samples == NULL) || (sample_count == 0U))
    {
        return 0.0f;
    }

    for (index = 0U; index < sample_count; index++)
    {
        sum_of_squares += samples[index] * samples[index];
    }

    return sqrtf(sum_of_squares / (float)sample_count);
}
