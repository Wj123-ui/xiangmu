# FFT and LPF usage

The module is independent of HAL, DMA, UART, and the display driver. The
application passes a completed ADC block to the analyzer and consumes the
returned arrays.

## Files

- `lpf.h`: streaming 2/4/6/8-order Butterworth low-pass API.
- `lpf.c`: CMSIS-DSP biquad implementation.
- `fft.h`: public configuration, context, result, and API.
- `fft.c`: conversion, filtering, FFT, measurements, peak
  extraction, and display-array generation.

These files are deliberately kept in the workspace root and are not bound to
one generated STM32Cube project. Add both `.c` files to the target project,
add this directory and the CMSIS-DSP `Include` directory to the compiler
include paths, define `ARM_MATH_CM7`, and link
`libarm_cortexM7lfdp_math.a` for the STM32H743 hard-float build.

## Static allocation

Both objects contain large work arrays and must not be local variables on the
main stack:

```c
#include "fft.h"

static FFT_Handle fft;
static FFT_Result fft_result;
static uint16_t adc_dma_buffer[4096];
```

## Initialization

```c
FFT_Config config;

config = FFT_DefaultConfig(2048000.0f);

/*
 * Example only. Replace this with a calibrated input-referred scale:
 *
 * ADC volts/count = ADC reference / ADC full scale / analog voltage gain
 */
config.adc_zero_code = 2047.5f;
config.adc_volts_per_count = (3.3f / 4095.0f) / FRONT_END_GAIN;

/* Set 200000.0f for the u_a task or 500000.0f for the u_b task. */
config.analysis_max_frequency_hz = 500000.0f;

if (FFT_Init(&fft, &config) != FFT_OK)
{
  Error_Handler();
}
```

The default configuration uses:

- sample rate: supplied by the caller;
- FFT size: 4096;
- FFT bin width at 2.048 MSPS: 500 Hz;
- low-pass: eighth-order Butterworth, 650 kHz cutoff;
- analysis band: 10-500 kHz;
- waveform display arrays: 800 points;
- spectrum display array: 800 max-pooled points.

The analog front end still needs an anti-alias low-pass filter. A digital
filter cannot remove an interferer after it has aliased into 0-500 kHz.

## Processing a DMA block

Call the analyzer outside the ADC interrupt. The callback should only mark a
buffer ready or swap a ping-pong buffer.

```c
if (adc_block_ready != 0U)
{
  adc_block_ready = 0U;

  /*
   * On STM32H743, invalidate the D-cache for a cacheable DMA destination
   * before the CPU reads it, or place the DMA buffer in non-cacheable RAM.
   */
  FFT_Status status =
      FFT_ProcessADC(&fft, adc_dma_buffer, 4096U, &fft_result);

  if (status == FFT_OK)
  {
    float fundamental_hz = fft_result.fundamental_hz;
    float vpp_v = fft_result.peak_to_peak_v;
    float true_rms_v = fft_result.true_rms_v;
  }
}
```

The low-pass state is retained across calls, so sequential DMA blocks form a
continuous stream. Call `FFT_ResetFilter()` after a sampling gap
or after changing the input path. Ignore the first filtered block after a
reset if filter startup transients matter to the measurement.

## Output arrays

```c
/* Full filtered time record: fft_size samples at sample_period_s spacing. */
fft_result.waveform_v;

/* Exactly one period, phase aligned, ready to plot from left to right. */
fft_result.one_cycle_v;
fft_result.waveform_display_count;

/* Exactly three periods, using the same horizontal point count. */
fft_result.three_cycle_v;

/* Full one-sided peak-amplitude spectrum. */
fft_result.spectrum_frequency_hz;
fft_result.spectrum_amplitude_v;
fft_result.spectrum_bin_count;

/* Screen-width spectrum with max pooling so narrow lines are not lost. */
fft_result.spectrum_display_frequency_hz;
fft_result.spectrum_display_amplitude_v;
fft_result.spectrum_display_count;

/* Peaks are sorted by frequency. The first peak is the fundamental. */
fft_result.peaks;
fft_result.peak_count;
```

Each `FFT_Peak` provides:

- `frequency_hz`;
- `amplitude_v` as sine peak amplitude, matching `U1`, `U3`, and `U4` in the
  problem statement;
- `phase_rad`;
- the FFT `bin_index` and interpolated `bin_offset`.

## Direct floating-point input

Tests, an external ADC driver, or another calibrated acquisition layer can
bypass ADC-code conversion:

```c
FFT_Process(&fft, input_volts, 4096U, &fft_result);
```

## Standalone low-pass usage

```c
static LPF_Handle lpf;

LPF_Init(&lpf, 2048000.0f, 650000.0f, 8U);
LPF_Process(&lpf, input, output, sample_count);
```

Input and output may be the same array. Filter coefficients are generated at
runtime, so the same API can be reused at another sampling rate or cutoff.
