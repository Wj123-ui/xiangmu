#include "signal_fft.h"

#include "arm_math.h"

#include <float.h>
#include <math.h>
#include <stddef.h>
#include <string.h>

#define SIGNAL_FFT_TWO_PI 6.28318530717958647692f
#define SIGNAL_FFT_RELATIVE_PEAK_FLOOR 1.0e-4f
#define SIGNAL_FFT_RECONSTRUCTION_POINTS SIGNAL_FFT_SIZE
#define SIGNAL_FFT_HALF_SIZE (SIGNAL_FFT_SIZE / 2U)
#define SIGNAL_FFT_QUARTER_SIZE (SIGNAL_FFT_SIZE / 4U)
#define SIGNAL_FFT_HARMONIC_TOLERANCE_BINS 2.0f
#define SIGNAL_FFT_HARMONIC_RELATIVE_TOLERANCE 0.0025f
#define SIGNAL_FFT_MAX_FIT_PARAMETERS \
    (1U + (2U * SIGNAL_FFT_MAX_PEAKS))

#if defined(__GNUC__)
#define SIGNAL_FFT_CCMRAM \
    __attribute__((section(".ccmram"), aligned(4)))
#else
#define SIGNAL_FFT_CCMRAM
#endif

/*
 * The supplied CMSIS-DSP library has real-FFT tables only through 4096
 * points, but it has a 4096-point complex FFT.  An 8192-point real FFT is
 * therefore formed by packing x[2n]+j*x[2n+1] and unpacking its complex
 * spectrum.  The final 16384-point transform computes this 8192-point real
 * FFT for the even and odd input subsequences and combines them with the
 * radix-2 identity X[k] = E[k] + exp(-j*2*pi*k/N) O[k].
 */
extern const arm_cfft_instance_f32 arm_cfft_sR_f32_len4096;

static signal_fft_config_t signal_fft_config;

static float32_t signal_fft_time_data[SIGNAL_FFT_SIZE]
    SIGNAL_FFT_CCMRAM;
static float32_t signal_fft_output[SIGNAL_FFT_SIZE]
    SIGNAL_FFT_CCMRAM;
static float32_t signal_fft_window[SIGNAL_FFT_SIZE]
    SIGNAL_FFT_CCMRAM;
static float32_t signal_fft_magnitude[SIGNAL_FFT_SPECTRUM_BIN_COUNT]
    SIGNAL_FFT_CCMRAM;

static float signal_fft_window_sum;
static float signal_fft_window_energy;
static bool signal_fft_initialized;
static bool signal_fft_spectrum_valid;

static void Signal_FFT_TransformReal8192(float32_t *packed_input,
                                         float32_t *spectrum_output)
{
    const float angular_step =
        SIGNAL_FFT_TWO_PI / (float)SIGNAL_FFT_HALF_SIZE;
    const float step_sine = sinf(angular_step);
    const float step_cosine = cosf(angular_step);
    float twiddle_sine = step_sine;
    float twiddle_cosine = step_cosine;
    uint32_t bin;

    /* packed_input is initially 4096 packed complex input samples. */
    arm_cfft_f32(&arm_cfft_sR_f32_len4096,
                 packed_input,
                 0U,
                 1U);

    /* DC and Nyquist are both represented by complex bin zero. */
    spectrum_output[0] = packed_input[0] + packed_input[1];
    spectrum_output[1] = packed_input[0] - packed_input[1];

    for (bin = 1U; bin < SIGNAL_FFT_QUARTER_SIZE; bin++)
    {
        const uint32_t mirror_bin =
            SIGNAL_FFT_QUARTER_SIZE - bin;
        const float a_real = packed_input[2U * bin];
        const float a_imaginary = packed_input[2U * bin + 1U];
        const float b_real = packed_input[2U * mirror_bin];
        const float b_imaginary =
            -packed_input[2U * mirror_bin + 1U];
        const float sum_real = a_real + b_real;
        const float sum_imaginary = a_imaginary + b_imaginary;
        const float difference_real = a_real - b_real;
        const float difference_imaginary =
            a_imaginary - b_imaginary;
        const float rotated_real =
            twiddle_cosine * difference_real +
            twiddle_sine * difference_imaginary;
        const float rotated_imaginary =
            twiddle_cosine * difference_imaginary -
            twiddle_sine * difference_real;
        float next_twiddle_sine;

        /* X[k] = 0.5 * ((A+B) - j*W(k)*(A-B)). */
        spectrum_output[2U * bin] =
            0.5f * (sum_real + rotated_imaginary);
        spectrum_output[2U * bin + 1U] =
            0.5f * (sum_imaginary - rotated_real);

        next_twiddle_sine =
            twiddle_sine * step_cosine +
            twiddle_cosine * step_sine;
        twiddle_cosine =
            twiddle_cosine * step_cosine -
            twiddle_sine * step_sine;
        twiddle_sine = next_twiddle_sine;

        if ((bin & 0xFFU) == 0xFFU)
        {
            const float inverse_length =
                1.0f / sqrtf(twiddle_sine * twiddle_sine +
                              twiddle_cosine * twiddle_cosine);

            twiddle_sine *= inverse_length;
            twiddle_cosine *= inverse_length;
        }
    }
}

static void Signal_FFT_GetReal8192Bin(const float32_t *spectrum,
                                      uint32_t bin,
                                      float *real,
                                      float *imaginary)
{
    if (bin == 0U)
    {
        *real = spectrum[0];
        *imaginary = 0.0f;
    }
    else if (bin == SIGNAL_FFT_QUARTER_SIZE)
    {
        *real = spectrum[1];
        *imaginary = 0.0f;
    }
    else if (bin < SIGNAL_FFT_QUARTER_SIZE)
    {
        *real = spectrum[2U * bin];
        *imaginary = spectrum[2U * bin + 1U];
    }
    else
    {
        const uint32_t mirror_bin = SIGNAL_FFT_HALF_SIZE - bin;

        *real = spectrum[2U * mirror_bin];
        *imaginary = -spectrum[2U * mirror_bin + 1U];
    }
}

static void Signal_FFT_TransformReal16384(const float *samples,
                                          float input_mean)
{
    const float angular_step =
        SIGNAL_FFT_TWO_PI / (float)SIGNAL_FFT_SIZE;
    const float step_sine = sinf(angular_step);
    const float step_cosine = cosf(angular_step);
    float twiddle_sine = 0.0f;
    float twiddle_cosine = 1.0f;
    uint32_t index;
    uint32_t bin;

    /*
     * First transform the even samples.  Each packed work set contains
     * exactly 8192 real samples and each output occupies 8192 floats.
     */
    for (index = 0U; index < SIGNAL_FFT_HALF_SIZE; index++)
    {
        const uint32_t source_index = 2U * index;

        signal_fft_output[index] =
            (samples[source_index] - input_mean) *
            signal_fft_window[source_index];
    }

    Signal_FFT_TransformReal8192(
        signal_fft_output,
        &signal_fft_time_data[0]);

    /* Transform the odd samples into the upper half of the work array. */
    for (index = 0U; index < SIGNAL_FFT_HALF_SIZE; index++)
    {
        const uint32_t source_index = 2U * index + 1U;

        signal_fft_output[index] =
            (samples[source_index] - input_mean) *
            signal_fft_window[source_index];
    }

    Signal_FFT_TransformReal8192(
        signal_fft_output,
        &signal_fft_time_data[SIGNAL_FFT_HALF_SIZE]);

    /*
     * Only magnitudes are required by the spectral peak detector.  Combine
     * E[k] and O[k] directly into the N/2+1 real-spectrum magnitudes, avoiding
     * another 64 KiB complex output buffer.
     */
    for (bin = 0U; bin < SIGNAL_FFT_HALF_SIZE; bin++)
    {
        float even_real;
        float even_imaginary;
        float odd_real;
        float odd_imaginary;
        float rotated_real;
        float rotated_imaginary;
        float combined_real;
        float combined_imaginary;
        float next_twiddle_sine;

        Signal_FFT_GetReal8192Bin(&signal_fft_time_data[0],
                                  bin,
                                  &even_real,
                                  &even_imaginary);
        Signal_FFT_GetReal8192Bin(
            &signal_fft_time_data[SIGNAL_FFT_HALF_SIZE],
            bin,
            &odd_real,
            &odd_imaginary);

        rotated_real =
            twiddle_cosine * odd_real +
            twiddle_sine * odd_imaginary;
        rotated_imaginary =
            twiddle_cosine * odd_imaginary -
            twiddle_sine * odd_real;
        combined_real = even_real + rotated_real;
        combined_imaginary = even_imaginary + rotated_imaginary;
        signal_fft_magnitude[bin] =
            sqrtf(combined_real * combined_real +
                  combined_imaginary * combined_imaginary);

        next_twiddle_sine =
            twiddle_sine * step_cosine +
            twiddle_cosine * step_sine;
        twiddle_cosine =
            twiddle_cosine * step_cosine -
            twiddle_sine * step_sine;
        twiddle_sine = next_twiddle_sine;

        if ((bin & 0xFFU) == 0xFFU)
        {
            const float inverse_length =
                1.0f / sqrtf(twiddle_sine * twiddle_sine +
                              twiddle_cosine * twiddle_cosine);

            twiddle_sine *= inverse_length;
            twiddle_cosine *= inverse_length;
        }
    }

    /* X[N/2] = E[0] - O[0] for a real input sequence. */
    signal_fft_magnitude[SIGNAL_FFT_HALF_SIZE] =
        fabsf(signal_fft_time_data[0] -
              signal_fft_time_data[SIGNAL_FFT_HALF_SIZE]);
}

static signal_fft_config_t Signal_FFT_DefaultConfig(void)
{
    signal_fft_config_t config;

    config.sample_rate_hz = SIGNAL_ANALYSIS_SAMPLE_RATE_HZ;
    config.minimum_frequency_hz = SIGNAL_MINIMUM_FREQUENCY_HZ;
    config.maximum_frequency_hz = SIGNAL_MAXIMUM_FREQUENCY_HZ;
    /*
     * The official minimum component is 5 mV peak.  Keep detection margin
     * before the nine-record coherence and reportability checks so a weak
     * fundamental is not lost merely because of front-end roll-off.
     */
    config.minimum_peak_amplitude = 0.0015f;
    config.noise_threshold_multiplier = 6.0f;
    config.maximum_peak_count = SIGNAL_FFT_MAX_PEAKS;
    config.peak_separation_bins = 8U;
    config.peak_energy_half_width_bins = 4U;

    return config;
}

static bool Signal_FFT_ConfigIsValid(const signal_fft_config_t *config)
{
    if ((config == NULL) ||
        (!isfinite(config->sample_rate_hz)) ||
        (!isfinite(config->minimum_frequency_hz)) ||
        (!isfinite(config->maximum_frequency_hz)) ||
        (!isfinite(config->minimum_peak_amplitude)) ||
        (!isfinite(config->noise_threshold_multiplier)))
    {
        return false;
    }

    if ((config->sample_rate_hz <= 0.0f) ||
        (config->minimum_frequency_hz < 0.0f) ||
        (config->maximum_frequency_hz <=
         config->minimum_frequency_hz) ||
        (config->maximum_frequency_hz >
         (config->sample_rate_hz * 0.5f)) ||
        (config->minimum_peak_amplitude < 0.0f) ||
        (config->noise_threshold_multiplier < 1.0f) ||
        (config->maximum_peak_count == 0U) ||
        (config->maximum_peak_count > SIGNAL_FFT_MAX_PEAKS) ||
        (config->peak_separation_bins == 0U) ||
        (config->peak_energy_half_width_bins == 0U))
    {
        return false;
    }

    return true;
}

static uint32_t Signal_FFT_Partition(float *values,
                                     uint32_t left,
                                     uint32_t right,
                                     uint32_t pivot_index)
{
    uint32_t index;
    uint32_t store_index = left;
    float pivot_value = values[pivot_index];
    float temporary = values[pivot_index];

    values[pivot_index] = values[right];
    values[right] = temporary;

    for (index = left; index < right; index++)
    {
        if (values[index] < pivot_value)
        {
            temporary = values[index];
            values[index] = values[store_index];
            values[store_index] = temporary;
            store_index++;
        }
    }

    temporary = values[right];
    values[right] = values[store_index];
    values[store_index] = temporary;
    return store_index;
}

static float Signal_FFT_Median(float *values, uint32_t count)
{
    uint32_t left = 0U;
    uint32_t right = count - 1U;
    uint32_t target = count / 2U;

    while (left < right)
    {
        uint32_t pivot_index = left + ((right - left) / 2U);

        pivot_index = Signal_FFT_Partition(values,
                                           left,
                                           right,
                                           pivot_index);

        if (pivot_index == target)
        {
            break;
        }

        if (target < pivot_index)
        {
            right = pivot_index - 1U;
        }
        else
        {
            left = pivot_index + 1U;
        }
    }

    return values[target];
}

static void Signal_FFT_GenerateBlackmanHarrisWindow(void)
{
    uint32_t index;

    signal_fft_window_sum = 0.0f;
    signal_fft_window_energy = 0.0f;

    for (index = 0U; index < SIGNAL_FFT_SIZE; index++)
    {
        float phase =
            SIGNAL_FFT_TWO_PI * (float)index /
            (float)(SIGNAL_FFT_SIZE - 1U);
        float value =
            0.35875f -
            (0.48829f * cosf(phase)) +
            (0.14128f * cosf(2.0f * phase)) -
            (0.01168f * cosf(3.0f * phase));

        signal_fft_window[index] = value;
        signal_fft_window_sum += value;
        signal_fft_window_energy += value * value;
    }
}

static uint16_t Signal_FFT_MinimumBin(void)
{
    float bin_width =
        signal_fft_config.sample_rate_hz / (float)SIGNAL_FFT_SIZE;
    uint32_t bin =
        (uint32_t)ceilf(signal_fft_config.minimum_frequency_hz /
                        bin_width);

    if (bin < 1U)
    {
        bin = 1U;
    }

    if (bin >= (SIGNAL_FFT_SIZE / 2U))
    {
        bin = (SIGNAL_FFT_SIZE / 2U) - 1U;
    }

    return (uint16_t)bin;
}

static uint16_t Signal_FFT_MaximumBin(void)
{
    float bin_width =
        signal_fft_config.sample_rate_hz / (float)SIGNAL_FFT_SIZE;
    uint32_t bin =
        (uint32_t)floorf(signal_fft_config.maximum_frequency_hz /
                         bin_width);

    if (bin < 1U)
    {
        bin = 1U;
    }

    if (bin >= (SIGNAL_FFT_SIZE / 2U))
    {
        bin = (SIGNAL_FFT_SIZE / 2U) - 1U;
    }

    return (uint16_t)bin;
}

static bool Signal_FFT_IsSeparated(
    uint16_t candidate,
    const uint16_t *selected_bins,
    uint8_t selected_count)
{
    uint8_t index;

    for (index = 0U; index < selected_count; index++)
    {
        int32_t difference =
            (int32_t)candidate - (int32_t)selected_bins[index];

        if (difference < 0)
        {
            difference = -difference;
        }

        if ((uint32_t)difference <
            (uint32_t)signal_fft_config.peak_separation_bins)
        {
            return false;
        }
    }

    return true;
}

static float Signal_FFT_RefineBinPosition(uint16_t bin)
{
    float left = logf(signal_fft_magnitude[bin - 1U] + FLT_MIN);
    float center = logf(signal_fft_magnitude[bin] + FLT_MIN);
    float right = logf(signal_fft_magnitude[bin + 1U] + FLT_MIN);
    float denominator = left - (2.0f * center) + right;
    float offset = 0.0f;

    if (fabsf(denominator) > 1.0e-12f)
    {
        offset = 0.5f * (left - right) / denominator;
    }

    if (offset > 0.5f)
    {
        offset = 0.5f;
    }
    else if (offset < -0.5f)
    {
        offset = -0.5f;
    }

    return (float)bin + offset;
}

static float Signal_FFT_CalculatePeakAmplitude(uint16_t peak_bin)
{
    uint32_t first_bin;
    uint32_t last_bin;
    uint32_t index;
    float energy = 0.0f;
    uint32_t half_width =
        signal_fft_config.peak_energy_half_width_bins;

    first_bin = (peak_bin > half_width) ?
        ((uint32_t)peak_bin - half_width) : 1U;
    last_bin = (uint32_t)peak_bin + half_width;

    if (last_bin >= (SIGNAL_FFT_SIZE / 2U))
    {
        last_bin = (SIGNAL_FFT_SIZE / 2U) - 1U;
    }

    for (index = first_bin; index <= last_bin; index++)
    {
        energy +=
            signal_fft_magnitude[index] *
            signal_fft_magnitude[index];
    }

    return 2.0f *
           sqrtf(energy /
                 ((float)SIGNAL_FFT_SIZE *
                  signal_fft_window_energy));
}

static float Signal_FFT_CalculatePeakPhase(const float *samples,
                                           float input_mean,
                                           float frequency_hz)
{
    uint32_t index;
    float angular_step =
        SIGNAL_FFT_TWO_PI * frequency_hz /
        signal_fft_config.sample_rate_hz;
    float step_sine = sinf(angular_step);
    float step_cosine = cosf(angular_step);
    float oscillator_sine = 0.0f;
    float oscillator_cosine = 1.0f;
    float sine_coefficient = 0.0f;
    float cosine_coefficient = 0.0f;

    for (index = 0U; index < SIGNAL_FFT_SIZE; index++)
    {
        float weighted_sample =
            (samples[index] - input_mean) *
            signal_fft_window[index];
        float next_sine;

        sine_coefficient += weighted_sample * oscillator_sine;
        cosine_coefficient += weighted_sample * oscillator_cosine;

        next_sine =
            oscillator_sine * step_cosine +
            oscillator_cosine * step_sine;
        oscillator_cosine =
            oscillator_cosine * step_cosine -
            oscillator_sine * step_sine;
        oscillator_sine = next_sine;

        if ((index & 0xFFU) == 0xFFU)
        {
            float inverse_length =
                1.0f /
                sqrtf(oscillator_sine * oscillator_sine +
                      oscillator_cosine * oscillator_cosine);

            oscillator_sine *= inverse_length;
            oscillator_cosine *= inverse_length;
        }
    }

    return atan2f(cosine_coefficient, sine_coefficient);
}

static void Signal_FFT_SortPeaksByFrequency(signal_fft_result_t *result)
{
    uint8_t first;

    for (first = 0U; first < result->peak_count; first++)
    {
        uint8_t second;

        for (second = (uint8_t)(first + 1U);
             second < result->peak_count;
             second++)
        {
            if (result->peaks[second].frequency_hz <
                result->peaks[first].frequency_hz)
            {
                signal_fft_peak_t temporary = result->peaks[first];
                result->peaks[first] = result->peaks[second];
                result->peaks[second] = temporary;
            }
        }
    }
}

static float Signal_FFT_HarmonicTolerance(float frequency_hz)
{
    const float bin_tolerance =
        SIGNAL_FFT_HARMONIC_TOLERANCE_BINS *
        signal_fft_config.sample_rate_hz /
        (float)SIGNAL_FFT_SIZE;
    const float relative_tolerance =
        SIGNAL_FFT_HARMONIC_RELATIVE_TOLERANCE *
        frequency_hz;

    return (relative_tolerance > bin_tolerance) ?
        relative_tolerance : bin_tolerance;
}

static bool Signal_FFT_MatchHarmonic(float frequency_hz,
                                     float fundamental_hz,
                                     uint16_t *harmonic_order)
{
    float ratio;
    float rounded_order;
    float frequency_error;

    if ((!isfinite(frequency_hz)) ||
        (!isfinite(fundamental_hz)) ||
        (frequency_hz <= 0.0f) ||
        (fundamental_hz <= 0.0f))
    {
        return false;
    }

    ratio = frequency_hz / fundamental_hz;
    rounded_order = roundf(ratio);

    if ((rounded_order < 1.0f) ||
        (rounded_order > 65535.0f))
    {
        return false;
    }

    frequency_error =
        fabsf(frequency_hz - rounded_order * fundamental_hz);

    if (frequency_error >
        Signal_FFT_HarmonicTolerance(frequency_hz))
    {
        return false;
    }

    if (harmonic_order != NULL)
    {
        *harmonic_order = (uint16_t)rounded_order;
    }

    return true;
}

#if 0
/* Legacy selection discarded all non-harmonic peaks.  Retained here only as
 * migration reference; it is deliberately not compiled in the H743 build. */
static void Signal_FFT_SelectHarmonicFamilyLegacy(
    signal_fft_result_t *result)
{
    uint8_t original_count = result->peak_count;
    uint8_t best_candidate = 0U;
    uint8_t best_match_count = 0U;
    float best_energy = -1.0f;
    uint8_t candidate;
    uint8_t peak;
    uint8_t write_index = 0U;
    float numerator = 0.0f;
    float denominator = 0.0f;

    if (original_count == 0U)
    {
        result->fundamental_frequency_hz = 0.0f;
        return;
    }

    /*
     * Test every detected peak as a possible fundamental.  The family with
     * the largest number of integer-related peaks wins; energy breaks ties.
     * This prevents a lower-frequency spur from automatically becoming f0.
     */
    for (candidate = 0U; candidate < original_count; candidate++)
    {
        uint8_t match_count = 0U;
        float energy = 0.0f;

        for (peak = 0U; peak < original_count; peak++)
        {
            if (Signal_FFT_MatchHarmonic(
                    result->peaks[peak].frequency_hz,
                    result->peaks[candidate].frequency_hz,
                    NULL))
            {
                match_count++;
                energy +=
                    result->peaks[peak].amplitude_peak *
                    result->peaks[peak].amplitude_peak;
            }
        }

        if ((match_count > best_match_count) ||
            ((match_count == best_match_count) &&
             (energy > best_energy)))
        {
            best_candidate = candidate;
            best_match_count = match_count;
            best_energy = energy;
        }
    }

    for (peak = 0U; peak < original_count; peak++)
    {
        uint16_t harmonic_order;

        if (Signal_FFT_MatchHarmonic(
                result->peaks[peak].frequency_hz,
                result->peaks[best_candidate].frequency_hz,
                &harmonic_order))
        {
            signal_fft_peak_t accepted_peak = result->peaks[peak];

            accepted_peak.harmonic_order = harmonic_order;
            result->peaks[write_index] = accepted_peak;
            write_index++;
        }
    }

    result->peak_count = write_index;

    /*
     * Weighted least-squares estimate of the common fundamental:
     *             f0 = sum(w*m*f) / sum(w*m*m)
     * where m is the integer harmonic order and w is component energy.
     */
    for (peak = 0U; peak < result->peak_count; peak++)
    {
        const float order =
            (float)result->peaks[peak].harmonic_order;
        float weight =
            result->peaks[peak].amplitude_peak *
            result->peaks[peak].amplitude_peak;

        if (weight < 1.0e-12f)
        {
            weight = 1.0e-12f;
        }

        numerator +=
            weight * order * result->peaks[peak].frequency_hz;
        denominator += weight * order * order;
    }

    if (denominator <= 0.0f)
    {
        result->peak_count = 0U;
        result->fundamental_frequency_hz = 0.0f;
        return;
    }

    result->fundamental_frequency_hz = numerator / denominator;

    /*
     * From this point onward the result uses one consistent frequency model.
     * The raw FFT bin is retained, while the reported/fitted frequency is the
     * integer harmonic of the jointly estimated fundamental.
     */
    for (peak = 0U; peak < result->peak_count; peak++)
    {
        result->peaks[peak].frequency_hz =
            result->fundamental_frequency_hz *
            (float)result->peaks[peak].harmonic_order;
        result->peaks[peak].bin_position =
            result->peaks[peak].frequency_hz *
            (float)SIGNAL_FFT_SIZE /
            signal_fft_config.sample_rate_hz;
    }
}

#endif

static void Signal_FFT_SelectHarmonicFamily(
    signal_fft_result_t *result)
{
    uint8_t best_candidate = 0U;
    uint8_t best_match_count = 0U;
    uint8_t candidate;
    uint8_t peak;
    float best_family_score = -1.0f;

    if (result->peak_count == 0U)
    {
        result->fundamental_frequency_hz = 0.0f;
        return;
    }

    /*
     * Score every actually detected line as a possible fundamental.  A real
     * fundamental in the competition input has one or two integer-related
     * partners, whereas a lower unrelated spur normally matches only itself.
     * Ties keep the lower-frequency candidate; no missing subharmonic is
     * invented; all other real peaks remain in the result unchanged.
     */
    for (candidate = 0U;
         candidate < result->peak_count;
         candidate++)
    {
        uint8_t match_count = 0U;
        float matched_energy = 0.0f;
        float family_score;

        for (peak = 0U; peak < result->peak_count; peak++)
        {
            if (Signal_FFT_MatchHarmonic(
                    result->peaks[peak].frequency_hz,
                    result->peaks[candidate].frequency_hz,
                    NULL))
            {
                match_count++;
                matched_energy +=
                    result->peaks[peak].amplitude_peak *
                    result->peaks[peak].amplitude_peak;
            }
        }

        /*
         * Energy remains the primary evidence so a strong single input is not
         * displaced by a weaker board spur that happens to have odd multiples.
         * Each additional integer-related line adds a modest 25% confidence
         * bonus; this is enough for a weak fundamental plus strong harmonics
         * to beat any one harmonic considered alone.
         */
        family_score =
            matched_energy *
            (1.0f + 0.25f * (float)(match_count - 1U));

        if ((family_score > best_family_score) ||
            ((fabsf(family_score - best_family_score) <= 1.0e-12f) &&
             (match_count > best_match_count)))
        {
            best_candidate = candidate;
            best_match_count = match_count;
            best_family_score = family_score;
        }
    }

    result->fundamental_frequency_hz =
        result->peaks[best_candidate].frequency_hz;

    /* Keep the fundamental estimate independent.  Harmonics are classified
     * against this measured base line but never pull its frequency.  Their
     * public frequencies are generated later as n*f0, after f0 itself has
     * completed the eighteen-frame robust average. */

    for (peak = 0U; peak < result->peak_count; peak++)
    {
        uint16_t harmonic_order;

        if (Signal_FFT_MatchHarmonic(
                result->peaks[peak].frequency_hz,
                result->fundamental_frequency_hz,
                &harmonic_order))
        {
            result->peaks[peak].harmonic_order = harmonic_order;
        }
        else
        {
            result->peaks[peak].harmonic_order = 0U;
        }
    }
}

static bool Signal_FFT_SolveFitSystem(
    float matrix[SIGNAL_FFT_MAX_FIT_PARAMETERS]
                [SIGNAL_FFT_MAX_FIT_PARAMETERS + 1U],
    uint8_t parameter_count,
    float *solution)
{
    uint8_t column;

    for (column = 0U; column < parameter_count; column++)
    {
        uint8_t pivot_row = column;
        float pivot_magnitude = fabsf(matrix[column][column]);
        uint8_t row;
        uint8_t item;

        for (row = (uint8_t)(column + 1U);
             row < parameter_count;
             row++)
        {
            float candidate_magnitude =
                fabsf(matrix[row][column]);

            if (candidate_magnitude > pivot_magnitude)
            {
                pivot_magnitude = candidate_magnitude;
                pivot_row = row;
            }
        }

        if (pivot_magnitude < 1.0e-6f)
        {
            return false;
        }

        if (pivot_row != column)
        {
            for (item = column;
                 item <= parameter_count;
                 item++)
            {
                float temporary = matrix[column][item];
                matrix[column][item] = matrix[pivot_row][item];
                matrix[pivot_row][item] = temporary;
            }
        }

        {
            float inverse_pivot = 1.0f / matrix[column][column];

            for (item = column;
                 item <= parameter_count;
                 item++)
            {
                matrix[column][item] *= inverse_pivot;
            }
        }

        for (row = 0U; row < parameter_count; row++)
        {
            float factor;

            if (row == column)
            {
                continue;
            }

            factor = matrix[row][column];

            for (item = column;
                 item <= parameter_count;
                 item++)
            {
                matrix[row][item] -=
                    factor * matrix[column][item];
            }
        }
    }

    for (column = 0U; column < parameter_count; column++)
    {
        solution[column] = matrix[column][parameter_count];
    }

    return true;
}

static bool Signal_FFT_FitHarmonicComponents(
    const float *samples,
    signal_fft_result_t *result)
{
    float matrix[SIGNAL_FFT_MAX_FIT_PARAMETERS]
                [SIGNAL_FFT_MAX_FIT_PARAMETERS + 1U];
    float solution[SIGNAL_FFT_MAX_FIT_PARAMETERS];
    float basis[SIGNAL_FFT_MAX_FIT_PARAMETERS];
    float oscillator_sine[SIGNAL_FFT_MAX_PEAKS];
    float oscillator_cosine[SIGNAL_FFT_MAX_PEAKS];
    float step_sine[SIGNAL_FFT_MAX_PEAKS];
    float step_cosine[SIGNAL_FFT_MAX_PEAKS];
    const uint8_t parameter_count =
        (uint8_t)(1U + (2U * result->peak_count));
    uint8_t peak;
    uint32_t index;

    if ((samples == NULL) ||
        (result->peak_count == 0U) ||
        (parameter_count > SIGNAL_FFT_MAX_FIT_PARAMETERS))
    {
        return false;
    }

    memset(matrix, 0, sizeof(matrix));
    memset(solution, 0, sizeof(solution));

    for (peak = 0U; peak < result->peak_count; peak++)
    {
        const float angular_step =
            SIGNAL_FFT_TWO_PI *
            result->peaks[peak].frequency_hz /
            signal_fft_config.sample_rate_hz;

        oscillator_sine[peak] = 0.0f;
        oscillator_cosine[peak] = 1.0f;
        step_sine[peak] = sinf(angular_step);
        step_cosine[peak] = cosf(angular_step);
    }

    for (index = 0U; index < SIGNAL_FFT_SIZE; index++)
    {
        uint8_t row;

        basis[0] = 1.0f;

        for (peak = 0U; peak < result->peak_count; peak++)
        {
            basis[1U + (2U * peak)] = oscillator_cosine[peak];
            basis[2U + (2U * peak)] = oscillator_sine[peak];
        }

        for (row = 0U; row < parameter_count; row++)
        {
            uint8_t column;

            matrix[row][parameter_count] +=
                basis[row] * samples[index];

            for (column = row;
                 column < parameter_count;
                 column++)
            {
                matrix[row][column] +=
                    basis[row] * basis[column];
            }
        }

        for (peak = 0U; peak < result->peak_count; peak++)
        {
            float next_sine =
                oscillator_sine[peak] * step_cosine[peak] +
                oscillator_cosine[peak] * step_sine[peak];

            oscillator_cosine[peak] =
                oscillator_cosine[peak] * step_cosine[peak] -
                oscillator_sine[peak] * step_sine[peak];
            oscillator_sine[peak] = next_sine;

            if ((index & 0xFFU) == 0xFFU)
            {
                float inverse_length =
                    1.0f /
                    sqrtf(oscillator_sine[peak] *
                              oscillator_sine[peak] +
                          oscillator_cosine[peak] *
                              oscillator_cosine[peak]);

                oscillator_sine[peak] *= inverse_length;
                oscillator_cosine[peak] *= inverse_length;
            }
        }
    }

    for (index = 0U; index < parameter_count; index++)
    {
        uint8_t column;

        for (column = (uint8_t)(index + 1U);
             column < parameter_count;
             column++)
        {
            matrix[column][index] = matrix[index][column];
        }
    }

    if (!Signal_FFT_SolveFitSystem(matrix,
                                   parameter_count,
                                   solution))
    {
        return false;
    }

    for (peak = 0U; peak < result->peak_count; peak++)
    {
        const float cosine_coefficient =
            solution[1U + (2U * peak)];
        const float sine_coefficient =
            solution[2U + (2U * peak)];

        result->peaks[peak].amplitude_peak =
            sqrtf(cosine_coefficient * cosine_coefficient +
                  sine_coefficient * sine_coefficient);
        result->peaks[peak].phase_radians =
            atan2f(cosine_coefficient, sine_coefficient);
    }

    return true;
}

#if 0
/* A finite peak reconstruction cannot represent an arbitrary input waveform.
 * It is superseded by the direct, filtered time-domain metrics below. */
static void Signal_FFT_CalculateVoltageMetricsLegacy(
    signal_fft_result_t *result)
{
    float oscillator_sine[SIGNAL_FFT_MAX_PEAKS];
    float oscillator_cosine[SIGNAL_FFT_MAX_PEAKS];
    float step_sine[SIGNAL_FFT_MAX_PEAKS];
    float step_cosine[SIGNAL_FFT_MAX_PEAKS];
    float minimum = FLT_MAX;
    float maximum = -FLT_MAX;
    uint8_t peak;
    uint32_t point;
    bool square_like = false;

    if (result->peak_count == 0U)
    {
        result->voltage_peak_to_peak =
            result->input_peak_to_peak;
        result->voltage_rms = result->input_rms;
        result->fundamental_frequency_hz = 0.0f;
        return;
    }

    if (result->fundamental_frequency_hz <= 0.0f)
    {
        result->fundamental_frequency_hz =
            result->peaks[0].frequency_hz;
    }

    for (peak = 0U; peak < result->peak_count; peak++)
    {
        float harmonic =
            (float)result->peaks[peak].harmonic_order;
        float angular_step;

        if (harmonic < 1.0f)
        {
            harmonic = 1.0f;
        }

        angular_step =
            SIGNAL_FFT_TWO_PI * harmonic /
            (float)SIGNAL_FFT_RECONSTRUCTION_POINTS;

        oscillator_sine[peak] =
            sinf(result->peaks[peak].phase_radians);
        oscillator_cosine[peak] =
            cosf(result->peaks[peak].phase_radians);
        step_sine[peak] = sinf(angular_step);
        step_cosine[peak] = cosf(angular_step);
    }

    for (point = 0U;
         point < SIGNAL_FFT_RECONSTRUCTION_POINTS;
         point++)
    {
        float voltage = 0.0f;

        for (peak = 0U; peak < result->peak_count; peak++)
        {
            float next_sine;

            voltage +=
                result->peaks[peak].amplitude_peak *
                oscillator_sine[peak];

            next_sine =
                oscillator_sine[peak] * step_cosine[peak] +
                oscillator_cosine[peak] * step_sine[peak];
            oscillator_cosine[peak] =
                oscillator_cosine[peak] * step_cosine[peak] -
                oscillator_sine[peak] * step_sine[peak];
            oscillator_sine[peak] = next_sine;

            if ((point & 0xFFU) == 0xFFU)
            {
                float inverse_length =
                    1.0f /
                    sqrtf(oscillator_sine[peak] *
                              oscillator_sine[peak] +
                          oscillator_cosine[peak] *
                              oscillator_cosine[peak]);

                oscillator_sine[peak] *= inverse_length;
                oscillator_cosine[peak] *= inverse_length;
            }
        }

        if (voltage < minimum)
        {
            minimum = voltage;
        }

        if (voltage > maximum)
        {
            maximum = voltage;
        }

    }

    /*
     * A 50% square wave is dominated by phase-aligned odd harmonics with
     * A3/A1 ~= 1/3 and A5/A1 ~= 1/5.  Requiring both ratios and their
     * relative phases prevents an ordinary fundamental + third-harmonic
     * input from being misclassified. A truncated Fourier reconstruction
     * has Gibbs overshoot, so use the square-wave model for that case.
     * Other periodic signals use fitted harmonic reconstruction, which
     * interpolates peaks between ADC sample instants near 500...600 kHz.
     */
    {
        float fundamental_amplitude = 0.0f;
        float third_harmonic_amplitude = 0.0f;
        float fifth_harmonic_amplitude = 0.0f;
        float fundamental_phase = 0.0f;
        float third_harmonic_phase = 0.0f;
        float fifth_harmonic_phase = 0.0f;
        bool significant_even_harmonic = false;

        for (peak = 0U; peak < result->peak_count; peak++)
        {
            const uint16_t order =
                result->peaks[peak].harmonic_order;
            const float amplitude =
                result->peaks[peak].amplitude_peak;

            if (order == 1U)
            {
                fundamental_amplitude = amplitude;
                fundamental_phase =
                    result->peaks[peak].phase_radians;
            }
            else if (order == 3U)
            {
                third_harmonic_amplitude = amplitude;
                third_harmonic_phase =
                    result->peaks[peak].phase_radians;
            }
            else if (order == 5U)
            {
                fifth_harmonic_amplitude = amplitude;
                fifth_harmonic_phase =
                    result->peaks[peak].phase_radians;
            }
        }

        if (fundamental_amplitude > 1.0e-9f)
        {
            for (peak = 0U; peak < result->peak_count; peak++)
            {
                const uint16_t order =
                    result->peaks[peak].harmonic_order;

                if (((order & 1U) == 0U) &&
                    (result->peaks[peak].amplitude_peak >
                     (0.10f * fundamental_amplitude)))
                {
                    significant_even_harmonic = true;
                }
            }

            {
                const float third_ratio =
                    third_harmonic_amplitude /
                    fundamental_amplitude;
                const float fifth_ratio =
                    fifth_harmonic_amplitude /
                    fundamental_amplitude;
                const float third_relative_phase =
                    atan2f(
                        sinf(third_harmonic_phase -
                             3.0f * fundamental_phase),
                        cosf(third_harmonic_phase -
                             3.0f * fundamental_phase));
                const float fifth_relative_phase =
                    atan2f(
                        sinf(fifth_harmonic_phase -
                             5.0f * fundamental_phase),
                        cosf(fifth_harmonic_phase -
                             5.0f * fundamental_phase));

                square_like =
                    (!significant_even_harmonic) &&
                    (third_ratio >= 0.25f) &&
                    (third_ratio <= 0.42f) &&
                    (fifth_ratio >= 0.13f) &&
                    (fifth_ratio <= 0.28f) &&
                    (fabsf(third_relative_phase) <= 0.35f) &&
                    (fabsf(fifth_relative_phase) <= 0.35f);
            }
        }
    }

    /*
     * This flag is only a low-band square-wave candidate. The application
     * must confirm the seventh and ninth harmonics in the unfiltered
     * 6.0 MSPS ADC block before applying an ideal-square Vpp/RMS model.
     * Until then, retain the exact metrics of the detected finite harmonic
     * combination so a legal A1+A3+A5 signal is never misreported.
     */
    result->square_wave_detected = square_like ? 1U : 0U;
    result->voltage_peak_to_peak = maximum - minimum;

    /*
     * RMS is the discrete integral of every filtered sample. Do not derive
     * it only from the detected peaks, otherwise weak components lose
     * energy when the peak list is truncated.
     */
    result->voltage_rms = result->input_rms;
}

#endif

static void Signal_FFT_CalculateVoltageMetrics(
    signal_fft_result_t *result)
{
    if (result->peak_count == 0U)
    {
        result->fundamental_frequency_hz = 0.0f;
    }

    /*
     * Vpp and RMS are measured from every sample after the two anti-alias
     * FIR stages.  They therefore include every in-band component, not only
     * the limited set of reportable FFT peaks, and contain no square/sine
     * waveform assumption.
     */
    result->voltage_peak_to_peak = result->input_peak_to_peak;
    result->voltage_rms = result->input_rms;
    result->square_wave_detected = 0U;
}

bool Signal_FFT_Init(const signal_fft_config_t *config)
{
    signal_fft_config_t selected_config =
        (config == NULL) ? Signal_FFT_DefaultConfig() : *config;

    if (!Signal_FFT_ConfigIsValid(&selected_config))
    {
        return false;
    }

    signal_fft_config = selected_config;
    Signal_FFT_GenerateBlackmanHarrisWindow();
    signal_fft_spectrum_valid = false;
    signal_fft_initialized = true;

    return true;
}

bool Signal_FFT_Analyze(const float *samples,
                        signal_fft_result_t *result)
{
    uint32_t index;
    uint16_t minimum_bin;
    uint16_t maximum_bin;
    uint16_t selected_bins[SIGNAL_FFT_MAX_PEAKS] = {0U};
    float input_mean = 0.0f;
    float input_minimum = FLT_MAX;
    float input_maximum = -FLT_MAX;
    float sum_of_squares = 0.0f;
    float raw_noise_median;
    float band_maximum = 0.0f;
    float coherent_amplitude_scale;
    float raw_detection_threshold;
    uint32_t noise_bin_count;

    if ((!signal_fft_initialized) ||
        (samples == NULL) ||
        (result == NULL))
    {
        return false;
    }

    memset(result, 0, sizeof(*result));

    for (index = 0U; index < SIGNAL_FFT_SIZE; index++)
    {
        input_mean += samples[index];

        if (samples[index] < input_minimum)
        {
            input_minimum = samples[index];
        }

        if (samples[index] > input_maximum)
        {
            input_maximum = samples[index];
        }
    }

    input_mean /= (float)SIGNAL_FFT_SIZE;

    for (index = 0U; index < SIGNAL_FFT_SIZE; index++)
    {
        const float centered_sample = samples[index] - input_mean;

        sum_of_squares += centered_sample * centered_sample;
    }

    Signal_FFT_TransformReal16384(samples, input_mean);

    minimum_bin = Signal_FFT_MinimumBin();
    maximum_bin = Signal_FFT_MaximumBin();
    noise_bin_count = (uint32_t)maximum_bin -
                      (uint32_t)minimum_bin + 1U;

    for (index = 0U; index < noise_bin_count; index++)
    {
        float magnitude =
            signal_fft_magnitude[(uint32_t)minimum_bin + index];

        signal_fft_time_data[index] = magnitude;

        if (magnitude > band_maximum)
        {
            band_maximum = magnitude;
        }
    }

    raw_noise_median =
        Signal_FFT_Median(signal_fft_time_data, noise_bin_count);
    coherent_amplitude_scale = 2.0f / signal_fft_window_sum;
    raw_detection_threshold =
        raw_noise_median *
        signal_fft_config.noise_threshold_multiplier;

    if ((band_maximum * SIGNAL_FFT_RELATIVE_PEAK_FLOOR) >
        raw_detection_threshold)
    {
        raw_detection_threshold =
            band_maximum * SIGNAL_FFT_RELATIVE_PEAK_FLOOR;
    }

    if (signal_fft_config.minimum_peak_amplitude > 0.0f)
    {
        float minimum_raw_magnitude =
            signal_fft_config.minimum_peak_amplitude /
            coherent_amplitude_scale;

        if (minimum_raw_magnitude > raw_detection_threshold)
        {
            raw_detection_threshold = minimum_raw_magnitude;
        }
    }

    while (result->peak_count <
           signal_fft_config.maximum_peak_count)
    {
        uint16_t best_bin = 0U;
        float best_magnitude = raw_detection_threshold;

        for (index = minimum_bin; index <= maximum_bin; index++)
        {
            uint16_t bin = (uint16_t)index;

            if ((signal_fft_magnitude[bin] >
                 signal_fft_magnitude[bin - 1U]) &&
                (signal_fft_magnitude[bin] >=
                 signal_fft_magnitude[bin + 1U]) &&
                (signal_fft_magnitude[bin] > best_magnitude) &&
                Signal_FFT_IsSeparated(bin,
                                       selected_bins,
                                       result->peak_count))
            {
                best_magnitude = signal_fft_magnitude[bin];
                best_bin = bin;
            }
        }

        if (best_bin == 0U)
        {
            break;
        }

        selected_bins[result->peak_count] = best_bin;
        result->peaks[result->peak_count].bin_index = best_bin;
        result->peaks[result->peak_count].bin_position =
            Signal_FFT_RefineBinPosition(best_bin);
        result->peaks[result->peak_count].frequency_hz =
            Signal_FFT_BinToFrequency(
                result->peaks[result->peak_count].bin_position);
        result->peaks[result->peak_count].amplitude_peak =
            Signal_FFT_CalculatePeakAmplitude(best_bin);
        result->peak_count++;
    }

    result->input_mean = input_mean;
    result->input_peak_to_peak = input_maximum - input_minimum;
    result->input_rms =
        sqrtf(sum_of_squares / (float)SIGNAL_FFT_SIZE);
    result->frequency_bin_width_hz =
        signal_fft_config.sample_rate_hz / (float)SIGNAL_FFT_SIZE;
    result->estimated_noise_floor =
        raw_noise_median * coherent_amplitude_scale;

    Signal_FFT_SortPeaksByFrequency(result);
    Signal_FFT_SelectHarmonicFamily(result);

    if (!Signal_FFT_FitHarmonicComponents(samples, result))
    {
        for (index = 0U; index < result->peak_count; index++)
        {
            result->peaks[index].phase_radians =
                Signal_FFT_CalculatePeakPhase(
                    samples,
                    input_mean,
                    result->peaks[index].frequency_hz);
        }
    }

    Signal_FFT_CalculateVoltageMetrics(result);

    signal_fft_magnitude[0] /= signal_fft_window_sum;

    for (index = 1U; index < (SIGNAL_FFT_SIZE / 2U); index++)
    {
        signal_fft_magnitude[index] *= coherent_amplitude_scale;
    }

    signal_fft_magnitude[SIGNAL_FFT_SIZE / 2U] /=
        signal_fft_window_sum;

    signal_fft_spectrum_valid = true;
    return true;
}

const float *Signal_FFT_GetSpectrum(uint32_t *bin_count)
{
    if (bin_count != NULL)
    {
        *bin_count = signal_fft_spectrum_valid ?
            SIGNAL_FFT_SPECTRUM_BIN_COUNT : 0U;
    }

    return signal_fft_spectrum_valid ?
        signal_fft_magnitude : NULL;
}

float Signal_FFT_BinToFrequency(float bin_position)
{
    if ((!signal_fft_initialized) || (!isfinite(bin_position)))
    {
        return 0.0f;
    }

    return bin_position *
           signal_fft_config.sample_rate_hz /
           (float)SIGNAL_FFT_SIZE;
}

const signal_fft_config_t *Signal_FFT_GetConfig(void)
{
    return signal_fft_initialized ? &signal_fft_config : NULL;
}
