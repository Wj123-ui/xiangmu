import fs from "node:fs/promises";
import path from "node:path";
import { Workbook, SpreadsheetFile } from "@oai/artifact-tool";

const outputDir = "C:/Users/dell/Downloads/H743/H743/outputs/stm32h743_batch_test_plan";
const outputPath = path.join(outputDir, "STM32H743_批量测量与修正记录.xlsx");
const previewDir = path.join(outputDir, "previews");

const wb = Workbook.create();
const summary = wb.worksheets.add("说明与汇总");
const single = wb.worksheets.add("单基波");
const oneH = wb.worksheets.add("一个谐波");
const twoH = wb.worksheets.add("两个谐波");
const noise = wb.worksheets.add("噪声筛选");
const correction = wb.worksheets.add("修正记录");

const C = {
  navy: "#16324F",
  teal: "#006D77",
  teal2: "#0A9396",
  white: "#FFFFFF",
  ink: "#1F2937",
  muted: "#5B6573",
  grid: "#CBD5E1",
  blue: "#DCEEFF",
  yellow: "#FFF2CC",
  green: "#E2F0D9",
  gray: "#E7E6E6",
  red: "#FCE8E6",
  pale: "#F7FAFC",
};

function colName(n) {
  let s = "";
  for (let x = n; x > 0; x = Math.floor((x - 1) / 26)) s = String.fromCharCode(65 + ((x - 1) % 26)) + s;
  return s;
}

function theoreticalVpp(components, steps = 65536) {
  let lo = Infinity;
  let hi = -Infinity;
  for (let i = 0; i < steps; i++) {
    const t = (2 * Math.PI * i) / steps;
    let u = 0;
    for (const c of components) u += (c.vpp / 2) * Math.sin(c.order * t + (c.phase * Math.PI) / 180);
    if (u < lo) lo = u;
    if (u > hi) hi = u;
  }
  return Number((hi - lo).toFixed(4));
}

function aliasKHz(noiseMHz, sampleMHz) {
  const f = noiseMHz * 1000;
  const fs = sampleMHz * 1000;
  const m = ((f % fs) + fs) % fs;
  return Math.min(m, fs - m);
}

function safeText(a6, a48) {
  const inBand = (a) => a >= 5 && a <= 510;
  const s6 = !inBand(a6);
  const s48 = !inBand(a48);
  if (s6 && s48) return "两种采样率均应避开有效带，软件自动处理";
  if (s6) return "6.0 MSPS 通道应更干净（仅诊断，不人工切换）";
  if (s48) return "4.8 MSPS 通道应更干净（仅诊断，不人工切换）";
  return "两路均可能折叠入带，依靠交叉一致性拒绝噪声";
}

function baseSheet(sheet, title, subtitle, headers, rows, tableName) {
  const lastCol = colName(headers.length);
  sheet.showGridLines = false;
  sheet.getRange(`A1:${lastCol}1`).merge();
  sheet.getRange("A1").values = [[title]];
  sheet.getRange(`A2:${lastCol}2`).merge();
  sheet.getRange("A2").values = [[subtitle]];
  sheet.getRange(`A3:${lastCol}3`).values = [headers];
  sheet.getRange(`A4:${lastCol}${3 + rows.length}`).values = rows;
  sheet.getRange(`A1:${lastCol}1`).format = {
    fill: C.navy,
    font: { bold: true, color: C.white, size: 16 },
    verticalAlignment: "center",
  };
  sheet.getRange(`A1:${lastCol}1`).format.rowHeight = 30;
  sheet.getRange(`A2:${lastCol}2`).format = {
    fill: "#D9EAF2",
    font: { color: C.ink, italic: true, size: 10 },
    wrapText: true,
    verticalAlignment: "center",
  };
  sheet.getRange(`A2:${lastCol}2`).format.rowHeight = 34;
  sheet.getRange(`A3:${lastCol}3`).format = {
    fill: C.teal,
    font: { bold: true, color: C.white, size: 10 },
    wrapText: true,
    horizontalAlignment: "center",
    verticalAlignment: "center",
    borders: { preset: "all", style: "thin", color: C.grid },
  };
  sheet.getRange(`A3:${lastCol}3`).format.rowHeight = 44;
  sheet.getRange(`A4:${lastCol}${3 + rows.length}`).format = {
    font: { color: C.ink, size: 10 },
    verticalAlignment: "center",
    borders: { preset: "all", style: "thin", color: C.grid },
  };
  sheet.getRange(`A4:${lastCol}${3 + rows.length}`).format.rowHeight = 22;
  sheet.freezePanes.freezeRows(3);
  sheet.freezePanes.freezeColumns(2);
  sheet.tables.add(`A3:${lastCol}${3 + rows.length}`, true, tableName);
}

function styleColumns(sheet, ranges) {
  for (const [address, fill] of ranges) sheet.getRange(address).format.fill = fill;
}

function statusFormatting(range) {
  range.conditionalFormats.add("containsText", { text: "通过", format: { fill: "#C6EFCE", font: { color: "#006100", bold: true } } });
  range.conditionalFormats.add("containsText", { text: "超差", format: { fill: "#FFC7CE", font: { color: "#9C0006", bold: true } } });
  range.conditionalFormats.add("containsText", { text: "待", format: { fill: "#FFEB9C", font: { color: "#9C6500" } } });
}

function setWidths(sheet, widths) {
  for (const [col, width] of Object.entries(widths)) sheet.getRange(`${col}:${col}`).format.columnWidth = width;
}

const singleCases = [
  ["S01", 10, 50], ["S02", 10, 100], ["S03", 10, 250], ["S04", 20, 80],
  ["S05", 50, 150], ["S06", 80, 200], ["S07", 100, 50], ["S08", 100, 100],
  ["S09", 100, 250], ["S10", 150, 120], ["S11", 200, 180], ["S12", 250, 100],
  ["S13", 300, 150], ["S14", 350, 200], ["S15", 400, 50], ["S16", 400, 100],
  ["S17", 450, 150], ["S18", 480, 200], ["S19", 500, 100], ["S20", 510, 250],
];

const singleHeaders = [
  "编号", "信号源f0 (kHz)", "信号源Vpp (mV)", "理论A1峰值 (mV)", "理论真有效值 (mV)", "信号说明",
  "实测整波Vpp (mV)", "实测真有效值 (mV)", "实测f0 (kHz)", "实测A1峰值 (mV)", "整轮耗时 (ms)",
  "Vpp误差 (mV)", "RMS误差 (mV)", "f0误差 (Hz)", "A1误差 (mV)", "目标判定", "备注",
];
const singleRows = singleCases.map(([id, f, vpp], i) => {
  const r = i + 4;
  return [id, f, vpp, `=C${r}/2`, `=D${r}/SQRT(2)`, "仅正弦基波", null, null, null, null, null,
    `=IF(G${r}="","",G${r}-C${r})`, `=IF(H${r}="","",H${r}-E${r})`, `=IF(I${r}="","",(I${r}-B${r})*1000)`, `=IF(J${r}="","",J${r}-D${r})`,
    `=IF(COUNT(G${r}:J${r})<4,"待填写",IF(AND(ABS(L${r})<=1,ABS(M${r})<=1,ABS(N${r})<=20,ABS(O${r})<=1),"通过","超差"))`, null];
});
baseSheet(single, "单基波批量测试（20组）", "你只设置蓝色的信号源频率和峰峰值；软件自动采样、FFT、18帧去3高去3低平均并输出，黄色栏填写最终结果。", singleHeaders, singleRows, "SingleToneTests");
styleColumns(single, [["B4:C23", C.blue], ["G4:K23", C.yellow], ["D4:E23", C.green], ["L4:P23", C.pale]]);
statusFormatting(single.getRange("P4:P23"));
single.getRange("B4:B23").format.numberFormat = "0.0000";
single.getRange("C4:E23").format.numberFormat = "0.000";
single.getRange("G4:O23").format.numberFormat = "0.0000";
setWidths(single, {A:9,B:15,C:16,D:17,E:18,F:16,G:17,H:18,I:15,J:17,K:14,L:15,M:15,N:14,O:15,P:12,Q:24});

const oneHCases = [
  ["H101",10,2,60,30,0], ["H102",10,5,100,40,30], ["H103",20,3,150,50,90], ["H104",25,4,200,40,45],
  ["H105",40,2,80,40,-45], ["H106",50,3,120,60,0], ["H107",60,5,160,50,90], ["H108",80,2,200,40,30],
  ["H109",100,2,100,50,-90], ["H110",100,5,180,40,60], ["H111",120,3,120,30,45], ["H112",150,2,200,20,0],
  ["H113",160,3,140,40,-30], ["H114",180,2,100,60,90], ["H115",200,2,180,50,30], ["H116",225,2,200,30,-60],
  ["H117",240,2,120,50,45], ["H118",250,2,160,40,0], ["H119",255,2,100,40,90], ["H120",50,10,120,20,-90],
];
const oneHeaders = [
  "编号","信号源f0 (kHz)","谐波次数n","理论fh (kHz)","基波分量Vpp (mV)","谐波分量Vpp (mV)","谐波相位 (°)",
  "理论A1峰值 (mV)","理论Ah峰值 (mV)","理论整波Vpp (mV)","理论真有效值 (mV)",
  "实测整波Vpp (mV)","实测真有效值 (mV)","实测f0 (kHz)","实测A1峰值 (mV)","实测fh (kHz)","实测Ah峰值 (mV)","整轮耗时 (ms)",
  "Vpp误差 (mV)","RMS误差 (mV)","f0误差 (Hz)","A1误差 (mV)","fh误差 (Hz)","Ah误差 (mV)","目标判定","备注",
];
const oneRows = oneHCases.map(([id,f,n,v1,vh,ph], i) => {
  const r = i + 4;
  const total = theoreticalVpp([{order:1,vpp:v1,phase:0},{order:n,vpp:vh,phase:ph}]);
  return [id,f,n,`=B${r}*C${r}`,v1,vh,ph,`=E${r}/2`,`=F${r}/2`,total,`=SQRT((E${r}^2+F${r}^2)/8)`,
    null,null,null,null,null,null,null,
    `=IF(L${r}="","",L${r}-J${r})`,`=IF(M${r}="","",M${r}-K${r})`,`=IF(N${r}="","",(N${r}-B${r})*1000)`,`=IF(O${r}="","",O${r}-H${r})`,
    `=IF(P${r}="","",(P${r}-D${r})*1000)`,`=IF(Q${r}="","",Q${r}-I${r})`,
    `=IF(COUNT(L${r}:Q${r})<6,"待填写",IF(AND(ABS(S${r})<=1,ABS(T${r})<=1,ABS(U${r})<=20,ABS(V${r})<=1,ABS(W${r})<=20,ABS(X${r})<=1),"通过","超差"))`,null];
});
baseSheet(oneH, "基波 + 一个谐波批量测试（20组）", "蓝色栏为信号源设置；各分量Vpp是该正弦分量自身的峰峰值。程序返回的谐波幅值按峰值A填写，不是Vpp。", oneHeaders, oneRows, "OneHarmonicTests");
styleColumns(oneH, [["B4:C23", C.blue], ["E4:G23", C.blue], ["L4:R23", C.yellow], ["D4:K23", C.green], ["S4:Y23", C.pale]]);
statusFormatting(oneH.getRange("Y4:Y23"));
oneH.getRange("B4:K23").format.numberFormat = "0.0000";
oneH.getRange("L4:X23").format.numberFormat = "0.0000";
setWidths(oneH, {A:9,B:15,C:12,D:14,E:18,F:18,G:14,H:17,I:17,J:18,K:18,L:17,M:18,N:15,O:17,P:15,Q:17,R:14,S:15,T:15,U:14,V:15,W:14,X:15,Y:12,Z:24});

const twoHCases = [
  ["H201",10,2,3,60,30,20,0,90], ["H202",10,5,9,100,35,20,30,-45], ["H203",20,2,5,120,40,20,-30,60], ["H204",25,3,7,160,40,25,45,90],
  ["H205",40,2,4,80,30,20,-45,30], ["H206",50,2,5,120,50,20,0,90], ["H207",60,3,5,150,40,30,30,-60], ["H208",80,2,6,180,40,20,90,45],
  ["H209",100,2,4,100,50,25,-90,30], ["H210",100,3,5,160,40,20,60,-45], ["H211",120,2,4,120,35,20,45,90], ["H212",125,2,4,180,30,20,0,-60],
  ["H213",150,2,3,120,50,30,30,90], ["H214",160,2,3,150,40,20,-30,45], ["H215",170,2,3,100,40,30,90,-45], ["H216",20,10,20,180,25,15,45,-90],
  ["H217",40,5,10,200,25,15,-60,30], ["H218",50,4,10,100,50,20,90,0], ["H219",80,3,6,140,40,20,30,60], ["H220",100,2,5,200,25,15,-45,90],
];
const twoHeaders = [
  "编号","信号源f0 (kHz)","谐波1次数n2","谐波2次数n3","理论fh2 (kHz)","理论fh3 (kHz)",
  "基波分量Vpp (mV)","谐波1分量Vpp (mV)","谐波2分量Vpp (mV)","谐波1相位 (°)","谐波2相位 (°)",
  "理论A1峰值 (mV)","理论A2峰值 (mV)","理论A3峰值 (mV)","理论整波Vpp (mV)","理论真有效值 (mV)",
  "实测整波Vpp (mV)","实测真有效值 (mV)","实测f0 (kHz)","实测A1峰值 (mV)","实测fh2 (kHz)","实测A2峰值 (mV)","实测fh3 (kHz)","实测A3峰值 (mV)","整轮耗时 (ms)",
  "Vpp误差 (mV)","RMS误差 (mV)","f0误差 (Hz)","A1误差 (mV)","fh2误差 (Hz)","A2误差 (mV)","fh3误差 (Hz)","A3误差 (mV)","目标判定","备注",
];
const twoRows = twoHCases.map(([id,f,n2,n3,v1,v2,v3,p2,p3], i) => {
  const r = i + 4;
  const total = theoreticalVpp([{order:1,vpp:v1,phase:0},{order:n2,vpp:v2,phase:p2},{order:n3,vpp:v3,phase:p3}]);
  return [id,f,n2,n3,`=B${r}*C${r}`,`=B${r}*D${r}`,v1,v2,v3,p2,p3,`=G${r}/2`,`=H${r}/2`,`=I${r}/2`,total,`=SQRT((G${r}^2+H${r}^2+I${r}^2)/8)`,
    null,null,null,null,null,null,null,null,null,
    `=IF(Q${r}="","",Q${r}-O${r})`,`=IF(R${r}="","",R${r}-P${r})`,`=IF(S${r}="","",(S${r}-B${r})*1000)`,`=IF(T${r}="","",T${r}-L${r})`,
    `=IF(U${r}="","",(U${r}-E${r})*1000)`,`=IF(V${r}="","",V${r}-M${r})`,`=IF(W${r}="","",(W${r}-F${r})*1000)`,`=IF(X${r}="","",X${r}-N${r})`,
    `=IF(COUNT(Q${r}:X${r})<8,"待填写",IF(AND(ABS(Z${r})<=1,ABS(AA${r})<=1,ABS(AB${r})<=20,ABS(AC${r})<=1,ABS(AD${r})<=20,ABS(AE${r})<=1,ABS(AF${r})<=20,ABS(AG${r})<=1),"通过","超差"))`,null];
});
baseSheet(twoH, "基波 + 两个谐波批量测试（20组）", "蓝色栏为信号源设置；所有分量均为正弦波。理论整波Vpp按给定相位对合成波形做65536点求极差，RMS按各正交谐波平方和计算。", twoHeaders, twoRows, "TwoHarmonicTests");
styleColumns(twoH, [["B4:D23", C.blue], ["G4:K23", C.blue], ["Q4:Y23", C.yellow], ["E4:F23", C.green], ["L4:P23", C.green], ["Z4:AH23", C.pale]]);
statusFormatting(twoH.getRange("AH4:AH23"));
twoH.getRange("B4:P23").format.numberFormat = "0.0000";
twoH.getRange("Q4:AG23").format.numberFormat = "0.0000";
setWidths(twoH, {A:9,B:15,C:13,D:13,E:15,F:15,G:18,H:19,I:19,J:15,K:15,L:17,M:17,N:17,O:18,P:18,Q:17,R:18,S:15,T:17,U:16,V:17,W:16,X:17,Y:14,Z:15,AA:15,AB:14,AC:15,AD:15,AE:15,AF:15,AG:15,AH:12,AI:24});

const noiseFreqs = [1.0,1.2,2.4,3.0,4.3,4.8,5.3,5.5,5.75,6.0,6.5,9.8,11.5,12.0,14.7,17.5,18.0,18.7,19.6,20.0];
const fixedNoiseComponents = [{order:1,vpp:120,phase:0},{order:2,vpp:40,phase:30},{order:4,vpp:20,phase:-45}];
const fixedUbVpp = theoreticalVpp(fixedNoiseComponents);
const noiseHeaders = [
  "编号","仅改变：噪声频率 (MHz)","噪声Vpp (mV)","固定f0 (kHz)","固定n2","固定n3","基波分量Vpp (mV)","谐波1分量Vpp (mV)","谐波2分量Vpp (mV)","谐波1相位 (°)","谐波2相位 (°)",
  "理论有效波Vpp (mV)","理论有效波RMS (mV)","6MSPS折叠频率 (kHz)","4.8MSPS折叠频率 (kHz)","软件自动判别预期（非人工设置）",
  "实测有效波Vpp (mV)","实测真有效值 (mV)","实测f0 (kHz)","实测A1峰值 (mV)","实测fh2 (kHz)","实测A2峰值 (mV)","实测fh3 (kHz)","实测A3峰值 (mV)","程序采样率记录 (可留空)","整轮耗时 (ms)",
  "Vpp误差 (mV)","RMS误差 (mV)","f0误差 (Hz)","A1误差 (mV)","fh2误差 (Hz)","A2误差 (mV)","fh3误差 (Hz)","A3误差 (mV)","目标判定","备注",
];
const noiseRows = noiseFreqs.map((fj, i) => {
  const r = i + 4;
  const a6 = Number(aliasKHz(fj,6.0).toFixed(3));
  const a48 = Number(aliasKHz(fj,4.8).toFixed(3));
  return [`N${String(i+1).padStart(2,"0")}`,fj,200,100,2,4,120,40,20,30,-45,fixedUbVpp,`=SQRT((G${r}^2+H${r}^2+I${r}^2)/8)`,a6,a48,safeText(a6,a48),
    null,null,null,null,null,null,null,null,null,null,
    `=IF(Q${r}="","",Q${r}-L${r})`,`=IF(R${r}="","",R${r}-M${r})`,`=IF(S${r}="","",(S${r}-D${r})*1000)`,`=IF(T${r}="","",T${r}-G${r}/2)`,
    `=IF(U${r}="","",(U${r}-D${r}*E${r})*1000)`,`=IF(V${r}="","",V${r}-H${r}/2)`,`=IF(W${r}="","",(W${r}-D${r}*F${r})*1000)`,`=IF(X${r}="","",X${r}-I${r}/2)`,
    `=IF(COUNT(Q${r}:X${r})<8,"待填写",IF(AND(ABS(AA${r})<=1,ABS(AB${r})<=1,ABS(AC${r})<=20,ABS(AD${r})<=1,ABS(AE${r})<=20,ABS(AF${r})<=1,ABS(AG${r})<=20,ABS(AH${r})<=1),"通过","超差"))`,null];
});
baseSheet(noise, "高频正弦噪声筛选测试（20组）", "每组只改变蓝色的噪声频率；有效波、噪声200mVpp和其他参数保持固定。采样率由程序自动选择，折叠频率仅用于事后诊断。", noiseHeaders, noiseRows, "NoiseRejectionTests");
styleColumns(noise, [["B4:B23", C.blue], ["Q4:Z23", C.yellow], ["C4:M23", C.gray], ["N4:P23", C.green], ["AA4:AI23", C.pale]]);
statusFormatting(noise.getRange("AI4:AI23"));
noise.getRange("B4:O23").format.numberFormat = "0.0000";
noise.getRange("Q4:AH23").format.numberFormat = "0.0000";
noise.getRange("P4:P23").format.wrapText = true;
setWidths(noise, {A:9,B:22,C:15,D:14,E:10,F:10,G:18,H:19,I:19,J:15,K:15,L:19,M:19,N:19,O:21,P:40,Q:18,R:18,S:15,T:17,U:16,V:17,W:16,X:17,Y:20,Z:14,AA:15,AB:15,AC:14,AD:15,AE:15,AF:15,AG:15,AH:15,AI:12,AJ:24});

summary.showGridLines = false;
summary.getRange("A1:H1").merge();
summary.getRange("A1").values = [["STM32H743 周期信号批量测量与修正工作簿"]];
summary.getRange("A1:H1").format = { fill: C.navy, font: { bold:true, color:C.white, size:18 }, verticalAlignment:"center" };
summary.getRange("A1:H1").format.rowHeight = 34;
summary.getRange("A3:H3").merge();
summary.getRange("A3").values = [["使用规则：你只改信号源参数，采样率、FFT、滤波、18帧稳健平均和采样率选择均由软件正常运行。每行等待一整轮结束后，只把最终显示值填进黄色栏。"]];
summary.getRange("A3:H3").format = { fill:"#D9EAF2", font:{bold:true,color:C.ink}, wrapText:true };
summary.getRange("A3:H3").format.rowHeight = 42;
summary.getRange("A5:B11").values = [
  ["项目","统一定义"],
  ["整波峰峰值Vpp","完整有效波形的最大值减最小值；多谐波时不能把各分量Vpp直接相加"],
  ["频谱幅值A","单个正弦分量的峰值；该分量Vpp = 2A"],
  ["真有效值","去直流后完整有效信号RMS；不同整数次谐波为 sqrt(ΣA²/2)"],
  ["频率范围","本批表覆盖 10–510 kHz；510 kHz仅作上边界容错测试"],
  ["误差目标","电压类绝对误差 ≤ 1 mV；基波与谐波频率绝对误差 ≤ 20 Hz"],
  ["噪声组","有效波固定，噪声固定200 mVpp，只改变1–20 MHz噪声频率"],
];
summary.getRange("A5:B5").format = { fill:C.teal, font:{bold:true,color:C.white}, borders:{preset:"all",style:"thin",color:C.grid} };
summary.getRange("A6:B11").format = { borders:{preset:"all",style:"thin",color:C.grid}, wrapText:true, verticalAlignment:"center" };
summary.getRange("A13:E18").values = [
  ["测试表","计划组数","已填写组数","通过组数","通过率"],
  ["单基波",20,`=COUNTIF('单基波'!P4:P23,"通过")+COUNTIF('单基波'!P4:P23,"超差")`,`=COUNTIF('单基波'!P4:P23,"通过")`,`=IF(C14=0,"",D14/C14)`],
  ["一个谐波",20,`=COUNTIF('一个谐波'!Y4:Y23,"通过")+COUNTIF('一个谐波'!Y4:Y23,"超差")`,`=COUNTIF('一个谐波'!Y4:Y23,"通过")`,`=IF(C15=0,"",D15/C15)`],
  ["两个谐波",20,`=COUNTIF('两个谐波'!AH4:AH23,"通过")+COUNTIF('两个谐波'!AH4:AH23,"超差")`,`=COUNTIF('两个谐波'!AH4:AH23,"通过")`,`=IF(C16=0,"",D16/C16)`],
  ["噪声筛选",20,`=COUNTIF('噪声筛选'!AI4:AI23,"通过")+COUNTIF('噪声筛选'!AI4:AI23,"超差")`,`=COUNTIF('噪声筛选'!AI4:AI23,"通过")`,`=IF(C17=0,"",D17/C17)`],
  ["合计",`=SUM(B14:B17)`,`=SUM(C14:C17)`,`=SUM(D14:D17)`,`=IF(C18=0,"",D18/C18)`],
];
summary.getRange("A13:E13").format = { fill:C.teal, font:{bold:true,color:C.white}, horizontalAlignment:"center", borders:{preset:"all",style:"thin",color:C.grid} };
summary.getRange("A14:E18").format = { borders:{preset:"all",style:"thin",color:C.grid}, horizontalAlignment:"center" };
summary.getRange("E14:E18").format.numberFormat = "0.0%";
summary.getRange("A20:H20").merge();
summary.getRange("A20").values = [["执行顺序建议：先完成单基波 → 一个谐波 → 两个谐波，确认幅值/频率定义无误后再做噪声组。发现系统性偏差时先记录，不要现场改采样率或协议；整批完成后按“修正记录”统一更新。"]];
summary.getRange("A20:H20").format = { fill:C.green, font:{bold:true,color:C.ink}, wrapText:true };
summary.getRange("A20:H20").format.rowHeight = 42;
summary.getRange("A22:H26").values = [
  ["颜色","含义","填写人","说明",null,null,null,null],
  ["蓝色","信号源设置","你","只调整这些参数",null,null,null,null],
  ["黄色","软件最终输出","你","一整轮结束后填写",null,null,null,null],
  ["绿色","理论值/诊断值","表格自动","不要手工改",null,null,null,null],
  ["灰色","固定条件","不改","噪声组尤其保持不变",null,null,null,null],
];
summary.getRange("A22:D22").format = { fill:C.teal, font:{bold:true,color:C.white}, borders:{preset:"all",style:"thin",color:C.grid} };
summary.getRange("A23:D26").format = { borders:{preset:"all",style:"thin",color:C.grid} };
summary.getRange("A23").format.fill = C.blue;
summary.getRange("A24").format.fill = C.yellow;
summary.getRange("A25").format.fill = C.green;
summary.getRange("A26").format.fill = C.gray;
summary.freezePanes.freezeRows(3);
setWidths(summary, {A:18,B:70,C:16,D:35,E:14,F:14,G:14,H:14});

correction.showGridLines = false;
correction.getRange("A1:H1").merge();
correction.getRange("A1").values = [["修正记录（整批测完后统一改，不在测试中途改采样率）"]];
correction.getRange("A1:H1").format = { fill:C.navy, font:{bold:true,color:C.white,size:16} };
correction.getRange("A3:D12").values = [
  ["当前项","当前值","下一版值","说明"],
  ["ADC偏置 (V)",1.535449,null,"宏定义与W25校准记录保持一致"],
  ["前端增益",5.978054,null,"由500 kHz / 100 mVpp校准所得"],
  ["频率总校正Kf",1.00002513,null,"对频率结果统一乘法校正"],
  ["FFT点数",16384,null,"固定，不作为人工测试变量"],
  ["主采样率 (MSPS)",6.0,null,"由软件使用"],
  ["辅助采样率 (MSPS)",4.8,null,"由软件用于高频噪声交叉判别"],
  ["正式统计帧数",18,null,"连续18帧"],
  ["每端剔除帧数",3,null,"去3个最高、3个最低，余12帧平均"],
  ["幅值修正 10 kHz",1.061113,null,"当前锚点，等待本批复核"],
];
correction.getRange("A3:D3").format = { fill:C.teal, font:{bold:true,color:C.white}, borders:{preset:"all",style:"thin",color:C.grid} };
correction.getRange("A4:D12").format = { borders:{preset:"all",style:"thin",color:C.grid}, wrapText:true };
correction.getRange("B4:B12").format.fill = C.gray;
correction.getRange("C4:C12").format.fill = C.yellow;
correction.getRange("A14:H20").values = [
  ["修正批次","日期","依据测试表","主要偏差现象","修改的常量/算法","修改前","修改后","复测结论"],
  ["R01",null,null,null,null,null,null,null],
  ["R02",null,null,null,null,null,null,null],
  ["R03",null,null,null,null,null,null,null],
  ["R04",null,null,null,null,null,null,null],
  ["R05",null,null,null,null,null,null,null],
  ["R06",null,null,null,null,null,null,null],
];
correction.getRange("A14:H14").format = { fill:C.teal, font:{bold:true,color:C.white}, wrapText:true, borders:{preset:"all",style:"thin",color:C.grid} };
correction.getRange("A15:H20").format = { fill:C.yellow, borders:{preset:"all",style:"thin",color:C.grid}, wrapText:true };
correction.getRange("A22:H25").values = [
  ["后续修正原则",null,null,null,null,null,null,null],
  ["1. 先区分频率系统误差、幅值随频率误差、单点异常和噪声折叠异常；不要用一个系数同时修四类问题。",null,null,null,null,null,null,null],
  ["2. 谐波频率按Hz与基波整数倍匹配，不比较FFT bin编号；两个采样率的bin宽不同（约366.211 Hz与292.969 Hz）。",null,null,null,null,null,null,null],
  ["3. 噪声组只检查有效波是否被保留、1–20 MHz噪声是否不显示；串口协议和x0~x7含义保持不变。",null,null,null,null,null,null,null],
];
for (const row of [22,23,24,25]) correction.getRange(`A${row}:H${row}`).merge();
correction.getRange("A22:H22").format = { fill:C.teal, font:{bold:true,color:C.white} };
correction.getRange("A23:H25").format = { fill:"#D9EAF2", wrapText:true };
correction.freezePanes.freezeRows(3);
setWidths(correction, {A:24,B:18,C:18,D:42,E:30,F:16,G:16,H:28});

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });
const xlsx = await SpreadsheetFile.exportXlsx(wb);
await xlsx.save(outputPath);

const sheetsToRender = [
  ["说明与汇总","A1:H26"], ["单基波","A1:Q23"], ["一个谐波","A1:Z23"],
  ["两个谐波","A1:AI23"], ["噪声筛选","A1:AJ23"], ["修正记录","A1:H25"],
];
for (const [sheetName, range] of sheetsToRender) {
  const img = await wb.render({ sheetName, range, autoCrop:"all", scale:0.72, format:"png" });
  const bytes = new Uint8Array(await img.arrayBuffer());
  await fs.writeFile(path.join(previewDir, `${sheetName}.png`), bytes);
}

const inspect = await wb.inspect({ kind:"workbook,sheet,table", maxChars:6000, tableMaxRows:4, tableMaxCols:8, tableMaxCellChars:80 });
const errors = await wb.inspect({ kind:"match", searchTerm:"#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A", options:{useRegex:true,maxResults:200}, maxChars:5000 });
console.log(JSON.stringify({ outputPath, inspect: inspect.ndjson ?? inspect, errors: errors.ndjson ?? errors }, null, 2));
