#!/usr/bin/env python3
"""Static and numerical verification for the F407-to-H743 signal-chain port."""

from __future__ import annotations

import json
import math
import re
import sys
from pathlib import Path

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
ADC_CLOCK_HZ = 24_000_000.0
INTERLEAVE_PHASE_CYCLES = 4.0
ADC_PROGRAMMED_DELAY_CYCLES = 2.5
ADC_SAMPLE_TIME_CYCLES = 1.5
ADC_RESOLUTION_BITS = 12
ADC_CONVERSION_CYCLES = (
    ADC_SAMPLE_TIME_CYCLES + 0.5 + ADC_RESOLUTION_BITS / 2.0
)
ADC_SAMPLE_RATE_HZ = ADC_CLOCK_HZ / INTERLEAVE_PHASE_CYCLES
DECIMATION = 1
ANALYSIS_RATE_HZ = ADC_SAMPLE_RATE_HZ / DECIMATION
FFT_SIZE = 16384
WARMUP = 512
CAPTURE_COUNT = (FFT_SIZE + WARMUP) * DECIMATION
DMA_WORD_COUNT = CAPTURE_COUNT // 2
DMA_BYTE_COUNT = DMA_WORD_COUNT * 4
DMA_BANDWIDTH_BYTES_PER_SECOND = ADC_SAMPLE_RATE_HZ * 2.0
CAPTURE_DURATION_SECONDS = CAPTURE_COUNT / ADC_SAMPLE_RATE_HZ
HALF_BUFFER_CPU_CYCLES = (
    (CAPTURE_COUNT / 2.0) * 480_000_000.0 / ADC_SAMPLE_RATE_HZ
)
ADC_VREF = 3.3
ADC_BIAS = 2.080224
FRONTEND_GAIN = 8.444958
ADC_FULL_SCALE = 4095.0
INPUT_MIN_V = -ADC_BIAS / FRONTEND_GAIN
INPUT_MAX_V = (ADC_VREF - ADC_BIAS) / FRONTEND_GAIN


def require_text(path: str, patterns: list[str]) -> None:
    text = (PROJECT_ROOT / path).read_text(encoding="utf-8")
    missing = [pattern for pattern in patterns if re.search(pattern, text) is None]
    if missing:
        raise AssertionError(f"{path}: missing patterns {missing}")


def forbid_text(path: str, patterns: list[str]) -> None:
    text = (PROJECT_ROOT / path).read_text(encoding="utf-8")
    present = [pattern for pattern in patterns if re.search(pattern, text)]
    if present:
        raise AssertionError(f"{path}: forbidden patterns {present}")


def generate_lowpass(tap_count: int, cutoff_hz: float, rate_hz: float) -> np.ndarray:
    index = np.arange(tap_count, dtype=np.float64)
    center = (tap_count - 1) // 2
    offset = index - center
    phase = 2.0 * np.pi * index / (tap_count - 1)
    window = (
        0.35875
        - 0.48829 * np.cos(phase)
        + 0.14128 * np.cos(2.0 * phase)
        - 0.01168 * np.cos(3.0 * phase)
    )
    normalized_cutoff = cutoff_hz / rate_hz
    ideal = np.empty(tap_count, dtype=np.float64)
    ideal[center] = 2.0 * normalized_cutoff
    non_center = index != center
    ideal[non_center] = np.sin(
        2.0 * np.pi * normalized_cutoff * offset[non_center]
    ) / (np.pi * offset[non_center])
    coefficients = ideal * window
    return coefficients / np.sum(coefficients)


FIR1 = generate_lowpass(513, 650_000.0, ADC_SAMPLE_RATE_HZ)
FIR2 = generate_lowpass(257, 625_000.0, ANALYSIS_RATE_HZ)


def fir_response_db(coefficients: np.ndarray, frequency_hz: float, rate_hz: float) -> float:
    angular_frequency = 2.0 * np.pi * frequency_hz / rate_hz
    response = np.sum(
        coefficients
        * np.exp(
            -1.0j
            * angular_frequency
            * np.arange(len(coefficients), dtype=np.float64)
        )
    )
    magnitude = max(float(abs(response)), 1e-300)
    return 20.0 * math.log10(magnitude)


def adc_roundtrip(input_voltage: np.ndarray) -> np.ndarray:
    adc_voltage = ADC_BIAS + FRONTEND_GAIN * input_voltage
    codes = np.rint(adc_voltage * ADC_FULL_SCALE / ADC_VREF)
    codes = np.clip(codes, 0.0, ADC_FULL_SCALE).astype(np.uint16)

    packed = codes[0::2].astype(np.uint32)
    packed |= codes[1::2].astype(np.uint32) << np.uint32(16)
    unpacked = np.empty_like(codes)
    unpacked[0::2] = (packed & np.uint32(0xFFFF)).astype(np.uint16)
    unpacked[1::2] = (packed >> np.uint32(16)).astype(np.uint16)
    if not np.array_equal(codes, unpacked):
        raise AssertionError("dual-ADC packed DMA ordering failed")

    return (
        unpacked.astype(np.float64)
        * ADC_VREF
        / (ADC_FULL_SCALE * FRONTEND_GAIN)
        - ADC_BIAS / FRONTEND_GAIN
    )


def process_signal(input_voltage: np.ndarray) -> np.ndarray:
    converted = adc_roundtrip(input_voltage)
    stage1 = np.convolve(converted, FIR1, mode="full")[
        : len(converted)
    ][::DECIMATION]
    stage2 = (
        np.convolve(stage1, FIR2, mode="full")[: len(stage1)]
        if DECIMATION > 1
        else stage1
    )
    analysis = stage2[WARMUP : WARMUP + FFT_SIZE]
    return analysis - np.mean(analysis)


def analysis_window() -> np.ndarray:
    index = np.arange(FFT_SIZE, dtype=np.float64)
    phase = 2.0 * np.pi * index / (FFT_SIZE - 1)
    return (
        0.35875
        - 0.48829 * np.cos(phase)
        + 0.14128 * np.cos(2.0 * phase)
        - 0.01168 * np.cos(3.0 * phase)
    )


def estimate_tone(samples: np.ndarray, expected_hz: float) -> tuple[float, float]:
    window = analysis_window()
    spectrum = np.fft.rfft(samples * window)
    magnitude_peak = 2.0 * np.abs(spectrum) / np.sum(window)
    frequencies = np.fft.rfftfreq(FFT_SIZE, 1.0 / ANALYSIS_RATE_HZ)
    expected_bin = int(round(expected_hz / ANALYSIS_RATE_HZ * FFT_SIZE))
    search = slice(max(1, expected_bin - 3), min(len(frequencies), expected_bin + 4))
    local_index = int(np.argmax(magnitude_peak[search]))
    peak_index = (search.start or 0) + local_index
    return float(frequencies[peak_index]), float(magnitude_peak[peak_index])


def estimate_amplitude_at_frequency(
    samples: np.ndarray, frequency_hz: float
) -> float:
    window = analysis_window()
    time_s = np.arange(FFT_SIZE, dtype=np.float64) / ANALYSIS_RATE_HZ
    coefficient = np.sum(
        samples
        * window
        * np.exp(-2.0j * np.pi * frequency_hz * time_s)
    )
    return float(2.0 * abs(coefficient) / np.sum(window))


def run_case(name: str, tones: list[tuple[float, float, float]]) -> dict[str, float | str]:
    time_s = np.arange(CAPTURE_COUNT, dtype=np.float64) / ADC_SAMPLE_RATE_HZ
    waveform = np.zeros(CAPTURE_COUNT, dtype=np.float64)
    for frequency_hz, amplitude_peak, phase in tones:
        waveform += amplitude_peak * np.sin(2.0 * np.pi * frequency_hz * time_s + phase)

    analysis = process_signal(waveform)
    expected_hz, expected_peak, _ = tones[0]
    measured_hz, _ = estimate_tone(analysis, expected_hz)
    # The closest FFT bin is intentionally only used for frequency-bin
    # localisation.  Project at the known test tone for the amplitude check,
    # so a longer 16384-point record is not penalised merely because a test
    # tone falls between two bins.
    measured_peak = estimate_amplitude_at_frequency(analysis, expected_hz)
    bin_width = ANALYSIS_RATE_HZ / FFT_SIZE
    frequency_error_bins = abs(measured_hz - expected_hz) / bin_width
    amplitude_error = abs(measured_peak - expected_peak) / expected_peak

    if frequency_error_bins > 1.1:
        raise AssertionError(f"{name}: frequency error {frequency_error_bins:.3f} bins")
    if amplitude_error > 0.08:
        raise AssertionError(f"{name}: amplitude error {amplitude_error:.3%}")

    return {
        "name": name,
        "measured_hz": round(measured_hz, 3),
        "frequency_error_bins": round(frequency_error_bins, 4),
        "measured_peak_v": round(measured_peak, 6),
        "amplitude_error_percent": round(amplitude_error * 100.0, 3),
    }


def simulation_waveform(
    waveform: str,
    fundamental_hz: float,
    fundamental_peak: float,
    harmonic_2_order: int = 0,
    harmonic_2_peak: float = 0.0,
    harmonic_3_order: int = 0,
    harmonic_3_peak: float = 0.0,
    interference_hz: float = 0.0,
    interference_peak: float = 0.0,
) -> np.ndarray:
    time_s = np.arange(CAPTURE_COUNT, dtype=np.float64) / ADC_SAMPLE_RATE_HZ
    base_phase = 2.0 * np.pi * fundamental_hz * time_s
    aligned_phase = base_phase + 0.20
    cycle_fraction = np.mod(aligned_phase / (2.0 * np.pi), 1.0)

    if waveform == "square":
        values = np.where(np.sin(aligned_phase) >= 0.0, 1.0, -1.0)
        values *= fundamental_peak
    elif waveform == "truncated_square":
        values = fundamental_peak * (
            np.sin(aligned_phase)
            + np.sin(3.0 * aligned_phase) / 3.0
            + np.sin(5.0 * aligned_phase) / 5.0
        )
    elif waveform == "triangle":
        values = fundamental_peak * (
            1.0 - 4.0 * np.abs(cycle_fraction - 0.5)
        )
    elif waveform == "sawtooth":
        values = fundamental_peak * (2.0 * cycle_fraction - 1.0)
    elif waveform == "pulse_25":
        values = np.where(
            cycle_fraction < 0.25, fundamental_peak, -fundamental_peak
        )
    elif waveform == "clipped_sine":
        values = fundamental_peak * np.clip(
            1.6 * np.sin(aligned_phase), -1.0, 1.0
        )
    else:
        values = fundamental_peak * np.sin(aligned_phase)
        if waveform == "harmonics":
            values += harmonic_2_peak * np.sin(
                harmonic_2_order * base_phase - 0.35
            )
            values += harmonic_3_peak * np.sin(
                harmonic_3_order * base_phase + 0.55
            )

    if interference_peak > 0.0:
        values += interference_peak * np.sin(
            2.0 * np.pi * interference_hz * time_s + 0.75
        )
    return values


def expected_waveform_fundamental_peak(
    waveform: str, fundamental_peak: float
) -> float:
    if waveform == "square":
        return 4.0 * fundamental_peak / np.pi
    if waveform == "triangle":
        return 8.0 * fundamental_peak / (np.pi * np.pi)
    if waveform == "sawtooth":
        return 2.0 * fundamental_peak / np.pi
    if waveform == "pulse_25":
        return (
            4.0
            * fundamental_peak
            * math.sin(math.pi * 0.25)
            / math.pi
        )
    if waveform == "clipped_sine":
        phase = np.linspace(0.0, 2.0 * np.pi, 1_000_000, endpoint=False)
        normalized = np.clip(1.6 * np.sin(phase), -1.0, 1.0)
        return fundamental_peak * abs(
            2.0 * np.mean(normalized * np.sin(phase))
        )
    return fundamental_peak


def run_simulation_waveform_case(
    name: str,
    waveform: str,
    fundamental_hz: float,
    fundamental_peak: float,
    harmonic_2_order: int = 0,
    harmonic_2_peak: float = 0.0,
    harmonic_3_order: int = 0,
    harmonic_3_peak: float = 0.0,
    interference_hz: float = 0.0,
    interference_peak: float = 0.0,
) -> dict[str, float | str]:
    input_voltage = simulation_waveform(
        waveform,
        fundamental_hz,
        fundamental_peak,
        harmonic_2_order,
        harmonic_2_peak,
        harmonic_3_order,
        harmonic_3_peak,
        interference_hz,
        interference_peak,
    )
    analysis = process_signal(input_voltage)
    measured_hz, _ = estimate_tone(analysis, fundamental_hz)
    measured_peak = estimate_amplitude_at_frequency(
        analysis, fundamental_hz
    )
    expected_peak = expected_waveform_fundamental_peak(
        waveform, fundamental_peak
    )
    bin_width = ANALYSIS_RATE_HZ / FFT_SIZE
    frequency_error_bins = abs(measured_hz - fundamental_hz) / bin_width
    amplitude_error = abs(measured_peak - expected_peak) / expected_peak

    if frequency_error_bins > 1.1:
        raise AssertionError(
            f"{name}: frequency error {frequency_error_bins:.3f} bins"
        )
    if amplitude_error > 0.08:
        raise AssertionError(f"{name}: amplitude error {amplitude_error:.3%}")

    return {
        "name": name,
        "waveform": waveform,
        "measured_hz": round(measured_hz, 3),
        "frequency_error_bins": round(frequency_error_bins, 4),
        "measured_fundamental_peak_v": round(measured_peak, 6),
        "amplitude_error_percent": round(amplitude_error * 100.0, 3),
    }


def run_arbitrary_periodic_case(
    name: str,
    fundamental_hz: float,
    components: list[tuple[int, float, float]],
) -> dict[str, float | str | list[dict[str, float]]]:
    """Verify a periodic waveform defined only by arbitrary Fourier terms.

    This is deliberately not a sine/square/triangle template.  It exercises
    the same linear acquisition and spectrum path with mixed even and odd
    harmonics, unequal amplitudes and unrelated phases.
    """
    time_s = np.arange(CAPTURE_COUNT, dtype=np.float64) / ADC_SAMPLE_RATE_HZ
    waveform = np.zeros(CAPTURE_COUNT, dtype=np.float64)
    measured_components: list[dict[str, float]] = []

    for order, amplitude_peak, phase in components:
        waveform += amplitude_peak * np.sin(
            2.0 * np.pi * (order * fundamental_hz) * time_s + phase
        )

    analysis = process_signal(waveform)
    measured_hz, _ = estimate_tone(analysis, fundamental_hz)
    bin_width = ANALYSIS_RATE_HZ / FFT_SIZE
    frequency_error_bins = abs(measured_hz - fundamental_hz) / bin_width
    if frequency_error_bins > 1.1:
        raise AssertionError(
            f"{name}: fundamental frequency error {frequency_error_bins:.3f} bins"
        )

    for order, expected_peak, _ in components:
        frequency_hz = order * fundamental_hz
        measured_peak = estimate_amplitude_at_frequency(analysis, frequency_hz)
        amplitude_error = abs(measured_peak - expected_peak) / expected_peak
        if amplitude_error > 0.08:
            raise AssertionError(
                f"{name}: component {order} amplitude error {amplitude_error:.3%}"
            )
        measured_components.append(
            {
                "order": float(order),
                "frequency_hz": round(frequency_hz, 3),
                "measured_peak_v": round(measured_peak, 6),
                "amplitude_error_percent": round(amplitude_error * 100.0, 3),
            }
        )

    return {
        "name": name,
        "fundamental_hz": fundamental_hz,
        "frequency_error_bins": round(frequency_error_bins, 4),
        "components": measured_components,
    }


def verify_firmware_fft_decomposition() -> float:
    """Numerically verify the exact two-level real-FFT identity used in C."""

    rng = np.random.default_rng(0x743)
    values = rng.normal(0.0, 1.0, FFT_SIZE)

    def packed_real_fft_8192(samples: np.ndarray) -> np.ndarray:
        packed = samples[0::2] + 1.0j * samples[1::2]
        packed_spectrum = np.fft.fft(packed)
        output = np.empty((len(samples) // 2) + 1, dtype=np.complex128)
        output[0] = packed_spectrum[0].real + packed_spectrum[0].imag
        output[-1] = packed_spectrum[0].real - packed_spectrum[0].imag
        for bin_index in range(1, len(samples) // 2):
            a = packed_spectrum[bin_index]
            b = np.conj(packed_spectrum[len(samples) // 2 - bin_index])
            twiddle = np.exp(-2.0j * np.pi * bin_index / len(samples))
            output[bin_index] = 0.5 * (
                (a + b) - 1.0j * twiddle * (a - b)
            )
        return output

    even_spectrum = packed_real_fft_8192(values[0::2])
    odd_spectrum = packed_real_fft_8192(values[1::2])
    combined = np.empty((FFT_SIZE // 2) + 1, dtype=np.complex128)
    for bin_index in range(FFT_SIZE // 2):
        if bin_index <= FFT_SIZE // 4:
            even_bin = even_spectrum[bin_index]
            odd_bin = odd_spectrum[bin_index]
        else:
            mirror = FFT_SIZE // 2 - bin_index
            even_bin = np.conj(even_spectrum[mirror])
            odd_bin = np.conj(odd_spectrum[mirror])
        combined[bin_index] = even_bin + np.exp(
            -2.0j * np.pi * bin_index / FFT_SIZE
        ) * odd_bin
    combined[-1] = even_spectrum[0] - odd_spectrum[0]

    reference = np.fft.rfft(values)
    maximum_error = float(np.max(np.abs(combined - reference)))
    relative_error = maximum_error / float(np.max(np.abs(reference)))
    if relative_error > 1.0e-12:
        raise AssertionError(
            f"16384-point FFT decomposition error {relative_error:.3e}"
        )
    return relative_error


def main() -> int:
    fft_decomposition_relative_error = verify_firmware_fft_decomposition()
    presets = json.loads(
        (PROJECT_ROOT / "CMakePresets.json").read_text(encoding="utf-8")
    )
    configure_presets = {
        preset["name"]: preset
        for preset in presets["configurePresets"]
        if not preset.get("hidden", False)
    }
    expected_build_modes = {
        "Release": ("OFF", "ON"),
        "SafeExternal": ("OFF", "ON"),
        "Actual": ("OFF", "OFF"),
        "Simulation": ("ON", "ON"),
    }
    for name, (simulation, analog_safe) in expected_build_modes.items():
        cache = configure_presets[name]["cacheVariables"]
        if (
            cache["APP_ADC_SIMULATION_MODE"] != simulation
            or cache["APP_ANALOG_SAFE_MODE"] != analog_safe
        ):
            raise AssertionError(f"CMake preset flags are unsafe: {name}")

    require_text(
        "App/Inc/signal_config.h",
        [
            r"SIGNAL_ADC_SAMPLE_RATE_HZ\s+\(24000000\.0f / 4\.0f\)",
            r"SIGNAL_DECIMATION_FACTOR\s+1U",
        ],
    )
    require_text(
        "App/Inc/signal_fft.h",
        [r"SIGNAL_FFT_SIZE\s+16384U"],
    )
    require_text(
        "Core/Src/adc.c",
        [
            r"ADC_DUALMODE_INTERL",
            r"ADC_DUALMODEDATAFORMAT_32_10_BITS",
            r"ADC_TWOSAMPLINGDELAY_2CYCLES",
            r"ADC_SAMPLETIME_1CYCLE_5",
            r"DMA_REQUEST_ADC1",
            r"DMA_PDATAALIGN_WORD",
            r"DMA_MDATAALIGN_WORD",
            r"GPIO_PIN_6",
            r"PLL2\.PLL2M = 25",
            r"PLL2\.PLL2N = 240",
            r"PLL2\.PLL2P = 5",
            r"PLL2\.PLL2RGE = RCC_PLL2VCIRANGE_0",
            r"ADC_CALIB_OFFSET_LINEARITY",
            r"\bhadc3\b",
            r"MX_ADC3_Init",
            r"ADC_CHANNEL_VREFINT",
            r"ADC_SAMPLETIME_387CYCLES_5",
            r"__HAL_RCC_ADC3_CLK_ENABLE",
        ],
    )
    require_text(
        "Core/Src/main.c",
        [
            r"#define ADC_REFERENCE_NOMINAL_VOLTAGE\s+3\.300F",
            r"VREF_ExternalConfig",
            r"HAL_SYSCFG_DisableVREFBUF",
            r"SYSCFG_VREFBUF_HIGH_IMPEDANCE_ENABLE",
            r"adc_vrefint_millivolts",
            r"adc_reference_voltage",
            r"Equivalent-time phase folding",
            r"sample < SIGNAL_FFT_SIZE",
            r"hmi_fold_weight_buffer",
            r"cycle_count \* \(float\)point",
            r"App_AccumulateCoherentComponents",
            r"App_EstimateFilteredTone",
            r"App_CalculateSeparatedVoltageMetrics",
            r"Vrms = sqrt\(0\.5 \* sum\(A_m\^2\)\)",
            r"APP_RAW_WAVE_METRIC_POINTS 32768U",
            r"APP_MAX_REPORTABLE_HARMONICS 2U",
            r"APP_MEASUREMENT_CAPTURE_COUNT 18U",
            r"APP_MEASUREMENT_TRIM_COUNT 4U",
            r"APP_CALIBRATION_CAPTURE_COUNT 18U",
            r"APP_CALIBRATION_TRIM_COUNT 4U",
            r"APP_COHERENT_MIN_CAPTURE_COUNT 10U",
            r"APP_COHERENT_DETECTION_MIN_AMPLITUDE_VOLTAGE 0\.00075F",
            r"APP_COHERENT_DETECTION_NOISE_MULTIPLIER 4\.0F",
            r"APP_REPORTABLE_COMPONENT_MIN_AMPLITUDE_VOLTAGE 0\.0020F",
            r"APP_COHERENT_MIN_PHASE_COHERENCE 0\.40F",
            r"coherent_harmonic_amplitude_sum",
            r"coherent_harmonic_evidence_count",
            r"APP_FRONTEND_CORRECTION_100KHZ 1\.084735F",
            r"APP_FRONTEND_CORRECTION_526KHZ 0\.978033F",
            r"App_GetFrontendAmplitudeCorrection",
            r"Draw only the same confirmed components",
            r"coherent_harmonic_sine_sum",
            r"phi_m-m\*phi_1",
            r'#define HMI_HARMONIC_1_FREQUENCY_ADDRESS\s+"x4\.val"',
            r'#define HMI_HARMONIC_1_AMPLITUDE_ADDRESS\s+"x5\.val"',
            r'#define HMI_HARMONIC_2_FREQUENCY_ADDRESS\s+"x6\.val"',
            r'#define HMI_HARMONIC_2_AMPLITUDE_ADDRESS\s+"x7\.val"',
            r"App_GetSeparatedHarmonic\(\s*0U,",
            r"App_GetSeparatedHarmonic\(\s*1U,",
            r"HMI_send_float\(\s*HMI_HARMONIC_1_FREQUENCY_ADDRESS,",
            r"HMI_send_float\(\s*HMI_HARMONIC_1_AMPLITUDE_ADDRESS,",
            r"HMI_send_float\(\s*HMI_HARMONIC_2_FREQUENCY_ADDRESS,",
            r"HMI_send_float\(\s*HMI_HARMONIC_2_AMPLITUDE_ADDRESS,",
            r"MX_USART2_UART_Init",
            r"section\(\"\.dma_buffer(?:\.adc)?\"\)",
            r"RCC_PERIPHCLK_ADC\) != 48000000U",
            r"device_revision_id != REV_ID_V",
            r"HAL_RCC_GetHCLKFreq\(\) != 240000000U",
            r"RCC_PLLSOURCE_HSE",
            r"FLASH_LATENCY_4",
            r"HAL_EnableCompensationCell",
            r"ADC_SIMULATION_TRIANGLE",
            r"ADC_SIMULATION_SAWTOOTH",
            r"ADC_SIMULATION_PULSE_25",
            r"ADC_SIMULATION_CLIPPED_SINE",
            r"ADC_Capture_Stop",
            r"#define APP_ANALOG_SAFE_MODE 1U",
        ],
    )
    require_text(
        "App/Src/signal_fft.c",
        [
            r"best_match_count",
            r"weight \* order \* result->peaks\[peak\]\.frequency_hz",
            r"result->voltage_peak_to_peak = result->input_peak_to_peak",
            r"all other real peaks remain in the result unchanged",
        ],
    )
    forbid_text(
        "Core/Src/main.c",
        [
            r"HAL_SYSCFG_EnableVREFBUF",
            r"SYSCFG_VREFBUF_VOLTAGE_SCALE",
            r"SYSCFG_VREFBUF_HIGH_IMPEDANCE_DISABLE",
            r"ADC_CalibrateExternalReference",
            r"ADC3_ReadVrefMillivolts",
        ],
    )
    require_text(
        "Core/Src/usart.c",
        [r"USART2", r"BaudRate = 115200", r"GPIO_PIN_2\|GPIO_PIN_3"],
    )
    require_text(
        "Core/Src/stm32h7xx_it.c",
        [
            r"void DMA1_Stream0_IRQHandler\(void\)",
            r"HAL_DMA_IRQHandler\(&hdma_adc1\)",
        ],
    )
    require_text(
        "STM32H743xG_flash.ld",
        [r"\.dma_buffer \(NOLOAD\)", r">RAM_D2", r"\.ccmram \(NOLOAD\)", r">RAM"],
    )
    require_text(
        "26G.ioc",
        [
            r"USART2\.BaudRate=115200",
            r"RCC\.ADCFreq_Value=24000000",
            r"RCC\.HCLKFreq_Value=240000000",
        ],
    )
    forbid_text(
        "26G.ioc",
        [
            r"LSE-External-Oscillator",
            r"\bADC3\.",
            r"VP_ADC3_Vref_Input",
            r"Mcu\.IP[0-9]+=ADC3",
            r"\bDAC1\.",
            r"Dma\.DAC1_CH1",
            r"\bTIM6\.",
            r"VP_TIM6",
            r"PC13\.",
        ],
    )
    require_text(
        "cmake/gcc-arm-none-eabi.cmake",
        [r'CMAKE_C_FLAGS_RELEASE "-O3 -g0 -flto"', r'CMAKE_EXE_LINKER_FLAGS_RELEASE "-flto"'],
    )
    require_text(
        "CMakeLists.txt",
        [
            r"option\(APP_ANALOG_SAFE_MODE",
            r"external VREF\+/VDDA wiring is confirmed",
        ],
    )
    forbid_text(
        "CMakeLists.txt",
        [
            r"APP_WAVE_OUTPUT_ENABLE",
            r"APP_CONTEST_START_BUTTON_ENABLE",
            r"wave_output\.c",
            r"contest_start_button\.c",
            r"contest_separator\.c",
        ],
    )

    if ADC_SAMPLE_RATE_HZ < 6_000_000.0:
        raise AssertionError("combined ADC rate is below 6 MSPS")
    if ADC_CLOCK_HZ > 35_000_000.0:
        raise AssertionError(
            "ADC clock exceeds the AN5354 LQFP100 12-bit two-ADC limit"
        )
    if not math.isclose(
        ADC_SAMPLE_TIME_CYCLES + ADC_PROGRAMMED_DELAY_CYCLES,
        INTERLEAVE_PHASE_CYCLES,
        rel_tol=0.0,
        abs_tol=1e-12,
    ):
        raise AssertionError(
            "interleaved sample starts are not uniformly spaced"
        )
    if not math.isclose(
        2.0 * INTERLEAVE_PHASE_CYCLES,
        ADC_CONVERSION_CYCLES,
        rel_tol=0.0,
        abs_tol=1e-12,
    ):
        raise AssertionError(
            "dual-interleave phase spacing does not match the 12-bit "
            "conversion period"
        )
    if ADC_SAMPLE_RATE_HZ * 0.5 > 3_890_000.0:
        raise AssertionError(
            "per-ADC rate exceeds the AN5354 LQFP100 12-bit fast-channel "
            "dual-mode limit"
        )
    if ANALYSIS_RATE_HZ * 0.5 <= 600_000.0:
        raise AssertionError("analysis Nyquist frequency does not cover 600 kHz")

    composite_600khz_db = fir_response_db(
        FIR1, 600_000.0, ADC_SAMPLE_RATE_HZ
    )
    if DECIMATION > 1:
        composite_600khz_db += fir_response_db(
            FIR2, 600_000.0, ANALYSIS_RATE_HZ
        )
    fir1_1mhz_db = fir_response_db(FIR1, 1_000_000.0, ADC_SAMPLE_RATE_HZ)
    fir1_1_2mhz_db = fir_response_db(FIR1, 1_200_000.0, ADC_SAMPLE_RATE_HZ)
    if composite_600khz_db < -0.1:
        raise AssertionError("composite FIR loss at 600 kHz exceeds 0.1 dB")
    if max(fir1_1mhz_db, fir1_1_2mhz_db) > -80.0:
        raise AssertionError("pre-decimation FIR stopband attenuation is below 80 dB")

    cases = [
        run_case("100kHz_250mVpp", [(100_000.0, 0.125, 0.2)]),
        run_case("10kHz_50mVpp", [(10_000.0, 0.025, -0.4)]),
        run_case("600kHz_250mVpp", [(600_000.0, 0.125, 0.7)]),
        run_case(
            "100kHz_harmonics_and_1.2MHz_interference",
            [
                (100_000.0, 0.05, 0.2),
                (200_000.0, 0.02, -0.35),
                (300_000.0, 0.01, 0.55),
                (1_200_000.0, 0.10, 0.75),
            ],
        ),
    ]
    source_simulation_cases = [
        run_simulation_waveform_case(
            "source_01_sine_100k", "sine", 100_000.0, 0.1250
        ),
        run_simulation_waveform_case(
            "source_02_square_100k", "square", 100_000.0, 0.1250
        ),
        run_simulation_waveform_case(
            "source_03_square_200k", "square", 200_000.0, 0.1250
        ),
        run_simulation_waveform_case(
            "source_04_square_400k", "square", 400_000.0, 0.1250
        ),
        run_simulation_waveform_case(
            "source_05_square_500k", "square", 500_000.0, 0.1250
        ),
        run_simulation_waveform_case(
            "source_06_harmonics_10k5",
            "harmonics",
            10_500.0,
            0.0500,
            3,
            0.0200,
            4,
            0.0100,
        ),
        run_simulation_waveform_case(
            "source_07_sine_550k", "sine", 550_000.0, 0.1000
        ),
        run_simulation_waveform_case(
            "source_08_interference_1m2",
            "harmonics",
            100_000.0,
            0.0500,
            2,
            0.0200,
            3,
            0.0100,
            1_200_000.0,
            0.1000,
        ),
        run_simulation_waveform_case(
            "source_09_sine_10k", "sine", 10_000.0, 0.0250
        ),
        run_simulation_waveform_case(
            "source_10_sine_200k", "sine", 200_000.0, 0.1250
        ),
        run_simulation_waveform_case(
            "source_11_sine_500k_small", "sine", 500_000.0, 0.0250
        ),
        run_simulation_waveform_case(
            "source_12_sine_500k_large", "sine", 500_000.0, 0.1250
        ),
        run_simulation_waveform_case(
            "source_13_sine_599k", "sine", 599_000.0, 0.1250
        ),
        run_simulation_waveform_case(
            "source_14_third_harmonic_regression",
            "harmonics",
            100_000.0,
            0.0500,
            3,
            0.0200,
        ),
        run_simulation_waveform_case(
            "source_15_upper_band_phase",
            "harmonics",
            200_000.0,
            0.0500,
            2,
            0.0200,
            3,
            0.0100,
        ),
        run_simulation_waveform_case(
            "source_16_truncated_square",
            "truncated_square",
            100_000.0,
            0.0600,
        ),
        run_simulation_waveform_case(
            "source_17_triangle", "triangle", 100_000.0, 0.1250
        ),
        run_simulation_waveform_case(
            "source_18_sawtooth", "sawtooth", 80_000.0, 0.1000
        ),
        run_simulation_waveform_case(
            "source_19_pulse_25", "pulse_25", 60_000.0, 0.1000
        ),
        run_simulation_waveform_case(
            "source_20_clipped_sine",
            "clipped_sine",
            120_000.0,
            0.1000,
        ),
        run_simulation_waveform_case(
            "source_21_asymmetric_phase",
            "harmonics",
            75_000.0,
            0.0700,
            2,
            0.0250,
            5,
            0.0120,
        ),
    ]
    arbitrary_periodic_cases = [
        run_arbitrary_periodic_case(
            "arbitrary_periodic_mixed_37k5",
            37_500.0,
            [
                (1, 0.083, 0.17),
                (2, 0.031, -1.11),
                (3, 0.052, 2.43),
                (5, 0.019, -2.01),
                (6, 0.011, 0.74),
            ],
        ),
        run_arbitrary_periodic_case(
            "arbitrary_periodic_mixed_83k",
            83_000.0,
            [
                (1, 0.071, -0.63),
                (2, 0.028, 1.88),
                (4, 0.041, -2.47),
                (5, 0.014, 0.36),
            ],
        ),
    ]

    report = {
        "status": "PASS",
        "adc_clock_hz": ADC_CLOCK_HZ,
        "adc_conversion_cycles": ADC_CONVERSION_CYCLES,
        "interleave_phase_cycles": INTERLEAVE_PHASE_CYCLES,
        "programmed_delay_after_sampling_cycles": ADC_PROGRAMMED_DELAY_CYCLES,
        "dual_interleaved_rate_hz": round(ADC_SAMPLE_RATE_HZ, 3),
        "per_adc_rate_hz": round(ADC_SAMPLE_RATE_HZ * 0.5, 3),
        "dma_word_rate_hz": round(ADC_SAMPLE_RATE_HZ * 0.5, 3),
        "dma_bandwidth_bytes_per_second": round(
            DMA_BANDWIDTH_BYTES_PER_SECOND, 3
        ),
        "dma_capture_bytes": DMA_BYTE_COUNT,
        "capture_duration_ms": round(CAPTURE_DURATION_SECONDS * 1000.0, 6),
        "expected_half_buffer_cpu_cycles": round(HALF_BUFFER_CPU_CYCLES, 3),
        "analysis_rate_hz": round(ANALYSIS_RATE_HZ, 3),
        "analysis_nyquist_hz": round(ANALYSIS_RATE_HZ * 0.5, 3),
        "fft_bin_width_hz": round(ANALYSIS_RATE_HZ / FFT_SIZE, 6),
        "fft_record_duration_ms": round(
            FFT_SIZE / ANALYSIS_RATE_HZ * 1000.0, 6
        ),
        "fft_decomposition_relative_error": fft_decomposition_relative_error,
        "composite_fir_gain_600khz_db": round(composite_600khz_db, 6),
        "fir1_attenuation_1mhz_db": round(fir1_1mhz_db, 3),
        "fir1_attenuation_1_2mhz_db": round(fir1_1_2mhz_db, 3),
        "capture_samples": CAPTURE_COUNT,
        "vref_v": ADC_VREF,
        "frontend_input_range_v": [
            round(INPUT_MIN_V, 6),
            round(INPUT_MAX_V, 6),
        ],
        "cases": cases,
        "source_simulation_cases": source_simulation_cases,
        "arbitrary_periodic_cases": arbitrary_periodic_cases,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False))
        raise
