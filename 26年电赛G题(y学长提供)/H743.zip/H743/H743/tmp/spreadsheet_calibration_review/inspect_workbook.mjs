import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const inputPath = process.env.INPUT_XLSX;
const outputDir = process.env.OUTPUT_DIR;

if (!inputPath || !outputDir) {
  throw new Error("INPUT_XLSX and OUTPUT_DIR are required");
}

await fs.mkdir(outputDir, { recursive: true });
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(inputPath));

const summary = await workbook.inspect({
  kind: "workbook,sheet,table",
  maxChars: 12000,
  tableMaxRows: 12,
  tableMaxCols: 24,
  tableMaxCellChars: 120,
});
console.log("SUMMARY_BEGIN");
console.log(summary.ndjson);
console.log("SUMMARY_END");

for (const sheet of workbook.worksheets.items) {
  const used = sheet.getUsedRange(true);
  if (!used) continue;

  const region = await workbook.inspect({
    kind: "region",
    sheetId: sheet.name,
    range: used.address,
    maxChars: 30000,
    tableMaxRows: 120,
    tableMaxCols: 30,
    tableMaxCellChars: 160,
  });
  console.log(`SHEET_BEGIN ${sheet.name} ${used.address}`);
  console.log(region.ndjson);
  console.log(`SHEET_END ${sheet.name}`);

  const safeName = sheet.name.replace(/[\\/:*?"<>|]/g, "_");
  const preview = await workbook.render({
    sheetName: sheet.name,
    autoCrop: "all",
    scale: 1.5,
    format: "png",
  });
  await fs.writeFile(
    path.join(outputDir, `${safeName}.png`),
    new Uint8Array(await preview.arrayBuffer()),
  );
}
