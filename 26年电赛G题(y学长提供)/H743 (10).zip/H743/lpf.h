#ifndef LPF_H
#define LPF_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#include "arm_math.h"

#define LPF_MAX_ORDER   8U
#define LPF_MAX_STAGES  (LPF_MAX_ORDER / 2U)

typedef enum
{
  LPF_OK = 0,
  LPF_BAD_ARGUMENT,
  LPF_BAD_FREQUENCY,
  LPF_BAD_ORDER
} LPF_Status;

/*
 * Floating-point Butterworth low-pass filter implemented with the CMSIS-DSP
 * transposed direct-form II biquad cascade.
 *
 * The object owns its coefficients and states. Do not copy an initialized
 * object because the CMSIS instance contains pointers into this object.
 */
typedef struct
{
  arm_biquad_cascade_df2T_instance_f32 cmsis;
  float32_t coefficients[5U * LPF_MAX_STAGES];
  float32_t states[2U * LPF_MAX_STAGES];
  float32_t sample_rate_hz;
  float32_t cutoff_hz;
  uint8_t order;
  uint8_t stage_count;
  uint8_t initialized;
} LPF_Handle;

/*
 * Designs a digital Butterworth low-pass filter at runtime.
 * Supported orders are 2, 4, 6, and 8.
 */
LPF_Status LPF_Init(LPF_Handle *filter,
                    float32_t sample_rate_hz,
                    float32_t cutoff_hz,
                    uint8_t order);

/* Clears the streaming states without changing the filter coefficients. */
void LPF_Reset(LPF_Handle *filter);

/*
 * Processes one block. Input and output may point to the same buffer.
 * Consecutive calls retain filter state for continuous DMA blocks.
 */
LPF_Status LPF_Process(LPF_Handle *filter,
                      const float32_t *input,
                      float32_t *output,
                      uint32_t sample_count);

/* Returns the linear voltage gain at a requested frequency. */
float32_t LPF_GetGain(const LPF_Handle *filter, float32_t frequency_hz);

#ifdef __cplusplus
}
#endif

#endif
