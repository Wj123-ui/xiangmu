/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    adc.c
  * @brief   ADC1/ADC2 dual-interleaved acquisition on PA6.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

#include "adc.h"

ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
ADC_HandleTypeDef hadc3;
DMA_HandleTypeDef hdma_adc1;
static uint8_t adc_kernel_clock_configured;

HAL_StatusTypeDef ADC12_ResetInterleavedMode(void)
{
  ADC_MultiModeTypeDef multimode = {0};

  /* RM0433 requires the common dual-ADC sequencer to be returned to
   * independent mode after an interleaved sequence is interrupted.  Each
   * application frame deliberately stops DMA, so reset the common sequencer
   * before arming the next frame. */
  multimode.Mode = ADC_MODE_INDEPENDENT;
  multimode.DualModeData = ADC_DUALMODEDATAFORMAT_DISABLED;
  multimode.TwoSamplingDelay = ADC_TWOSAMPLINGDELAY_1CYCLE;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
  {
    return HAL_ERROR;
  }

  multimode.Mode = ADC_DUALMODE_INTERL;
  multimode.DualModeData = ADC_DUALMODEDATAFORMAT_32_10_BITS;
  multimode.TwoSamplingDelay = ADC_TWOSAMPLINGDELAY_2CYCLES;
  return HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode);
}

HAL_StatusTypeDef ADC12_SetInterleavedSampleRate(uint32_t sample_rate_hz)
{
  RCC_PeriphCLKInitTypeDef clock = {0};
  uint32_t pll2_n;
  uint32_t expected_adc_source_hz;

  /* The common ADC clock must never be changed while either converter is
   * enabled.  The caller stops multimode DMA before entering this function. */
  if (((ADC1->CR & ADC_CR_ADEN) != 0U) ||
      ((ADC2->CR & ADC_CR_ADEN) != 0U))
  {
    return HAL_BUSY;
  }

  if (sample_rate_hz == 6000000U)
  {
    pll2_n = 240U;
    expected_adc_source_hz = 48000000U;
  }
  else if (sample_rate_hz == 4800000U)
  {
    pll2_n = 192U;
    expected_adc_source_hz = 38400000U;
  }
  else
  {
    return HAL_ERROR;
  }

  /* HSE/25 = 1 MHz; PLL2N is 240 or 192 and PLL2P is five.  Rev.V then
   * applies its fixed ADC /2 path, leaving a 24 or 19.2 MHz converter clock.
   * The uniform four-clock interleave therefore produces 6.0 or 4.8 MSPS. */
  clock.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  clock.PLL2.PLL2M = 25U;
  clock.PLL2.PLL2N = pll2_n;
  clock.PLL2.PLL2P = 5U;
  clock.PLL2.PLL2Q = 5U;
  clock.PLL2.PLL2R = 5U;
  clock.PLL2.PLL2RGE = RCC_PLL2VCIRANGE_0;
  clock.PLL2.PLL2VCOSEL = RCC_PLL2VCOWIDE;
  clock.PLL2.PLL2FRACN = 0.0;
  clock.AdcClockSelection = RCC_ADCCLKSOURCE_PLL2;

  if (HAL_RCCEx_PeriphCLKConfig(&clock) != HAL_OK)
  {
    return HAL_ERROR;
  }

  if (HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_ADC) !=
      expected_adc_source_hz)
  {
    return HAL_ERROR;
  }

  return ADC12_ResetInterleavedMode();
}

static void ADC_InitChannel3(ADC_HandleTypeDef *hadc,
                             ADC_TypeDef *instance,
                             FunctionalState continuous_mode)
{
  ADC_ChannelConfTypeDef sConfig = {0};

  hadc->Instance = instance;
  hadc->Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc->Init.Resolution = ADC_RESOLUTION_12B;
  hadc->Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc->Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc->Init.LowPowerAutoWait = DISABLE;
  hadc->Init.ContinuousConvMode = continuous_mode;
  hadc->Init.NbrOfConversion = 1;
  hadc->Init.DiscontinuousConvMode = DISABLE;
  hadc->Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc->Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc->Init.ConversionDataManagement =
      ADC_CONVERSIONDATA_DMA_CIRCULAR;
  hadc->Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  hadc->Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
  hadc->Init.OversamplingMode = DISABLE;

  if (HAL_ADC_Init(hadc) != HAL_OK)
  {
    Error_Handler();
  }

  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  sConfig.OffsetSignedSaturation = DISABLE;

  if (HAL_ADC_ConfigChannel(hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

void MX_ADC2_Init(void)
{
  /* The slave is triggered by ADC1 through the ADC12 common block. */
  ADC_InitChannel3(&hadc2, ADC2, DISABLE);
}

void MX_ADC1_Init(void)
{
  ADC_InitChannel3(&hadc1, ADC1, ENABLE);

  /*
   * Calibrate both converters while disabled.  Offset + linearity
   * calibration is the H7 equivalent of the F407's fixed ADC trim.
   */
  if (HAL_ADCEx_Calibration_Start(
          &hadc1,
          ADC_CALIB_OFFSET_LINEARITY,
          ADC_SINGLE_ENDED) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_ADCEx_Calibration_Start(
          &hadc2,
          ADC_CALIB_OFFSET_LINEARITY,
          ADC_SINGLE_ENDED) != HAL_OK)
  {
    Error_Handler();
  }

  /*
   * In H7 interleaved mode, DELAY begins after the master sampling phase.
   * With 1.5-cycle sampling and a 2.5-cycle DELAY, each conversion starts
   * four ADC clocks after the preceding one.  A 12-bit conversion occupies
   * eight clocks, so ADC1/ADC2 sample at uniformly spaced 4-clock intervals:
   * 24 MHz / 4 = 6 MSPS combined; each ADC runs at 3 MSPS.
   * This keeps PA6 below the AN5354 LQFP100 12-bit fast-channel dual-ADC
   * limit of 3.89 MSPS per converter and avoids deterministic interleave
   * images from unequal 7/2-clock sample spacing.
   */
  if (ADC12_ResetInterleavedMode() != HAL_OK)
  {
    Error_Handler();
  }
}

void MX_ADC3_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};

  /*
   * ADC3 is deliberately independent of the ADC1/ADC2 interleaved pair.
   * It takes a short startup-only VREFINT measurement so voltage conversion
   * follows the actual voltage on VREF+ (PA20), rather than assuming 3.300 V.
   */
  hadc3.Instance = ADC3;
  hadc3.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;
  hadc3.Init.Resolution = ADC_RESOLUTION_12B;
  hadc3.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc3.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc3.Init.LowPowerAutoWait = DISABLE;
  hadc3.Init.ContinuousConvMode = DISABLE;
  hadc3.Init.NbrOfConversion = 1;
  hadc3.Init.DiscontinuousConvMode = DISABLE;
  hadc3.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc3.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc3.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DR;
  hadc3.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc3.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
  hadc3.Init.OversamplingMode = DISABLE;

  if (HAL_ADC_Init(&hadc3) != HAL_OK)
  {
    Error_Handler();
  }

  sConfig.Channel = ADC_CHANNEL_VREFINT;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_387CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  sConfig.OffsetSignedSaturation = DISABLE;

  if (HAL_ADC_ConfigChannel(&hadc3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

void HAL_ADC_MspInit(ADC_HandleTypeDef *adcHandle)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  if ((adcHandle->Instance != ADC1) &&
      (adcHandle->Instance != ADC2) &&
      (adcHandle->Instance != ADC3))
  {
    return;
  }

  if (adc_kernel_clock_configured == 0U)
  {
    /*
     * HSE = 25 MHz, PLL2 input = 1 MHz and VCO = 240 MHz.
     * The required Rev.V silicon has a fixed /2 in the ADC path, so a
     * 48 MHz PLL2P source runs the converters at an effective 24 MHz.
     */
    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_ADC;
    PeriphClkInitStruct.PLL2.PLL2M = 25;
    PeriphClkInitStruct.PLL2.PLL2N = 240;
    PeriphClkInitStruct.PLL2.PLL2P = 5;
    PeriphClkInitStruct.PLL2.PLL2Q = 5;
    PeriphClkInitStruct.PLL2.PLL2R = 5;
    PeriphClkInitStruct.PLL2.PLL2RGE = RCC_PLL2VCIRANGE_0;
    PeriphClkInitStruct.PLL2.PLL2VCOSEL = RCC_PLL2VCOWIDE;
    PeriphClkInitStruct.PLL2.PLL2FRACN = 0.0;
    PeriphClkInitStruct.AdcClockSelection = RCC_ADCCLKSOURCE_PLL2;

    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
    {
      Error_Handler();
    }

    adc_kernel_clock_configured = 1U;
  }

  if (adcHandle->Instance == ADC3)
  {
    __HAL_RCC_ADC3_CLK_ENABLE();
    return;
  }

  __HAL_RCC_ADC12_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*
   * PA6 is ADC12_INP3 on STM32H743VGT6, so both ADC1 and ADC2 sample
   * the same physical input in interleaved mode.
   */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  if (adcHandle->Instance == ADC1)
  {
    hdma_adc1.Instance = DMA1_Stream0;
    hdma_adc1.Init.Request = DMA_REQUEST_ADC1;
    hdma_adc1.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc1.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_adc1.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    hdma_adc1.Init.Mode = DMA_CIRCULAR;
    hdma_adc1.Init.Priority = DMA_PRIORITY_VERY_HIGH;
    hdma_adc1.Init.FIFOMode = DMA_FIFOMODE_DISABLE;

    if (HAL_DMA_Init(&hdma_adc1) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(adcHandle, DMA_Handle, hdma_adc1);

    HAL_NVIC_SetPriority(ADC_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(ADC_IRQn);
  }
}

void HAL_ADC_MspDeInit(ADC_HandleTypeDef *adcHandle)
{
  if ((adcHandle->Instance != ADC1) &&
      (adcHandle->Instance != ADC2) &&
      (adcHandle->Instance != ADC3))
  {
    return;
  }

  if (adcHandle->Instance == ADC3)
  {
    __HAL_RCC_ADC3_CLK_DISABLE();
    return;
  }

  if (adcHandle->Instance == ADC1)
  {
    HAL_DMA_DeInit(adcHandle->DMA_Handle);
    HAL_NVIC_DisableIRQ(ADC_IRQn);
  }

  HAL_GPIO_DeInit(GPIOA, GPIO_PIN_6);
}
