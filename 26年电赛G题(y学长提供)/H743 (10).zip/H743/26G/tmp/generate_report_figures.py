import cmath
import html
import json
import math
from pathlib import Path


ROOT = Path(r"C:\Users\yqh\Desktop\H743\26G")
DATA_PATH = ROOT / "tmp" / "simulation_plot_data_1024.json"
OUTPUT_DIR = ROOT / "docs" / "report-assets"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

report = json.loads(DATA_PATH.read_text(encoding="utf-8"))
selected_names = [
    "harmonics_10k5",
    "g_83k_h2_h4",
    "g_160k_h2_h3",
    "g_interference_50k_h3_h7",
]
selected = {
    item["name"]: item
    for item in report["results"]
    if item["name"] in selected_names
}
titles = {
    "harmonics_10k5": "10.5 kHz + 3/4次谐波",
    "g_83k_h2_h4": "83 kHz + 2/4次谐波（4次最强）",
    "g_160k_h2_h3": "160 kHz + 2/3次谐波（2次最强）",
    "g_interference_50k_h3_h7":
        "50 kHz + 3/7次谐波 + 1.05 MHz干扰",
}


def svg_document(width, height, title, content):
    escaped_title = html.escape(title)
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
<title>{escaped_title}</title>
<style>
text {{ font-family: "Microsoft YaHei", "SimHei", sans-serif; fill: #20252b; }}
.title {{ font-size: 22px; font-weight: 600; }}
.panel-title {{ font-size: 15px; font-weight: 600; }}
.axis-label {{ font-size: 12px; fill: #4b5563; }}
.note {{ font-size: 11px; fill: #4b5563; }}
.grid {{ stroke: #d7dce2; stroke-width: 1; }}
.axis {{ stroke: #69727d; stroke-width: 1.2; }}
.expected {{ fill: none; stroke: #1479d1; stroke-width: 1.8; stroke-dasharray: 7 5; }}
.actual {{ fill: none; stroke: #e45a2a; stroke-width: 1.35; }}
.spectrum {{ fill: none; stroke: #168a5b; stroke-width: 1.4; }}
.peak {{ stroke: #d73a49; stroke-width: 1.2; stroke-dasharray: 5 4; }}
.filter1 {{ fill: none; stroke: #1479d1; stroke-width: 1.8; }}
.filter2 {{ fill: none; stroke: #e45a2a; stroke-width: 1.8; }}
</style>
<rect width="100%" height="100%" fill="#ffffff"/>
<text x="{width / 2:.1f}" y="31" text-anchor="middle" class="title">{escaped_title}</text>
{content}
</svg>
"""


def expected_display(item, cycles):
    components = item["expected_wave_components"]
    point_count = len(item["one_cycle_points"])
    voltage = []
    for point in range(point_count):
        base_phase = (
            2.0 * math.pi * cycles * point / (point_count - 1)
        )
        value = 0.0
        for component in components:
            value += component["Amplitude"] * math.sin(
                component["Order"] * base_phase + component["Phase"]
            )
        voltage.append(value)
    minimum = min(voltage)
    maximum = max(voltage)
    return [
        5.0 + round((value - minimum) * 170.0 /
                    (maximum - minimum))
        for value in voltage
    ]


def path_data(values, x, y, width, height, minimum, maximum):
    points = []
    count = len(values)
    span = maximum - minimum
    for index, value in enumerate(values):
        px = x + index * width / (count - 1)
        py = y + height - (value - minimum) * height / span
        command = "M" if index == 0 else "L"
        points.append(f"{command}{px:.2f},{py:.2f}")
    return " ".join(points)


def chart_axes(x, y, width, height, x_ticks, y_ticks,
               x_min, x_max, y_min, y_max, x_label, y_label):
    parts = []
    for tick in y_ticks:
        py = y + height - (tick - y_min) * height / (y_max - y_min)
        parts.append(
            f'<line x1="{x}" y1="{py:.2f}" x2="{x + width}" '
            f'y2="{py:.2f}" class="grid"/>'
        )
        parts.append(
            f'<text x="{x - 8}" y="{py + 4:.2f}" text-anchor="end" '
            f'class="axis-label">{html.escape(str(tick))}</text>'
        )
    for tick, label in x_ticks:
        px = x + (tick - x_min) * width / (x_max - x_min)
        parts.append(
            f'<line x1="{px:.2f}" y1="{y}" x2="{px:.2f}" '
            f'y2="{y + height}" class="grid"/>'
        )
        parts.append(
            f'<text x="{px:.2f}" y="{y + height + 18}" '
            f'text-anchor="middle" class="axis-label">'
            f'{html.escape(label)}</text>'
        )
    parts.append(
        f'<line x1="{x}" y1="{y + height}" x2="{x + width}" '
        f'y2="{y + height}" class="axis"/>'
    )
    parts.append(
        f'<line x1="{x}" y1="{y}" x2="{x}" '
        f'y2="{y + height}" class="axis"/>'
    )
    parts.append(
        f'<text x="{x + width / 2:.2f}" y="{y + height + 38}" '
        f'text-anchor="middle" class="axis-label">'
        f'{html.escape(x_label)}</text>'
    )
    parts.append(
        f'<text x="{x - 42}" y="{y + height / 2:.2f}" '
        f'transform="rotate(-90 {x - 42} {y + height / 2:.2f})" '
        f'text-anchor="middle" class="axis-label">'
        f'{html.escape(y_label)}</text>'
    )
    return "\n".join(parts)


def waveform_panel(item, title, panel_x, panel_y,
                   panel_width, panel_height, cycles, actual_key):
    plot_x = panel_x + 58
    plot_y = panel_y + 27
    plot_width = panel_width - 76
    plot_height = panel_height - 77
    actual = item[actual_key]
    expected = expected_display(item, cycles)
    x_ticks = [
        (cycles * fraction,
         f"{cycles * fraction:g}")
        for fraction in (0.0, 0.25, 0.5, 0.75, 1.0)
    ]
    parts = [
        f'<text x="{panel_x + panel_width / 2:.2f}" '
        f'y="{panel_y + 17}" text-anchor="middle" '
        f'class="panel-title">{html.escape(title)}</text>',
        chart_axes(
            plot_x, plot_y, plot_width, plot_height,
            x_ticks, [5, 90, 175],
            0.0, float(cycles), 0.0, 180.0,
            "周期位置", "HMI波形值",
        ),
        f'<path d="{path_data(expected, plot_x, plot_y, plot_width, plot_height, 0.0, 180.0)}" class="expected"/>',
        f'<path d="{path_data(actual, plot_x, plot_y, plot_width, plot_height, 0.0, 180.0)}" class="actual"/>',
        f'<text x="{plot_x + plot_width - 4}" '
        f'y="{plot_y + plot_height - 7}" text-anchor="end" '
        f'class="note">平均误差 '
        f'{item["one_cycle_shape_mean_error" if cycles == 1 else "three_cycle_shape_mean_error"]:.2f}/180</text>',
    ]
    return "\n".join(parts)


content = []
panel_width = 570
panel_height = 310
for index, name in enumerate(selected_names):
    row = index // 2
    column = index % 2
    content.append(waveform_panel(
        selected[name],
        titles[name],
        12 + column * panel_width,
        48 + row * panel_height,
        panel_width - 8,
        panel_height - 8,
        1,
        "one_cycle_points",
    ))
content.append(
    '<line x1="28" y1="680" x2="64" y2="680" class="expected"/>'
    '<text x="72" y="684" class="axis-label">理论输入</text>'
    '<line x1="160" y1="680" x2="196" y2="680" class="actual"/>'
    '<text x="204" y="684" class="axis-label">MCU串口返回</text>'
)
(OUTPUT_DIR / "waveform-one-cycle.svg").write_text(
    svg_document(1140, 700,
                 "1024点单周期输入波形与MCU输出波形对比",
                 "\n".join(content)),
    encoding="utf-8",
)


content = []
three_names = ["harmonics_10k5", "g_interference_50k_h3_h7"]
for index, name in enumerate(three_names):
    content.append(waveform_panel(
        selected[name],
        titles[name],
        18,
        48 + index * 315,
        1100,
        300,
        3,
        "three_cycle_points",
    ))
content.append(
    '<line x1="28" y1="680" x2="64" y2="680" class="expected"/>'
    '<text x="72" y="684" class="axis-label">理论输入</text>'
    '<line x1="160" y1="680" x2="196" y2="680" class="actual"/>'
    '<text x="204" y="684" class="axis-label">MCU串口返回</text>'
)
(OUTPUT_DIR / "waveform-three-cycle.svg").write_text(
    svg_document(1140, 700,
                 "1024点三周期输入波形与MCU输出波形对比",
                 "\n".join(content)),
    encoding="utf-8",
)


content = []
for index, name in enumerate(selected_names):
    item = selected[name]
    row = index // 2
    column = index % 2
    panel_x = 12 + column * panel_width
    panel_y = 48 + row * 325
    plot_x = panel_x + 58
    plot_y = panel_y + 27
    plot_width = panel_width - 80
    plot_height = 215
    spectrum = item["spectrum_points"]
    content.append(
        f'<text x="{panel_x + panel_width / 2:.2f}" '
        f'y="{panel_y + 17}" text-anchor="middle" '
        f'class="panel-title">{html.escape(titles[name])}</text>'
    )
    content.append(chart_axes(
        plot_x, plot_y, plot_width, plot_height,
        [(10, "10"), (100, "100"), (200, "200"),
         (300, "300"), (400, "400"), (500, "500"),
         (600, "600")],
        [5, 90, 175],
        10.0, 600.0, 0.0, 180.0,
        "频率/kHz", "频谱显示值",
    ))
    content.append(
        f'<path d="{path_data(spectrum, plot_x, plot_y, plot_width, plot_height, 0.0, 180.0)}" class="spectrum"/>'
    )
    for peak_index, (frequency, amplitude) in enumerate(zip(
            item["peak_frequencies_hz"],
            item["peak_amplitudes_v"])):
        if frequency <= 0.0:
            continue
        frequency_khz = frequency / 1000.0
        px = plot_x + (
            frequency_khz - 10.0
        ) * plot_width / 590.0
        label_y = plot_y + 18 + peak_index * 29
        content.append(
            f'<line x1="{px:.2f}" y1="{plot_y}" '
            f'x2="{px:.2f}" y2="{plot_y + plot_height}" '
            f'class="peak"/>'
        )
        content.append(
            f'<text x="{px + 5:.2f}" y="{label_y:.2f}" '
            f'class="note">{peak_index + 1}: '
            f'{frequency_khz:.3f} kHz, '
            f'{amplitude * 1000.0:.1f} mV</text>'
        )
(OUTPUT_DIR / "spectrum-separated.svg").write_text(
    svg_document(1140, 720,
                 "五轮8192点FFT功率平均后的1024点频谱",
                 "\n".join(content)),
    encoding="utf-8",
)


def fir_coefficients(tap_count, cutoff_hz, sample_rate_hz):
    coefficient = []
    last = tap_count - 1
    center = last // 2
    normalized_cutoff = cutoff_hz / sample_rate_hz
    for index in range(tap_count):
        offset = index - center
        phase = 2.0 * math.pi * index / last
        window = (
            0.35875
            - 0.48829 * math.cos(phase)
            + 0.14128 * math.cos(2.0 * phase)
            - 0.01168 * math.cos(3.0 * phase)
        )
        if offset == 0:
            ideal = 2.0 * normalized_cutoff
        else:
            ideal = math.sin(
                2.0 * math.pi * normalized_cutoff * offset
            ) / (math.pi * offset)
        coefficient.append(ideal * window)
    total = sum(coefficient)
    return [value / total for value in coefficient]


def response_db(coefficients, frequencies, sample_rate):
    result = []
    for frequency in frequencies:
        angular = -2.0 * math.pi * frequency / sample_rate
        response = sum(
            coefficient * cmath.exp(1j * angular * index)
            for index, coefficient in enumerate(coefficients)
        )
        result.append(
            20.0 * math.log10(max(abs(response), 1.0e-9))
        )
    return result


h1 = fir_coefficients(513, 650_000.0, 7_200_000.0)
h2 = fir_coefficients(257, 625_000.0, 1_800_000.0)
f_total = [index * 900_000.0 / 900 for index in range(901)]
f_h1 = [index * 1_500_000.0 / 1000 for index in range(1001)]
h1_total = response_db(h1, f_total, 7_200_000.0)
h2_total = response_db(h2, f_total, 1_800_000.0)
h_total = [
    first + second
    for first, second in zip(h1_total, h2_total)
]
h1_only = response_db(h1, f_h1, 7_200_000.0)
h_total_plot = [max(-180.0, min(5.0, value)) for value in h_total]
h1_only_plot = [max(-180.0, min(5.0, value)) for value in h1_only]

plot_x = 82
plot_y = 64
plot_width = 1015
plot_height = 400
content = [
    '<rect x="88.8" y="64" width="399.1" height="400" fill="#1479d1" opacity="0.08"/>',
    '<rect x="758.7" y="64" width="338.3" height="400" fill="#d73a49" opacity="0.06"/>',
    chart_axes(
        plot_x, plot_y, plot_width, plot_height,
        [(0, "0"), (300, "300"), (600, "600"),
         (900, "900"), (1200, "1200"), (1500, "1500")],
        [-180, -120, -60, 0],
        0.0, 1500.0, -180.0, 5.0,
        "频率/kHz", "幅频响应/dB",
    ),
]
f_total_khz = [value / 1000.0 for value in f_total]
f_h1_khz = [value / 1000.0 for value in f_h1]
content.append(
    f'<path d="{path_data(h_total_plot, plot_x, plot_y, plot_width * 0.6, plot_height, -180.0, 5.0)}" class="filter1"/>'
)
content.append(
    f'<path d="{path_data(h1_only_plot, plot_x, plot_y, plot_width, plot_height, -180.0, 5.0)}" class="filter2"/>'
)
content.extend([
    '<line x1="102" y1="500" x2="142" y2="500" class="filter1"/>',
    '<text x="150" y="504" class="axis-label">两级总响应（0-900 kHz）</text>',
    '<line x1="365" y1="500" x2="405" y2="500" class="filter2"/>',
    '<text x="413" y="504" class="axis-label">第一级抗混叠FIR</text>',
    '<text x="488" y="92" text-anchor="end" class="note">有效测量频带：10-600 kHz</text>',
    '<text x="1085" y="92" text-anchor="end" class="note">题设干扰：≥1 MHz</text>',
    '<text x="600" y="118" class="note">600 kHz：-0.0011 dB</text>',
    '<text x="775" y="318" class="note">1 MHz：第一级约-141.2 dB</text>',
])
(OUTPUT_DIR / "filter-response.svg").write_text(
    svg_document(1140, 540,
                 "两级线性相位FIR滤波器幅频响应",
                 "\n".join(content)),
    encoding="utf-8",
)

print(json.dumps({
    "status": "PASS",
    "figures": sorted(path.name for path in OUTPUT_DIR.glob("*.svg")),
}, ensure_ascii=False))
