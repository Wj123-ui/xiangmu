import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
from scipy.signal import lfilter

ROOT = Path(r"C:\Users\yqh\Desktop\H743\26G")
OUT = ROOT / "docs" / "report-assets-current"
OUT.mkdir(parents=True, exist_ok=True)

FS = 6_000_000.0
FFT_SIZE = 16_384
RAW_COUNT = 16_896
WARMUP = 512
FOLD_POINTS = 1_024
CAPTURES = 18
VREF = 3.3
BIAS = 2.119945
GAIN = 7.168498

CHINESE_FONT = Path(r"C:\Windows\Fonts\msyh.ttc")
font_manager.fontManager.addfont(CHINESE_FONT)
plt.rcParams["font.family"] = font_manager.FontProperties(
    fname=CHINESE_FONT
).get_name()
plt.rcParams["axes.unicode_minus"] = False


def fir_coefficients(taps=513, cutoff=650_000.0):
    index = np.arange(taps, dtype=np.float64)
    center = (taps - 1) / 2.0
    phase = 2.0 * np.pi * index / (taps - 1)
    window = (
        0.35875
        - 0.48829 * np.cos(phase)
        + 0.14128 * np.cos(2.0 * phase)
        - 0.01168 * np.cos(3.0 * phase)
    )
    coefficients = (
        2.0 * cutoff / FS
        * np.sinc(2.0 * cutoff / FS * (index - center))
        * window
    )
    return coefficients / np.sum(coefficients)


H = fir_coefficients()


def response_at(frequency):
    index = np.arange(len(H), dtype=np.float64)
    return abs(np.sum(H * np.exp(-2j * np.pi * frequency * index / FS)))


frequencies = np.linspace(0.0, 1_500_000.0, 6001)
index = np.arange(len(H), dtype=np.float64)
response = np.abs(
    np.exp(-2j * np.pi * frequencies[:, None] * index[None, :] / FS) @ H
)
response_db = 20.0 * np.log10(np.maximum(response, 1.0e-9))

fig, ax = plt.subplots(figsize=(10.8, 5.2), constrained_layout=True)
ax.plot(frequencies / 1000.0, response_db, color="#1479d1", lw=1.4)
ax.axvspan(10, 600, color="#1479d1", alpha=0.08,
           label="测量频带：10～600 kHz")
ax.axvspan(1000, 1500, color="#d73a49", alpha=0.06,
           label="规定干扰频带：不低于 1 MHz")
ax.set_xlim(0, 1500)
ax.set_ylim(-160, 5)
ax.set_xlabel("频率/kHz")
ax.set_ylabel("幅频响应/dB")
ax.set_title("每秒六百万点、513 抽头线性相位低通滤波器幅频响应")
ax.grid(True, alpha=0.25)
ax.legend(loc="lower left")
annotation_offsets = {
    600_000.0: (-5, -24),
    650_000.0: (8, -30),
    1_000_000.0: (8, 12),
    1_200_000.0: (8, 12),
}
for frequency in (600_000.0, 650_000.0, 1_000_000.0, 1_200_000.0):
    value = 20.0 * math.log10(max(response_at(frequency), 1.0e-12))
    ax.annotate(
        f"{frequency/1000:.0f} kHz: {value:.3f} dB",
        xy=(frequency / 1000.0, max(-158, value)),
        xytext=annotation_offsets[frequency],
        textcoords="offset points", fontsize=8,
    )
fig.savefig(OUT / "filter-response-6msps.svg")
fig.savefig(OUT / "filter-response-6msps.png", dpi=160)
plt.close(fig)


CASES = [
    ("10.5 kHz 基波及 3、4 次谐波", 10_500.0,
     [(1, 0.050, 0.0), (3, 0.020, 0.65), (4, 0.010, -0.80)]),
    ("83 kHz 基波及 2、4 次谐波", 83_000.0,
     [(1, 0.035, 0.0), (2, 0.028, -0.45), (4, 0.041, 0.90)]),
    ("160 kHz 基波及 2、3 次谐波", 160_000.0,
     [(1, 0.025, 0.0), (2, 0.050, 0.55), (3, 0.020, -1.10)]),
    ("125 kHz 基波及 2、4 次谐波", 125_000.0,
     [(1, 0.050, 0.0), (2, 0.025, -0.30), (4, 0.015, 1.20)]),
]


def expected_cycle(components, cycles=1):
    phase = (
        2.0 * np.pi * cycles * np.arange(FOLD_POINTS)
        / (FOLD_POINTS - 1)
    )
    result = np.zeros(FOLD_POINTS)
    for order, amplitude, relative_phase in components:
        result += amplitude * np.sin(order * phase + relative_phase)
    return result


def to_hmi(values):
    minimum = float(np.min(values))
    maximum = float(np.max(values))
    if maximum - minimum < 1.0e-12:
        return np.zeros(len(values))
    return np.clip(
        np.rint(5.0 + (values - minimum) * 170.0 / (maximum - minimum)),
        5, 175,
    )


def fill_empty_bins(folded, measured):
    if np.all(measured):
        return folded
    measured_index = np.flatnonzero(measured)
    extended_index = np.concatenate(
        (measured_index - FOLD_POINTS, measured_index,
         measured_index + FOLD_POINTS)
    )
    extended_value = np.tile(folded[measured_index], 3)
    missing_index = np.flatnonzero(~measured)
    folded[missing_index] = np.interp(
        missing_index, extended_index, extended_value
    )
    return folded


def folded_cycle(f0, components):
    sums = np.zeros(FOLD_POINTS)
    weights = np.zeros(FOLD_POINTS)
    raw_index = np.arange(RAW_COUNT, dtype=np.float64)
    group_delay = (len(H) - 1) // 2

    for capture in range(CAPTURES):
        start_phase = 2.0 * np.pi * (
            (0.173 * capture + 0.031 * capture * capture) % 1.0
        )
        input_voltage = np.zeros(RAW_COUNT)
        for order, amplitude, relative_phase in components:
            input_voltage += amplitude * np.sin(
                2.0 * np.pi * order * f0 * raw_index / FS
                + order * start_phase + relative_phase
            )
        adc_voltage = np.clip(BIAS + GAIN * input_voltage, 0.0, VREF)
        code = np.rint(adc_voltage * 4095.0 / VREF)
        recovered = (code * VREF / 4095.0 - BIAS) / GAIN
        filtered = lfilter(H, [1.0], recovered)[
            WARMUP:WARMUP + FFT_SIZE
        ]

        first_phase = (
            start_phase
            + 2.0 * np.pi * f0 * (WARMUP - group_delay) / FS
        ) / (2.0 * np.pi)
        phase = (
            first_phase + f0 / FS * np.arange(FFT_SIZE)
        ) % 1.0
        position = phase * FOLD_POINTS
        first = np.floor(position).astype(np.int64) % FOLD_POINTS
        second = (first + 1) % FOLD_POINTS
        second_weight = position - np.floor(position)
        first_weight = 1.0 - second_weight
        np.add.at(sums, first, filtered * first_weight)
        np.add.at(weights, first, first_weight)
        np.add.at(sums, second, filtered * second_weight)
        np.add.at(weights, second, second_weight)

    folded = np.zeros(FOLD_POINTS)
    measured = weights > 1.0e-6
    folded[measured] = sums[measured] / weights[measured]
    folded = fill_empty_bins(folded, measured)
    folded -= np.mean(folded)
    return folded


results = []
fig1, axes1 = plt.subplots(2, 2, figsize=(11.2, 6.8), constrained_layout=True)
fig3, axes3 = plt.subplots(2, 1, figsize=(11.2, 6.6), constrained_layout=True)
figs, axess = plt.subplots(2, 2, figsize=(11.2, 6.8), constrained_layout=True)

for case_index, (title, f0, components) in enumerate(CASES):
    folded = folded_cycle(f0, components)
    expected = expected_cycle(components)
    expected_hmi = to_hmi(expected)
    folded_hmi = to_hmi(folded)
    mean_error = float(np.mean(np.abs(expected_hmi - folded_hmi)))
    max_error = float(np.max(np.abs(expected_hmi - folded_hmi)))
    results.append({
        "case": title,
        "mean_hmi_error": mean_error,
        "max_hmi_error": max_error,
    })

    ax = axes1.flat[case_index]
    cycle_x = np.linspace(0.0, 1.0, FOLD_POINTS)
    ax.plot(cycle_x, expected_hmi[::-1], "--", color="#1479d1", lw=1.1,
            label="理论输入")
    ax.plot(cycle_x, folded_hmi[::-1], color="#e45a2a", lw=0.9,
            label="12 位模数转换、低通滤波与 18 轮折叠")
    ax.set_title(title, fontsize=10)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 180)
    ax.grid(True, alpha=0.22)
    ax.text(0.99, 0.04, f"平均误差 {mean_error:.2f}/180",
            ha="right", va="bottom", transform=ax.transAxes, fontsize=8)
    if case_index == 0:
        ax.legend(fontsize=8)

    spectrum_ax = axess.flat[case_index]
    maximum_amplitude = max(value[1] for value in components)
    spectrum_ax.set_xlim(10, 600)
    spectrum_ax.set_ylim(0, 1.08)
    for order, amplitude, _ in components:
        frequency_khz = order * f0 / 1000.0
        height = amplitude / maximum_amplitude
        spectrum_ax.vlines(frequency_khz, 0, height,
                           color="#168a5b", lw=2.0)
        spectrum_ax.text(
            frequency_khz + 4, height,
            f"{frequency_khz:.1f} kHz\n{amplitude*1000:.0f} mV",
            fontsize=7, va="top",
        )
    spectrum_ax.set_title(title, fontsize=10)
    spectrum_ax.grid(True, alpha=0.22)

    if case_index < 2:
        three_ax = axes3[case_index]
        three_x = np.linspace(0.0, 3.0, FOLD_POINTS)
        expected_three = to_hmi(expected_cycle(components, 3))
        wrapped = (
            np.arange(FOLD_POINTS) * 3.0 / (FOLD_POINTS - 1)
        ) % 1.0
        source_x = np.arange(FOLD_POINTS) / FOLD_POINTS
        folded_three = to_hmi(
            np.interp(wrapped, source_x, folded, period=1.0)
        )
        three_ax.plot(three_x, expected_three[::-1], "--",
                      color="#1479d1", lw=1.1,
                      label="理论输入")
        three_ax.plot(three_x, folded_three[::-1], color="#e45a2a", lw=0.9,
                      label="18 轮折叠重采样")
        three_ax.set_title(title, fontsize=10)
        three_ax.set_xlim(0, 3)
        three_ax.set_ylim(0, 180)
        three_ax.grid(True, alpha=0.22)
        if case_index == 0:
            three_ax.legend(fontsize=8)

fig1.suptitle("1024 点单周期理论输入与当前程序显示结果", fontsize=14)
fig1.supxlabel("串口屏横向位置（归一化）")
fig1.supylabel("串口屏波形值")
fig1.savefig(OUT / "waveform-one-cycle-18capture.svg")
fig1.savefig(OUT / "waveform-one-cycle-18capture.png", dpi=160)
plt.close(fig1)

fig3.suptitle("1024 点三周期理论输入与当前程序显示结果", fontsize=14)
fig3.supxlabel("串口屏横向位置（三周期）")
fig3.supylabel("串口屏波形值")
fig3.savefig(OUT / "waveform-three-cycle-18capture.svg")
fig3.savefig(OUT / "waveform-three-cycle-18capture.png", dpi=160)
plt.close(fig3)

figs.suptitle(
    "当前离散频谱：基波与已确认谐波",
    fontsize=14,
)
figs.supxlabel("频率/kHz")
figs.supylabel("相对峰值幅度")
figs.savefig(OUT / "spectrum-confirmed-components.svg")
figs.savefig(OUT / "spectrum-confirmed-components.png", dpi=160)
plt.close(figs)


def save_reserved_plot(filename, title, xlabel, ylabel, xlim, ylim):
    figure, axis = plt.subplots(figsize=(10.8, 4.8), constrained_layout=True)
    axis.set_xlim(*xlim)
    axis.set_ylim(*ylim)
    axis.set_xlabel(xlabel)
    axis.set_ylabel(ylabel)
    axis.set_title(title)
    axis.grid(True, alpha=0.25)
    axis.text(
        0.5, 0.5,
        "待接入含谐波复合信号后填入实板数据",
        ha="center", va="center", transform=axis.transAxes,
        fontsize=16, color="#666666",
        bbox={"boxstyle": "round,pad=0.6", "facecolor": "white",
              "edgecolor": "#999999", "linestyle": "--"},
    )
    figure.savefig(OUT / f"{filename}.svg")
    figure.savefig(OUT / f"{filename}.png", dpi=160)
    plt.close(figure)


save_reserved_plot(
    "harmonic-board-one-cycle-placeholder",
    "含谐波实测单周期波形（预留）",
    "串口屏横向位置（归一化）",
    "串口屏波形值",
    (0.0, 1.0), (0.0, 180.0),
)
save_reserved_plot(
    "harmonic-board-three-cycle-placeholder",
    "含谐波实测三周期波形（预留）",
    "串口屏横向位置（三周期）",
    "串口屏波形值",
    (0.0, 3.0), (0.0, 180.0),
)
save_reserved_plot(
    "harmonic-board-spectrum-placeholder",
    "含谐波实测离散频谱（预留）",
    "频率/kHz",
    "峰值幅度/mV",
    (10.0, 600.0), (0.0, 100.0),
)

(OUT / "figure-verification.json").write_text(
    json.dumps({
        "sample_rate_hz": FS,
        "fft_size": FFT_SIZE,
        "capture_count": CAPTURES,
        "raw_samples_per_capture": RAW_COUNT,
        "warmup_samples": WARMUP,
        "fold_points": FOLD_POINTS,
        "fir_gain": {
            str(int(frequency)): response_at(frequency)
            for frequency in (
                600_000.0, 650_000.0, 1_000_000.0, 1_200_000.0
            )
        },
        "waveform_cases": results,
    }, indent=2),
    encoding="utf-8",
)

print(json.dumps({"status": "PASS", "waveform_cases": results}))
