#include "hmi.h"
#include "usart.h"
#include "stm32h7xx_hal.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

uint8_t USART_RX_BUF[USART_REC_LEN];
volatile uint16_t USART_RX_STA;
static uint8_t usart2_rx_byte;
static volatile uint8_t usart2_pending_command;
static uint8_t hmi_reply_length;

static int HMI_IsApplicationCommand(uint8_t value)
{
    return (value == (uint8_t)'0') ||
           (value == (uint8_t)'1') ||
           (value == (uint8_t)'3') ||
           (value == (uint8_t)'6') ||
           (value == (uint8_t)'9') ||
           (value == (uint8_t)'P');
}

int HMI_UART_StartReceive(void)
{
    memset(USART_RX_BUF, 0, sizeof(USART_RX_BUF));
    USART_RX_STA = 0U;
    usart2_pending_command = 0U;
    hmi_reply_length = 0U;

    return (HAL_UART_Receive_IT(&huart2, &usart2_rx_byte, 1U) ==
            HAL_OK) ? 1 : 0;
}

int HMI_UART_TakeCommand(uint8_t *command)
{
    uint32_t primask;

    if (command == NULL)
        return 0;

    primask = __get_PRIMASK();
    __disable_irq();

    if (((USART_RX_STA & 0x8000U) != 0U) &&
        ((USART_RX_STA & 0x3FFFU) == 4U) &&
        ((USART_RX_BUF[0] == 0xFDU) ||
         (USART_RX_BUF[0] == 0xFEU)) &&
        (USART_RX_BUF[1] == 0xFFU) &&
        (USART_RX_BUF[2] == 0xFFU) &&
        (USART_RX_BUF[3] == 0xFFU))
    {
        memset(USART_RX_BUF, 0, sizeof(USART_RX_BUF));
        USART_RX_STA = 0U;
    }

    if (usart2_pending_command == 0U)
    {
        if (primask == 0U)
            __enable_irq();
        return 0;
    }

    *command = usart2_pending_command;
    usart2_pending_command = 0U;

    if (primask == 0U)
        __enable_irq();

    return 1;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    uint8_t value;

    if ((huart == NULL) || (huart->Instance != USART2))
        return;

    value = usart2_rx_byte;

    /*
     * Match the example's interrupt receive buffer.  Touch commands are
     * collapsed to the newest pending command, so repeated taps cannot queue
     * multiple long waveform transmissions.  FE/FD transparent-transfer
     * replies are collected as four-byte packets and cannot cause ORE.
     */
    if (HMI_IsApplicationCommand(value))
    {
        USART_RX_BUF[0] = value;
        USART_RX_STA = 0x8001U;
        usart2_pending_command = value;
        hmi_reply_length = 0U;
    }
    else if ((value == 0xFDU) || (value == 0xFEU))
    {
        USART_RX_BUF[0] = value;
        hmi_reply_length = 1U;
        USART_RX_STA = 1U;
    }
    else if ((hmi_reply_length > 0U) && (value == 0xFFU))
    {
        USART_RX_BUF[hmi_reply_length] = value;
        hmi_reply_length++;
        USART_RX_STA = hmi_reply_length;

        if (hmi_reply_length == 4U)
        {
            USART_RX_STA |= 0x8000U;
            hmi_reply_length = 0U;
        }
    }
    else
    {
        hmi_reply_length = 0U;
    }

    (void)HAL_UART_Receive_IT(&huart2, &usart2_rx_byte, 1U);
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if ((huart == NULL) || (huart->Instance != USART2))
        return;

    __HAL_UART_CLEAR_OREFLAG(&huart2);
    __HAL_UART_CLEAR_FEFLAG(&huart2);
    __HAL_UART_CLEAR_NEFLAG(&huart2);
    hmi_reply_length = 0U;
    (void)HAL_UART_Receive_IT(&huart2, &usart2_rx_byte, 1U);
}

void HMI_send_string(char* name, char* showdata)
{
    printf("%s=\"%s\"\xff\xff\xff", name, showdata);
}

void HMI_send_number(char* name, int num)
{
    printf("%s=%d\xff\xff\xff", name, num);
}

void HMI_send_float(char* name, float num)
{
    printf("%s=%d\xff\xff\xff", name, (int)(num * 10000.0f));
}

void HMI_Wave(char* name, int ch, int val)
{
    printf("add %s,%d,%d\xff\xff\xff", name, ch, val);
}

void HMI_Wave_Fast(char* name, int ch, int count, int* show_data)
{
    int i;

    if ((name == NULL) || (show_data == NULL) || (count <= 0))
        return;

    printf("addt %s,%d,%d\xff\xff\xff", name, ch, count);
    HAL_Delay(100);

    /* The HMI time/frequency axes run in the opposite direction to the
     * internal analysis buffers, so transmit every waveform right-to-left. */
    for (i = 0; i < count; i++)
        printf("%c", show_data[count - 1 - i]);

    printf("\xff\xff\xff");
}

void HMI_Wave_Clear(char* name, int ch)
{
    printf("cle %s,%d\xff\xff\xff", name, ch);
}
