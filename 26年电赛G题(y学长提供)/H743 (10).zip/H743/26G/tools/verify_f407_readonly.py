#!/usr/bin/env python3
"""Check that the external F407 source still matches the final read-only snapshot."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
F407_ROOT = PROJECT_ROOT.parents[1] / "F407_2"
SNAPSHOT = PROJECT_ROOT / "docs" / "F407_READONLY_SHA256.txt"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def main() -> int:
    changes: list[dict[str, str]] = []
    checked = 0

    for line in SNAPSHOT.read_text(encoding="utf-8").splitlines():
        if not line or line.startswith("#"):
            continue

        expected, relative_name = line.split(maxsplit=1)
        path = F407_ROOT / Path(relative_name)
        checked += 1

        if not path.is_file():
            changes.append(
                {"file": relative_name, "expected": expected, "actual": "MISSING"}
            )
            continue

        actual = sha256(path)
        if actual != expected:
            changes.append(
                {"file": relative_name, "expected": expected, "actual": actual}
            )

    report = {
        "status": "PASS" if not changes else "CHANGED",
        "f407_root": str(F407_ROOT),
        "files_checked": checked,
        "changes": changes,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if not changes else 1


if __name__ == "__main__":
    raise SystemExit(main())
