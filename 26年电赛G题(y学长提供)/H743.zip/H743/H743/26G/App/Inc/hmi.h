#ifndef HMI_H
#define HMI_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#define USART_REC_LEN 200U

extern uint8_t USART_RX_BUF[USART_REC_LEN];
extern volatile uint16_t USART_RX_STA;

void HMI_send_string(char* name, char* showdata);
void HMI_send_number(char* name, int num);
void HMI_send_float(char* name, float num);
/* Send a voltage expressed in volts as signed fixed-point mV x 100. */
void HMI_send_voltage_mv_2dp(char* name, float voltage_v);
void HMI_Wave(char* name, int ch, int val);
void HMI_Wave_Fast(char* name, int ch, int count, int* show_data);
void HMI_Wave_Clear(char* name, int ch);
int HMI_UART_StartReceive(void);
int HMI_UART_TakeCommand(uint8_t *command);

#ifdef __cplusplus
}
#endif

#endif
