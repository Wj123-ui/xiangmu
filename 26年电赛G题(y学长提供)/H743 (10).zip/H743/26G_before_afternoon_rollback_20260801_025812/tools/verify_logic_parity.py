#!/usr/bin/env python3
"""Verify that the final F407 application logic is preserved in the H743 port.

The F407 tree is read only.  This checker compares source text in memory and
normalizes only the explicitly required MCU-family adaptations.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path


F407_ROOT = Path(r"C:\Users\yqh\Desktop\F407_2")
H743_ROOT = Path(__file__).resolve().parents[1]


def read_text(root: Path, relative_path: str) -> str:
    return (root / relative_path).read_text(encoding="utf-8").replace("\r\n", "\n")


def strip_c_comments(text: str) -> str:
    output: list[str] = []
    index = 0
    state = "code"

    while index < len(text):
        char = text[index]
        next_char = text[index + 1] if index + 1 < len(text) else ""

        if state == "code":
            if char == "/" and next_char == "*":
                state = "block_comment"
                index += 2
                continue
            if char == "/" and next_char == "/":
                state = "line_comment"
                index += 2
                continue
            if char == '"':
                state = "string"
            elif char == "'":
                state = "character"
            output.append(char)
            index += 1
            continue

        if state == "block_comment":
            if char == "*" and next_char == "/":
                state = "code"
                index += 2
            else:
                if char == "\n":
                    output.append("\n")
                index += 1
            continue

        if state == "line_comment":
            if char == "\n":
                output.append("\n")
                state = "code"
            index += 1
            continue

        output.append(char)
        if char == "\\" and index + 1 < len(text):
            output.append(text[index + 1])
            index += 2
            continue
        if (state == "string" and char == '"') or (
            state == "character" and char == "'"
        ):
            state = "code"
        index += 1

    return "".join(output)


def compact_c(text: str) -> str:
    return re.sub(r"\s+", "", strip_c_comments(text))


def extract_function(text: str, function_name: str) -> str:
    signature = re.compile(
        rf"(?m)^[ \t]*(?:static[ \t]+)?"
        rf"[A-Za-z_][A-Za-z0-9_ \t\*]*\b{re.escape(function_name)}"
        rf"[ \t]*\([^;]*?\)[ \t\r\n]*\{{"
    )
    match = signature.search(text)
    if match is None:
        raise AssertionError(f"function not found: {function_name}")

    opening_brace = text.find("{", match.start(), match.end())
    depth = 0
    index = opening_brace
    state = "code"

    while index < len(text):
        char = text[index]
        next_char = text[index + 1] if index + 1 < len(text) else ""

        if state == "code":
            if char == "/" and next_char == "*":
                state = "block_comment"
                index += 2
                continue
            if char == "/" and next_char == "/":
                state = "line_comment"
                index += 2
                continue
            if char == '"':
                state = "string"
            elif char == "'":
                state = "character"
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    return text[match.start() : index + 1]
            index += 1
            continue

        if state == "block_comment":
            if char == "*" and next_char == "/":
                state = "code"
                index += 2
            else:
                index += 1
            continue

        if state == "line_comment":
            if char == "\n":
                state = "code"
            index += 1
            continue

        if char == "\\" and index + 1 < len(text):
            index += 2
            continue
        if (state == "string" and char == '"') or (
            state == "character" and char == "'"
        ):
            state = "code"
        index += 1

    raise AssertionError(f"unterminated function: {function_name}")


def normalize_platform_adaptations(text: str) -> str:
    normalized = text
    normalized = re.sub(
        r"/\* H743 COMPETITION EXTENSION BEGIN \*/"
        r".*?"
        r"/\* H743 COMPETITION EXTENSION END \*/",
        "",
        normalized,
        flags=re.DOTALL,
    )
    normalized = normalized.replace("stm32h7xx_hal.h", "stm32f4xx_hal.h")
    normalized = normalized.replace("huart2", "huart1")
    normalized = normalized.replace("->RDR", "->DR")
    normalized = re.sub(
        r"\(void\)\s*HAL_ADCEx_MultiModeStop_DMA"
        r"\s*\(\s*&hadc1\s*\)\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"\(void\)\s*HAL_ADC_Stop\s*\(\s*&hadc[23]\s*\)\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"\(void\)\s*ADC_Capture_Stop\s*\(\s*\)\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"memset\s*\(\s*hmi_(?:work_buffer|folded_cycle_buffer|fold_weight_buffer)"
        r"\s*,\s*0\s*,\s*sizeof\s*\(\s*hmi_"
        r"(?:work_buffer|folded_cycle_buffer|fold_weight_buffer)"
        r"\s*\)\s*\)\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"hmi_folded_cycle_valid\s*=\s*0U\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"memset\s*\(\s*spectrum_power_accumulator\s*,\s*0\s*,"
        r"\s*sizeof\s*\(\s*spectrum_power_accumulator\s*\)\s*\)\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"spectrum_accumulation_count\s*=\s*0U\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"memset\s*\(\s*coherent_harmonic_"
        r"(?:sine_sum|cosine_sum|amplitude_sum|capture_count|evidence_count)"
        r"\s*,\s*0\s*,"
        r"\s*sizeof\s*\(\s*coherent_harmonic_"
        r"(?:sine_sum|cosine_sum|amplitude_sum|capture_count|evidence_count)"
        r"\s*\)\s*\)\s*;",
        "",
        normalized,
    )
    return compact_c(normalized)


def assert_file_logic_equal(relative_path: str) -> None:
    f407_text = read_text(F407_ROOT, relative_path)
    h743_text = read_text(H743_ROOT, relative_path)
    if normalize_platform_adaptations(f407_text) != normalize_platform_adaptations(
        h743_text
    ):
        raise AssertionError(f"application file logic differs: {relative_path}")


def assert_h743_full_rate_filter_adaptation() -> None:
    """Audit the target-only 1:1 FIR path while retaining common math."""

    source = read_text(F407_ROOT, "App/Src/signal_filter.c")
    target = read_text(H743_ROOT, "App/Src/signal_filter.c")
    unchanged_functions = [
        "Signal_Filter_GenerateLowPass",
        "Signal_Filter_AdcToFloat",
        "Signal_Filter_RemoveDc",
        "Signal_Filter_CalculateRms",
    ]
    for function_name in unchanged_functions:
        if compact_c(extract_function(source, function_name)) != compact_c(
            extract_function(target, function_name)
        ):
            raise AssertionError(
                f"common FIR function changed unexpectedly: {function_name}"
            )

    required = [
        "#if SIGNAL_DECIMATION_FACTOR > 1U",
        "arm_fir_decimate_f32(&signal_filter_instance,",
        "Signal_Filter_ProcessFullRate",
        "SIGNAL_FILTER_OVERLAP_COUNT",
        "arm_rfft_fast_f32(&signal_filter_fft_instance,",
    ]
    for marker in required:
        if marker not in target:
            raise AssertionError(
                f"H743 full-rate FIR bypass is incomplete: {marker}"
            )


def assert_hmi_transport_adaptation() -> None:
    """Keep the supplied HMI example intact and audit its RX protection."""
    source = read_text(F407_ROOT, "App/Src/hmi.c")
    target = read_text(H743_ROOT, "App/Src/hmi.c")

    unchanged_functions = [
        "HMI_send_string",
        "HMI_send_number",
        "HMI_send_float",
        "HMI_Wave",
        "HMI_Wave_Fast",
        "HMI_Wave_Clear",
    ]
    for function_name in unchanged_functions:
        if compact_c(extract_function(source, function_name)) != compact_c(
            extract_function(target, function_name)
        ):
            raise AssertionError(
                f"HMI command changed unexpectedly: {function_name}"
            )

    required = [
        "#define USART_REC_LEN 200U",
        "HMI_UART_StartReceive",
        "HMI_UART_TakeCommand",
        "HAL_UART_RxCpltCallback",
        "HAL_UART_ErrorCallback",
        "USART_RX_STA = 0x8001U",
        "value == 0xFDU",
    ]
    for marker in required:
        if marker not in (
            target + read_text(H743_ROOT, "App/Inc/hmi.h")
        ):
            raise AssertionError(
                f"H743 HMI interrupt receive protection is missing: {marker}"
            )


def assert_h743_fft_capacity_upgrade() -> None:
    """Allow only the audited 16384-point real-FFT transform adaptation.

    The F407 estimator is retained where it is waveform independent.  The
    H743 intentionally expands peak capacity and replaces the old
    harmonic-only/template reporting with generic component retention.  The
    transform is also replaced because this CMSIS-DSP package offers a
    4096-point complex FFT but no native 16384-point real FFT.
    """
    header_source = read_text(F407_ROOT, "App/Inc/signal_fft.h")
    header_target = read_text(H743_ROOT, "App/Inc/signal_fft.h")
    normalized_header_target = header_target.replace(
        "#define SIGNAL_FFT_SIZE 16384U", "#define SIGNAL_FFT_SIZE 4096U"
    ).replace("#define SIGNAL_FFT_MAX_PEAKS 12U", "#define SIGNAL_FFT_MAX_PEAKS 6U")
    if compact_c(header_source) != compact_c(normalized_header_target):
        raise AssertionError("signal_fft.h differs beyond the 16384-point size")

    unchanged_functions = [
        "Signal_FFT_DefaultConfig",
        "Signal_FFT_ConfigIsValid",
        "Signal_FFT_Partition",
        "Signal_FFT_Median",
        "Signal_FFT_GenerateBlackmanHarrisWindow",
        "Signal_FFT_MinimumBin",
        "Signal_FFT_MaximumBin",
        "Signal_FFT_IsSeparated",
        "Signal_FFT_RefineBinPosition",
        "Signal_FFT_CalculatePeakAmplitude",
        "Signal_FFT_CalculatePeakPhase",
        "Signal_FFT_SortPeaksByFrequency",
        "Signal_FFT_HarmonicTolerance",
        "Signal_FFT_MatchHarmonic",
        "Signal_FFT_SolveFitSystem",
        "Signal_FFT_FitHarmonicComponents",
        "Signal_FFT_GetSpectrum",
        "Signal_FFT_BinToFrequency",
        "Signal_FFT_GetConfig",
    ]
    source = read_text(F407_ROOT, "App/Src/signal_fft.c")
    target = read_text(H743_ROOT, "App/Src/signal_fft.c")
    for function_name in unchanged_functions:
        source_function = extract_function(source, function_name)
        target_function = extract_function(target, function_name)
        if function_name == "Signal_FFT_DefaultConfig":
            target_function = target_function.replace(
                "config.minimum_peak_amplitude = 0.0015f;",
                "config.minimum_peak_amplitude = 0.0025f;",
            )
        if compact_c(source_function) != compact_c(target_function):
            raise AssertionError(
                f"signal FFT estimator changed unexpectedly: {function_name}"
            )

    required_target_text = [
        "#define SIGNAL_FFT_SIZE 16384U",
        "arm_cfft_sR_f32_len4096",
        "static void Signal_FFT_TransformReal8192(float32_t *packed_input,",
        "X[k] = 0.5 * ((A+B) - j*W(k)*(A-B))",
        "static void Signal_FFT_TransformReal16384(const float *samples,",
        "X[k] = E[k] + exp(-j*2*pi*k/N) O[k]",
        "Signal_FFT_TransformReal16384(samples, input_mean);",
        "#define SIGNAL_FFT_MAX_PEAKS 12U",
        "result->peaks[peak].harmonic_order = 0U;",
        "result->voltage_peak_to_peak = result->input_peak_to_peak;",
    ]
    for expected in required_target_text:
        if expected not in (header_target + target):
            raise AssertionError(f"16384-point FFT adaptation is incomplete: {expected}")


def assert_function_equal(function_name: str) -> None:
    relative_path = "Core/Src/main.c"
    f407_function = extract_function(
        read_text(F407_ROOT, relative_path), function_name
    )
    h743_function = extract_function(
        read_text(H743_ROOT, relative_path), function_name
    )
    if normalize_platform_adaptations(
        f407_function
    ) != normalize_platform_adaptations(h743_function):
        raise AssertionError(f"business function differs: {function_name}")


def normalize_uart_adaptations(text: str) -> str:
    normalized = text.replace("huart2", "huart1")
    normalized = normalized.replace("->RDR", "->DR")
    normalized = re.sub(
        r"\buint8_t\s+received_command\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"if\s*\(\s*!HMI_UART_TakeCommand"
        r"\s*\(\s*&received_command\s*\)\s*\)"
        r"\s*\{\s*return\s*;\s*\}",
        "",
        normalized,
        flags=re.DOTALL,
    )
    normalized = re.sub(
        r"if\s*\(\s*__HAL_UART_GET_FLAG"
        r"\s*\(\s*&huart1\s*,\s*UART_FLAG_RXNE\s*\)"
        r"\s*==\s*RESET\s*\)\s*\{\s*return\s*;\s*\}"
        r"\s*USART_RX_BUF\s*\[\s*0\s*\]\s*="
        r"\s*\(uint8_t\)\s*\(\s*huart1\.Instance->DR"
        r"\s*&\s*0x00FFU\s*\)\s*;",
        "",
        normalized,
        flags=re.DOTALL,
    )
    normalized = normalized.replace(
        "received_command", "USART_RX_BUF[0]"
    )
    normalized = re.sub(
        r"memset\s*\(\s*USART_RX_BUF\s*,\s*0\s*,"
        r"\s*sizeof\s*\(\s*USART_RX_BUF\s*\)\s*\)\s*;",
        "",
        normalized,
    )
    # The H743 simulation image is host-command driven so that the UART test
    # cannot race an automatic boot-time stream.  This conditional test-only
    # telemetry has no counterpart in the actual firmware protocol.
    normalized = re.sub(
        r"#if\s+APP_ADC_SIMULATION_MODE\s*"
        r"HMI_send_number\s*\(\s*\"x9\.val\".*?\n#endif",
        "",
        normalized,
        flags=re.DOTALL,
    )
    normalized = re.sub(
        r"\(void\)\s*HAL_ADCEx_MultiModeStop_DMA"
        r"\s*\(\s*&hadc1\s*\)\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"\(void\)\s*HAL_ADC_Stop\s*\(\s*&hadc[23]\s*\)\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"\(void\)\s*ADC_Capture_Stop\s*\(\s*\)\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"memset\s*\(\s*hmi_(?:work_buffer|folded_cycle_buffer|fold_weight_buffer)"
        r"\s*,\s*0\s*,\s*sizeof\s*\(\s*hmi_"
        r"(?:work_buffer|folded_cycle_buffer|fold_weight_buffer)"
        r"\s*\)\s*\)\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"hmi_folded_cycle_valid\s*=\s*0U\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"memset\s*\(\s*spectrum_power_accumulator\s*,\s*0\s*,"
        r"\s*sizeof\s*\(\s*spectrum_power_accumulator\s*\)\s*\)\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"spectrum_accumulation_count\s*=\s*0U\s*;",
        "",
        normalized,
    )
    normalized = re.sub(
        r"memset\s*\(\s*coherent_harmonic_"
        r"(?:sine_sum|cosine_sum|amplitude_sum|capture_count|evidence_count)"
        r"\s*,\s*0\s*,"
        r"\s*sizeof\s*\(\s*coherent_harmonic_"
        r"(?:sine_sum|cosine_sum|amplitude_sum|capture_count|evidence_count)"
        r"\s*\)\s*\)\s*;",
        "",
        normalized,
    )
    return compact_c(normalized)


def assert_uart_function_equal() -> None:
    relative_path = "Core/Src/main.c"
    f407_function = extract_function(
        read_text(F407_ROOT, relative_path), "uart_proc"
    )
    h743_function = extract_function(
        read_text(H743_ROOT, relative_path), "uart_proc"
    )
    if normalize_uart_adaptations(f407_function) != normalize_uart_adaptations(
        h743_function
    ):
        raise AssertionError(
            "uart_proc differs beyond USART1/DR -> USART2/RDR and ADC stop adaptation"
        )


def assert_calibration_function_equal() -> None:
    """Allow the target's measured external-reference calibration path."""
    relative_path = "Core/Src/main.c"
    f407_function = extract_function(
        read_text(F407_ROOT, relative_path), "App_UpdateFrontendCalibration"
    )
    h743_function = extract_function(
        read_text(H743_ROOT, relative_path), "App_UpdateFrontendCalibration"
    )
    h743_calibration_block = """
  calibrated_gain =
      2.0F * amplitude_code * adc_reference_voltage /
      (ADC_FULL_SCALE_CODE * ADC_CALIBRATION_REFERENCE_VPP);
  calibrated_bias =
      mean_code * adc_reference_voltage /
          ADC_FULL_SCALE_CODE -
      calibrated_gain *
          ADC_CALIBRATION_REFERENCE_DC_OFFSET;
"""
    f407_calibration_block = """
  calibrated_bias =
      mean_code * ADC_REFERENCE_VOLTAGE /
      ADC_FULL_SCALE_CODE;
  calibrated_gain =
      2.0F * amplitude_code * ADC_REFERENCE_VOLTAGE /
      (ADC_FULL_SCALE_CODE * ADC_CALIBRATION_REFERENCE_VPP);
"""
    if h743_calibration_block not in h743_function:
        raise AssertionError("H743 calibration offset block is missing or changed")
    normalized_h743 = h743_function.replace(
        h743_calibration_block, f407_calibration_block
    )
    normalized_h743 = normalized_h743.replace(
        "adc_reference_voltage", "ADC_REFERENCE_VOLTAGE"
    )
    if normalize_platform_adaptations(
        f407_function
    ) != normalize_platform_adaptations(normalized_h743):
        raise AssertionError(
            "App_UpdateFrontendCalibration differs beyond the approved DC-offset adaptation"
        )


def assert_main_loop_equal() -> None:
    start_marker = "/* Infinite loop */"
    end_marker = "/* USER CODE END 3 */"

    def loop_region(root: Path) -> str:
        text = read_text(root, "Core/Src/main.c")
        start = text.index(start_marker)
        end = text.index(end_marker, start) + len(end_marker)
        return normalize_platform_adaptations(text[start:end])

    if loop_region(F407_ROOT) != loop_region(H743_ROOT):
        raise AssertionError("main application loop differs")


def assert_w25q64_calibration_persistence() -> None:
    main_source = read_text(H743_ROOT, "Core/Src/main.c")
    store_source = read_text(H743_ROOT, "App/Src/calibration_store.c")
    cmake_source = read_text(H743_ROOT, "CMakeLists.txt")

    required_main_markers = [
        "#define ADC_CALIBRATION_REFERENCE_VPP 0.1000F",
        "CalibrationStore_Init(&adc_frontend_gain,",
        "CalibrationStore_Save(adc_frontend_gain,",
    ]
    required_store_markers = [
        "W25Q64_EXPECTED_JEDEC_ID",
        "0x00EF4017UL",
        "CALIBRATION_SECTOR_A",
        "CALIBRATION_SECTOR_B",
        "CalibrationStore_Crc32",
        "CalibrationStore_RecordValid",
        "W25Q64_EraseSector",
        "W25Q64_Program",
        "memcmp(&record, &verification",
    ]

    for marker in required_main_markers:
        if marker not in main_source:
            raise AssertionError(
                f"W25Q64 calibration integration missing: {marker}"
            )
    for marker in required_store_markers:
        if marker not in store_source:
            raise AssertionError(
                f"W25Q64 transactional store missing: {marker}"
            )
    if "App/Src/calibration_store.c" not in cmake_source:
        raise AssertionError("calibration_store.c is not part of the build")


def main() -> int:
    if not F407_ROOT.is_dir():
        raise AssertionError(f"F407 source tree not found: {F407_ROOT}")

    equal_files = ["App/Inc/signal_filter.h"]
    for relative_path in equal_files:
        assert_file_logic_equal(relative_path)

    assert_h743_full_rate_filter_adaptation()
    assert_hmi_transport_adaptation()
    assert_h743_fft_capacity_upgrade()

    business_functions = [
        "_write",
        "FFT_StartMeasurement",
        "ADC_BlockIsClipped",
        "ADC_EstimateRawTone",
        "App_SetMeasurementUnavailable",
        "App_EstimateFundamentalHz",
    ]
    for function_name in business_functions:
        assert_function_equal(function_name)

    assert_calibration_function_equal()
    assert_w25q64_calibration_persistence()
    assert_uart_function_equal()
    assert_main_loop_equal()

    report = {
        "status": "PASS",
        "f407_source": str(F407_ROOT),
        "h743_target": str(H743_ROOT),
        "application_files_checked": equal_files,
        "business_functions_checked": business_functions
        + ["App_UpdateFrontendCalibration", "uart_proc"],
        "main_loop_checked": True,
        "uart_protocol_checked_strictly": True,
        "hmi_transparent_transport_protection_checked": True,
        "target_calibration_adaptation_checked": True,
        "w25q64_calibration_persistence_checked": True,
        "h743_full_rate_fir_adaptation_checked": True,
        "h743_16384_point_fft_upgrade_checked": True,
        "generic_waveform_reporting_checked": True,
        "normalized_platform_adaptations": [
            "STM32F4 HAL include -> STM32H7 HAL include",
            "USART1/DR -> USART2/RDR",
            "F407 ADC2/ADC3 explicit stop removed for H743 dual-mode HAL",
            "sampling-rate constants remain target-specific",
            "6 MSPS FIR output is retained 1:1 without decimation",
            "500 kHz calibration reference adapted to 0.100 Vpp and 0 V offset",
            "CRC-validated gain and bias persist in alternating W25Q64 sectors",
            "16384-point real FFT uses two packed 8192-point real FFTs backed by CMSIS 4096-point complex FFT",
            "external 3.3 V drives VREF+ while internal VREFBUF remains high impedance",
            "all eighteen 16384-point filtered captures are phase-aligned and folded into one 1024-point measured cycle",
            "the eighteen 16384-point spectra are power-averaged before the 1024-point spectrum graph is generated",
            "eighteen Vpp estimates discard the four largest and four smallest values before averaging",
            "the supplied addt example is retained with buffered USART2 receive protection",
        ],
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False))
        raise
