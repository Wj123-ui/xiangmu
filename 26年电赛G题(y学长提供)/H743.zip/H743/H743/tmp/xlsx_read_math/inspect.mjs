import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const path = "C:/Users/dell/Downloads/H743/H743/outputs/stm32h743_batch_test_plan/STM32H743_现场测试数据填写表.xlsx";
const input = await FileBlob.load(path);
const wb = await SpreadsheetFile.importXlsx(input);
const sheets = await wb.inspect({ kind: "sheet", include: "id,name", maxChars: 8000 });
console.log("SHEETS");
console.log(sheets.ndjson);
for (const name of ["测试填写表"]) {
  const sheet = wb.worksheets.getItem(name);
  const used = sheet.getUsedRange();
  console.log(`USED ${name}`, used?.address ?? "none");
  if (used) {
    const region = await wb.inspect({
      kind: "region",
      sheetId: name,
      range: used.address,
      include: "values,formulas",
      maxChars: 50000,
      tableMaxRows: 100,
      tableMaxCols: 60,
      tableMaxCellChars: 200,
    });
    console.log(`REGION ${name}`);
    console.log(region.ndjson);
  }
}
