#ifndef SIGNAL_FFT_H
#define SIGNAL_FFT_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include <stdint.h>

#include "signal_config.h"

/*
 * H743 performance upgrade: analyse 16384 decimated samples per frame.
 * The bundled CMSIS-DSP library exposes a 4096-point complex FFT.  The
 * implementation first forms two mathematically exact 8192-point real FFTs
 * from the even/odd input streams, then combines them into the equivalent
 * 16384-point real FFT without changing the output protocol.
 */
#define SIGNAL_FFT_SIZE 16384U
#define SIGNAL_FFT_SPECTRUM_BIN_COUNT ((SIGNAL_FFT_SIZE / 2U) + 1U)
/* Preserve enough independently detected components for non-template,
 * asymmetric periodic waveforms.  This controls reportable spectral peaks;
 * the time-wave output itself uses the complete filtered sample record. */
#define SIGNAL_FFT_MAX_PEAKS 12U

typedef struct
{
    float sample_rate_hz;
    float minimum_frequency_hz;
    float maximum_frequency_hz;
    float minimum_peak_amplitude;
    float noise_threshold_multiplier;
    uint8_t maximum_peak_count;
    uint8_t peak_separation_bins;
    uint8_t peak_energy_half_width_bins;
} signal_fft_config_t;

typedef struct
{
    uint16_t bin_index;
    uint16_t harmonic_order;
    float bin_position;
    float frequency_hz;
    float amplitude_peak;
    float phase_radians;
} signal_fft_peak_t;

typedef struct
{
    float input_mean;
    float input_peak_to_peak;
    float input_rms;
    float voltage_peak_to_peak;
    float voltage_rms;
    float fundamental_frequency_hz;
    float frequency_bin_width_hz;
    float estimated_noise_floor;
    uint8_t peak_count;
    uint8_t square_wave_detected;
    signal_fft_peak_t peaks[SIGNAL_FFT_MAX_PEAKS];
} signal_fft_result_t;

bool Signal_FFT_Init(const signal_fft_config_t *config);
bool Signal_FFT_Analyze(const float *samples,
                        signal_fft_result_t *result);

const float *Signal_FFT_GetSpectrum(uint32_t *bin_count);
float Signal_FFT_BinToFrequency(float bin_position);
const signal_fft_config_t *Signal_FFT_GetConfig(void);

#ifdef __cplusplus
}
#endif

#endif
