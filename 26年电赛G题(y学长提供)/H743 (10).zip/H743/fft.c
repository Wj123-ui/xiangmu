#include "fft.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

#define FFT_PI_F          3.14159265358979323846f
#define FFT_TWO_PI_F      (2.0f * FFT_PI_F)
#define FFT_SMALL_VALUE   1.0e-20f
#define FFT_MAX_LOCAL_PEAKS  64U

static uint8_t FFT_IsPowerOfTwo(uint32_t value)
{
  return (uint8_t)((value != 0U) && ((value & (value - 1U)) == 0U));
}

static float32_t FFT_Hann(uint32_t index, uint32_t length)
{
  if (length <= 1U)
  {
    return 1.0f;
  }

  return 0.5f -
         (0.5f * cosf(FFT_TWO_PI_F * (float32_t)index /
                      (float32_t)(length - 1U)));
}

static FFT_Status FFT_ValidateConfig(
    const FFT_Config *config)
{
  if (config == NULL)
  {
    return FFT_BAD_ARGUMENT;
  }

  if ((!isfinite(config->sample_rate_hz)) ||
      (config->sample_rate_hz <= 0.0f) ||
      (config->fft_size < 32U) ||
      (config->fft_size > FFT_MAX_SIZE) ||
      (FFT_IsPowerOfTwo(config->fft_size) == 0U) ||
      (!isfinite(config->adc_zero_code)) ||
      (!isfinite(config->adc_volts_per_count)) ||
      (config->adc_volts_per_count <= 0.0f) ||
      (!isfinite(config->analysis_min_frequency_hz)) ||
      (!isfinite(config->analysis_max_frequency_hz)) ||
      (config->analysis_min_frequency_hz < 0.0f) ||
      (config->analysis_max_frequency_hz <=
       config->analysis_min_frequency_hz) ||
      (config->analysis_max_frequency_hz >
       (0.5f * config->sample_rate_hz)) ||
      (!isfinite(config->minimum_peak_amplitude_v)) ||
      (config->minimum_peak_amplitude_v < 0.0f) ||
      (!isfinite(config->relative_peak_threshold)) ||
      (config->relative_peak_threshold < 0.0f) ||
      (config->relative_peak_threshold > 1.0f) ||
      (config->maximum_peak_count == 0U) ||
      (config->maximum_peak_count > FFT_MAX_PEAKS) ||
      (config->waveform_display_points < 2U) ||
      (config->waveform_display_points >
       FFT_MAX_WAVE_POINTS) ||
      (config->spectrum_display_points < 2U) ||
      (config->spectrum_display_points >
       FFT_MAX_SPECTRUM_POINTS))
  {
    return FFT_BAD_CONFIG;
  }

  if (config->lowpass_enabled != 0U)
  {
    if ((!isfinite(config->lowpass_cutoff_hz)) ||
        (config->lowpass_cutoff_hz <= 0.0f) ||
        (config->lowpass_cutoff_hz >=
         (0.5f * config->sample_rate_hz)) ||
        (config->lowpass_order < 2U) ||
        (config->lowpass_order > LPF_MAX_ORDER) ||
        ((config->lowpass_order & 1U) != 0U))
    {
      return FFT_BAD_CONFIG;
    }
  }

  return FFT_OK;
}

FFT_Config FFT_DefaultConfig(float32_t sample_rate_hz)
{
  FFT_Config config;

  memset(&config, 0, sizeof(config));
  config.sample_rate_hz = sample_rate_hz;
  config.fft_size = 4096U;
  config.adc_zero_code = 2047.5f;
  config.adc_volts_per_count = 3.3f / 4095.0f;
  config.remove_dc = 1U;

  config.lowpass_enabled = 1U;
  config.lowpass_order = 8U;
  config.correct_lowpass_gain = 1U;
  config.lowpass_cutoff_hz = 650000.0f;

  config.analysis_min_frequency_hz = 10000.0f;
  config.analysis_max_frequency_hz = 500000.0f;
  config.minimum_peak_amplitude_v = 0.001f;
  config.relative_peak_threshold = 0.01f;
  config.maximum_peak_count = 6U;
  config.peak_separation_bins = 6U;

  config.waveform_display_points =
      (uint16_t)FFT_MAX_WAVE_POINTS;
  config.spectrum_display_points =
      (uint16_t)FFT_MAX_SPECTRUM_POINTS;
  return config;
}

FFT_Status FFT_Init(
    FFT_Handle *analyzer,
    const FFT_Config *config)
{
  FFT_Status status;

  if (analyzer == NULL)
  {
    return FFT_BAD_ARGUMENT;
  }

  status = FFT_ValidateConfig(config);
  if (status != FFT_OK)
  {
    return status;
  }

  memset(analyzer, 0, sizeof(*analyzer));
  analyzer->config = *config;

  if (arm_rfft_fast_init_f32(&analyzer->rfft,
                             analyzer->config.fft_size) != ARM_MATH_SUCCESS)
  {
    return FFT_INIT_FAILED;
  }

  if (analyzer->config.lowpass_enabled != 0U)
  {
    if (LPF_Init(&analyzer->lowpass,
                        analyzer->config.sample_rate_hz,
                        analyzer->config.lowpass_cutoff_hz,
                        analyzer->config.lowpass_order) != LPF_OK)
    {
      return FFT_FILTER_FAILED;
    }
  }

  analyzer->initialized = 1U;
  return FFT_OK;
}

void FFT_ResetFilter(FFT_Handle *analyzer)
{
  if ((analyzer == NULL) || (analyzer->initialized == 0U) ||
      (analyzer->config.lowpass_enabled == 0U))
  {
    return;
  }

  LPF_Reset(&analyzer->lowpass);
}

static void FFT_RemoveMean(float32_t *samples,
                                      uint32_t sample_count,
                                      float32_t *removed_mean)
{
  float32_t mean = 0.0f;

  arm_mean_f32(samples, sample_count, &mean);
  arm_offset_f32(samples, -mean, samples, sample_count);
  if (removed_mean != NULL)
  {
    *removed_mean = mean;
  }
}

static float32_t FFT_FilterCorrection(
    const FFT_Handle *analyzer,
    float32_t frequency_hz)
{
  float32_t gain;

  if ((analyzer->config.lowpass_enabled == 0U) ||
      (analyzer->config.correct_lowpass_gain == 0U))
  {
    return 1.0f;
  }

  gain = LPF_GetGain(&analyzer->lowpass, frequency_hz);
  if (gain < 0.05f)
  {
    return 1.0f;
  }
  return 1.0f / gain;
}

static void FFT_CalculateSpectrum(
    FFT_Handle *analyzer,
    FFT_Result *result,
    float32_t *window_sum_out)
{
  uint32_t n;
  uint32_t k;
  uint32_t fft_size = analyzer->config.fft_size;
  uint32_t half_size = fft_size / 2U;
  float32_t window_sum = 0.0f;

  for (n = 0U; n < fft_size; ++n)
  {
    float32_t window = FFT_Hann(n, fft_size);
    window_sum += window;
    /*
     * input_work is no longer needed after filtering, so reuse it as the FFT
     * input buffer instead of reserving another fft_size-float workspace.
     */
    analyzer->input_work[n] = result->waveform_v[n] * window;
  }

  arm_rfft_fast_f32(&analyzer->rfft,
                    analyzer->input_work,
                    analyzer->fft_output,
                    0U);

  result->spectrum_amplitude_v[0] =
      fabsf(analyzer->fft_output[0]);
  if (half_size > 1U)
  {
    arm_cmplx_mag_f32(&analyzer->fft_output[2],
                      &result->spectrum_amplitude_v[1],
                      half_size - 1U);
  }
  result->spectrum_amplitude_v[half_size] =
      fabsf(analyzer->fft_output[1]);

  for (k = 0U; k <= half_size; ++k)
  {
    float32_t frequency =
        (float32_t)k * analyzer->config.sample_rate_hz /
        (float32_t)fft_size;
    float32_t scale = ((k == 0U) || (k == half_size))
                          ? (1.0f / window_sum)
                          : (2.0f / window_sum);
    float32_t amplitude = result->spectrum_amplitude_v[k] * scale;

    if (frequency <= analyzer->config.analysis_max_frequency_hz)
    {
      amplitude *= FFT_FilterCorrection(analyzer, frequency);
    }

    result->spectrum_frequency_hz[k] = frequency;
    result->spectrum_amplitude_v[k] = amplitude;
  }

  result->spectrum_bin_count = (uint16_t)(half_size + 1U);
  result->spectrum_bin_width_hz =
      analyzer->config.sample_rate_hz / (float32_t)fft_size;
  *window_sum_out = window_sum;
}

static float32_t FFT_RefineBin(
    const FFT_Result *result,
    uint32_t bin)
{
  float32_t left =
      logf(result->spectrum_amplitude_v[bin - 1U] + FFT_SMALL_VALUE);
  float32_t center =
      logf(result->spectrum_amplitude_v[bin] + FFT_SMALL_VALUE);
  float32_t right =
      logf(result->spectrum_amplitude_v[bin + 1U] + FFT_SMALL_VALUE);
  float32_t denominator = left - (2.0f * center) + right;
  float32_t offset;

  if (fabsf(denominator) < FFT_SMALL_VALUE)
  {
    return 0.0f;
  }

  offset = 0.5f * (left - right) / denominator;
  if (offset > 0.5f)
  {
    offset = 0.5f;
  }
  else if (offset < -0.5f)
  {
    offset = -0.5f;
  }
  return offset;
}

static void FFT_ProjectedAmplitudePhase(
    const FFT_Handle *analyzer,
    const FFT_Result *result,
    float32_t frequency_hz,
    float32_t window_sum,
    float32_t *amplitude_v,
    float32_t *phase_rad)
{
  uint32_t n;
  uint32_t fft_size = analyzer->config.fft_size;
  float32_t real_sum = 0.0f;
  float32_t imaginary_sum = 0.0f;
  float32_t omega =
      FFT_TWO_PI_F * frequency_hz / analyzer->config.sample_rate_hz;

  for (n = 0U; n < fft_size; ++n)
  {
    float32_t window = FFT_Hann(n, fft_size);
    float32_t angle = omega * (float32_t)n;
    float32_t value = result->waveform_v[n] * window;

    real_sum += value * cosf(angle);
    imaginary_sum -= value * sinf(angle);
  }

  *amplitude_v =
      (2.0f * sqrtf((real_sum * real_sum) +
                    (imaginary_sum * imaginary_sum)) /
       window_sum) *
      FFT_FilterCorrection(analyzer, frequency_hz);
  *phase_rad = atan2f(imaginary_sum, real_sum);
}

static void FFT_InsertCandidate(uint16_t bin,
                                           float32_t amplitude,
                                           uint16_t *bins,
                                           float32_t *amplitudes,
                                           uint8_t *count,
                                           uint8_t capacity)
{
  uint8_t position;
  uint8_t move;

  if (capacity == 0U)
  {
    return;
  }

  position = 0U;
  while ((position < *count) && (amplitudes[position] >= amplitude))
  {
    ++position;
  }

  if ((position >= capacity) && (*count >= capacity))
  {
    return;
  }

  if (*count < capacity)
  {
    ++(*count);
  }

  move = (uint8_t)(*count - 1U);
  while (move > position)
  {
    bins[move] = bins[move - 1U];
    amplitudes[move] = amplitudes[move - 1U];
    --move;
  }

  bins[position] = bin;
  amplitudes[position] = amplitude;
}

static uint8_t FFT_BinIsSeparated(uint16_t bin,
                                             const uint16_t *bins,
                                             uint8_t count,
                                             uint8_t separation)
{
  uint8_t i;

  for (i = 0U; i < count; ++i)
  {
    uint16_t distance = (bin > bins[i]) ? (bin - bins[i])
                                        : (bins[i] - bin);
    if (distance <= (uint16_t)separation)
    {
      return 0U;
    }
  }
  return 1U;
}

static void FFT_SortPeaksByFrequency(
    FFT_Peak *peaks,
    uint8_t peak_count)
{
  uint8_t i;

  for (i = 1U; i < peak_count; ++i)
  {
    FFT_Peak key = peaks[i];
    uint8_t j = i;

    while ((j > 0U) && (peaks[j - 1U].frequency_hz > key.frequency_hz))
    {
      peaks[j] = peaks[j - 1U];
      --j;
    }
    peaks[j] = key;
  }
}

static void FFT_FindPeaks(FFT_Handle *analyzer,
                                     FFT_Result *result,
                                     float32_t window_sum)
{
  uint32_t k;
  uint32_t min_bin;
  uint32_t max_bin;
  uint32_t peak_search_bin;
  uint16_t local_peak_bins[FFT_MAX_LOCAL_PEAKS];
  float32_t local_peak_amplitudes[FFT_MAX_LOCAL_PEAKS];
  uint16_t selected_bins[FFT_MAX_PEAKS];
  float32_t maximum_amplitude = 0.0f;
  float32_t threshold;
  uint8_t local_peak_count = 0U;
  uint8_t selected_count = 0U;
  uint8_t i;

  memset(local_peak_bins, 0, sizeof(local_peak_bins));
  memset(local_peak_amplitudes, 0, sizeof(local_peak_amplitudes));
  memset(selected_bins, 0, sizeof(selected_bins));

  min_bin = (uint32_t)ceilf(
      analyzer->config.analysis_min_frequency_hz /
      result->spectrum_bin_width_hz);
  max_bin = (uint32_t)floorf(
      analyzer->config.analysis_max_frequency_hz /
      result->spectrum_bin_width_hz);

  if (min_bin < 1U)
  {
    min_bin = 1U;
  }
  if (max_bin >= ((uint32_t)result->spectrum_bin_count - 1U))
  {
    max_bin = (uint32_t)result->spectrum_bin_count - 2U;
  }

  for (k = min_bin; k <= max_bin; ++k)
  {
    if (result->spectrum_amplitude_v[k] > maximum_amplitude)
    {
      maximum_amplitude = result->spectrum_amplitude_v[k];
    }
  }

  threshold = analyzer->config.minimum_peak_amplitude_v;
  if ((maximum_amplitude * analyzer->config.relative_peak_threshold) >
      threshold)
  {
    threshold =
        maximum_amplitude * analyzer->config.relative_peak_threshold;
  }

  for (peak_search_bin = min_bin;
       peak_search_bin <= max_bin;
       ++peak_search_bin)
  {
    float32_t amplitude =
        result->spectrum_amplitude_v[peak_search_bin];

    if ((amplitude >= threshold) &&
        (amplitude > result->spectrum_amplitude_v[peak_search_bin - 1U]) &&
        (amplitude >= result->spectrum_amplitude_v[peak_search_bin + 1U]))
    {
      FFT_InsertCandidate(
          (uint16_t)peak_search_bin,
          amplitude,
          local_peak_bins,
          local_peak_amplitudes,
          &local_peak_count,
          FFT_MAX_LOCAL_PEAKS);
    }
  }

  /*
   * Local maxima were sorted by amplitude. Apply non-maximum suppression in
   * that order so a weak window side lobe can never hide its stronger main
   * lobe merely because the side lobe occurred at a lower FFT bin.
   */
  for (i = 0U;
       (i < local_peak_count) &&
       (selected_count < analyzer->config.maximum_peak_count);
       ++i)
  {
    if (FFT_BinIsSeparated(
            local_peak_bins[i],
            selected_bins,
            selected_count,
            analyzer->config.peak_separation_bins) != 0U)
    {
      selected_bins[selected_count] = local_peak_bins[i];
      ++selected_count;
    }
  }

  result->peak_count = selected_count;
  for (i = 0U; i < selected_count; ++i)
  {
    uint32_t bin = selected_bins[i];
    float32_t bin_offset = FFT_RefineBin(result, bin);
    float32_t frequency =
        ((float32_t)bin + bin_offset) * result->spectrum_bin_width_hz;
    FFT_Peak *peak = &result->peaks[i];

    peak->bin_index = (uint16_t)bin;
    peak->bin_offset = bin_offset;
    peak->frequency_hz = frequency;
    FFT_ProjectedAmplitudePhase(analyzer,
                                           result,
                                           frequency,
                                           window_sum,
                                           &peak->amplitude_v,
                                           &peak->phase_rad);
  }

  FFT_SortPeaksByFrequency(result->peaks, result->peak_count);
  if (result->peak_count > 0U)
  {
    result->fundamental_hz = result->peaks[0].frequency_hz;
  }
}

static float32_t FFT_LinearSample(const float32_t *samples,
                                             uint32_t sample_count,
                                             float32_t index)
{
  uint32_t left;
  uint32_t right;
  float32_t fraction;

  if (index <= 0.0f)
  {
    return samples[0];
  }
  if (index >= (float32_t)(sample_count - 1U))
  {
    return samples[sample_count - 1U];
  }

  left = (uint32_t)floorf(index);
  right = left + 1U;
  fraction = index - (float32_t)left;
  return samples[left] +
         (fraction * (samples[right] - samples[left]));
}

static FFT_Status FFT_CreateWaveformViews(
    const FFT_Handle *analyzer,
    FFT_Result *result)
{
  uint32_t i;
  uint32_t count = analyzer->config.waveform_display_points;
  float32_t phase;
  float32_t omega;
  float32_t trigger_index;
  float32_t one_period;

  if ((result->peak_count == 0U) || (result->fundamental_hz <= 0.0f))
  {
    return FFT_NO_SIGNAL;
  }

  one_period =
      analyzer->config.sample_rate_hz / result->fundamental_hz;
  if ((3.0f * one_period) >
      (float32_t)(analyzer->config.fft_size - 1U))
  {
    return FFT_CAPTURE_TOO_SHORT;
  }

  /*
   * The fundamental DFT phase is referenced to sample zero and expressed as
   * a cosine phase. A rising zero crossing occurs at 3*pi/2.
   */
  phase = result->peaks[0].phase_rad;
  omega = FFT_TWO_PI_F * result->fundamental_hz /
          analyzer->config.sample_rate_hz;
  trigger_index = (1.5f * FFT_PI_F - phase) / omega;
  trigger_index = fmodf(trigger_index, one_period);
  if (trigger_index < 0.0f)
  {
    trigger_index += one_period;
  }

  if ((trigger_index + (3.0f * one_period)) >
      (float32_t)(analyzer->config.fft_size - 1U))
  {
    trigger_index = 0.0f;
  }

  for (i = 0U; i < count; ++i)
  {
    float32_t normalized =
        (float32_t)i / (float32_t)(count - 1U);
    result->one_cycle_v[i] =
        FFT_LinearSample(
            result->waveform_v,
            analyzer->config.fft_size,
            trigger_index + (normalized * one_period));
    result->three_cycle_v[i] =
        FFT_LinearSample(
            result->waveform_v,
            analyzer->config.fft_size,
            trigger_index + (3.0f * normalized * one_period));
  }

  result->waveform_display_count = (uint16_t)count;
  result->samples_per_period = one_period;
  result->one_cycle_duration_s = 1.0f / result->fundamental_hz;
  result->three_cycle_duration_s =
      3.0f / result->fundamental_hz;
  return FFT_OK;
}

static void FFT_CreateSpectrumView(
    const FFT_Handle *analyzer,
    FFT_Result *result)
{
  uint32_t point;
  uint32_t point_count = analyzer->config.spectrum_display_points;
  uint32_t maximum_bin = (uint32_t)floorf(
      analyzer->config.analysis_max_frequency_hz /
      result->spectrum_bin_width_hz);
  uint32_t available_bin_count;

  if (maximum_bin >= (uint32_t)result->spectrum_bin_count)
  {
    maximum_bin = (uint32_t)result->spectrum_bin_count - 1U;
  }
  available_bin_count = maximum_bin + 1U;

  for (point = 0U; point < point_count; ++point)
  {
    uint32_t first_bin =
        (point * available_bin_count) / point_count;
    uint32_t end_bin =
        ((point + 1U) * available_bin_count) / point_count;
    uint32_t bin;
    uint32_t max_amplitude_bin;
    float32_t max_amplitude;

    if (end_bin <= first_bin)
    {
      end_bin = first_bin + 1U;
    }
    if (end_bin > available_bin_count)
    {
      end_bin = available_bin_count;
    }

    max_amplitude_bin = first_bin;
    max_amplitude = result->spectrum_amplitude_v[first_bin];
    for (bin = first_bin + 1U; bin < end_bin; ++bin)
    {
      if (result->spectrum_amplitude_v[bin] > max_amplitude)
      {
        max_amplitude = result->spectrum_amplitude_v[bin];
        max_amplitude_bin = bin;
      }
    }

    result->spectrum_display_frequency_hz[point] =
        result->spectrum_frequency_hz[max_amplitude_bin];
    result->spectrum_display_amplitude_v[point] = max_amplitude;
  }

  result->spectrum_display_count = (uint16_t)point_count;
}

static FFT_Status FFT_ProcessPrepared(
    FFT_Handle *analyzer,
    FFT_Result *result,
    float32_t dc_offset)
{
  FFT_Status waveform_status;
  uint32_t fft_size = analyzer->config.fft_size;
  float32_t residual_mean = 0.0f;
  float32_t minimum = 0.0f;
  float32_t maximum = 0.0f;
  float32_t window_sum = 0.0f;
  uint32_t minimum_index = 0U;
  uint32_t maximum_index = 0U;

  memset(result, 0, sizeof(*result));
  result->fft_size = (uint16_t)fft_size;
  result->sample_period_s = 1.0f / analyzer->config.sample_rate_hz;
  result->dc_offset_v = dc_offset;

  if (analyzer->config.lowpass_enabled != 0U)
  {
    if (LPF_Process(&analyzer->lowpass,
                           analyzer->input_work,
                           result->waveform_v,
                           fft_size) != LPF_OK)
    {
      result->status = FFT_FILTER_FAILED;
      return result->status;
    }
  }
  else
  {
    arm_copy_f32(analyzer->input_work,
                 result->waveform_v,
                 fft_size);
  }

  if (analyzer->config.remove_dc != 0U)
  {
    FFT_RemoveMean(result->waveform_v,
                              fft_size,
                              &residual_mean);
    result->dc_offset_v += residual_mean;
  }

  arm_min_f32(result->waveform_v,
              fft_size,
              &minimum,
              &minimum_index);
  arm_max_f32(result->waveform_v,
              fft_size,
              &maximum,
              &maximum_index);
  arm_rms_f32(result->waveform_v,
              fft_size,
              &result->true_rms_v);
  result->peak_to_peak_v = maximum - minimum;

  FFT_CalculateSpectrum(analyzer, result, &window_sum);
  FFT_FindPeaks(analyzer, result, window_sum);
  FFT_CreateSpectrumView(analyzer, result);
  waveform_status = FFT_CreateWaveformViews(analyzer, result);

  result->status = waveform_status;
  return result->status;
}

FFT_Status FFT_ProcessADC(
    FFT_Handle *analyzer,
    const uint16_t *adc_samples,
    uint32_t sample_count,
    FFT_Result *result)
{
  uint32_t i;
  uint32_t fft_size;
  float32_t mean = 0.0f;

  if ((analyzer == NULL) || (adc_samples == NULL) || (result == NULL) ||
      (analyzer->initialized == 0U))
  {
    return FFT_BAD_ARGUMENT;
  }

  fft_size = analyzer->config.fft_size;
  if (sample_count < fft_size)
  {
    memset(result, 0, sizeof(*result));
    result->status = FFT_CAPTURE_TOO_SHORT;
    return result->status;
  }

  for (i = 0U; i < fft_size; ++i)
  {
    analyzer->input_work[i] =
        ((float32_t)adc_samples[i] - analyzer->config.adc_zero_code) *
        analyzer->config.adc_volts_per_count;
  }

  if (analyzer->config.remove_dc != 0U)
  {
    FFT_RemoveMean(analyzer->input_work, fft_size, &mean);
  }
  return FFT_ProcessPrepared(analyzer, result, mean);
}

FFT_Status FFT_Process(
    FFT_Handle *analyzer,
    const float32_t *input_volts,
    uint32_t sample_count,
    FFT_Result *result)
{
  uint32_t fft_size;
  float32_t mean = 0.0f;

  if ((analyzer == NULL) || (input_volts == NULL) || (result == NULL) ||
      (analyzer->initialized == 0U))
  {
    return FFT_BAD_ARGUMENT;
  }

  fft_size = analyzer->config.fft_size;
  if (sample_count < fft_size)
  {
    memset(result, 0, sizeof(*result));
    result->status = FFT_CAPTURE_TOO_SHORT;
    return result->status;
  }

  arm_copy_f32(input_volts, analyzer->input_work, fft_size);
  if (analyzer->config.remove_dc != 0U)
  {
    FFT_RemoveMean(analyzer->input_work, fft_size, &mean);
  }
  return FFT_ProcessPrepared(analyzer, result, mean);
}
