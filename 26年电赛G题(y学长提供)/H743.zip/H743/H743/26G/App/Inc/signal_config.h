#ifndef SIGNAL_CONFIG_H
#define SIGNAL_CONFIG_H

/*
 * STM32H743 ADC1/ADC2 dual-interleaved sampling:
 * 24 MHz ADC clock / 4-cycle uniform interleave phase = 6.0000000 MSPS.
 * The complete 6.0000000 MSPS stream is retained for the 16384-point FFT.
 * A runtime 6.0/4.8 MSPS selector rejects alias ambiguity before the
 * linear-phase FIR.  The compiled constants remain the 6 MSPS startup mode.
 */
#define SIGNAL_ADC_SAMPLE_RATE_HZ      (24000000.0f / 4.0f)
#define SIGNAL_DECIMATION_FACTOR       1U
#define SIGNAL_ANALYSIS_SAMPLE_RATE_HZ \
    (SIGNAL_ADC_SAMPLE_RATE_HZ / (float)SIGNAL_DECIMATION_FACTOR)
#define SIGNAL_MINIMUM_FREQUENCY_HZ 9000.0f
#define SIGNAL_MAXIMUM_FREQUENCY_HZ 550000.0f

#endif
