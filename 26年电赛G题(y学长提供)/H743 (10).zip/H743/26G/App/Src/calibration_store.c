#include "calibration_store.h"

#include "main.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

/* Two sectors at the end of the 8 MiB W25Q64 form an alternating store.
 * An interrupted update therefore leaves the previous valid record intact. */
#define W25Q64_CAPACITY_BYTES       0x00800000UL
#define W25Q64_SECTOR_SIZE          0x00001000UL
#define CALIBRATION_SECTOR_A        0x007FE000UL
#define CALIBRATION_SECTOR_B        0x007FF000UL

#define W25Q64_CMD_WRITE_ENABLE     0x06U
#define W25Q64_CMD_READ_STATUS_1    0x05U
#define W25Q64_CMD_READ_DATA        0x03U
#define W25Q64_CMD_PAGE_PROGRAM     0x02U
#define W25Q64_CMD_SECTOR_ERASE     0x20U
#define W25Q64_CMD_JEDEC_ID         0x9FU
#define W25Q64_CMD_RESET_ENABLE     0x66U
#define W25Q64_CMD_RESET            0x99U

#define W25Q64_STATUS_BUSY          0x01U
#define W25Q64_STATUS_WEL           0x02U
#define W25Q64_EXPECTED_JEDEC_ID    0x00EF4017UL

#define CALIBRATION_MAGIC           0x314C4143UL /* "CAL1" */
#define CALIBRATION_VERSION         1U
#define QSPI_COMMAND_TIMEOUT_MS     100U
#define W25Q64_PROGRAM_TIMEOUT_MS   500U
#define W25Q64_ERASE_TIMEOUT_MS     5000U

typedef struct
{
    uint32_t magic;
    uint16_t version;
    uint16_t length;
    uint32_t sequence;
    float gain;
    float bias_voltage;
    uint32_t crc32;
} calibration_record_t;

_Static_assert(sizeof(calibration_record_t) == 24U,
               "Calibration record layout changed");
_Static_assert(CALIBRATION_SECTOR_B + W25Q64_SECTOR_SIZE ==
                   W25Q64_CAPACITY_BYTES,
               "Calibration sectors must end at W25Q64 capacity");

volatile uint32_t calibration_store_status;
volatile uint32_t calibration_store_jedec_id;
volatile uint32_t calibration_store_sequence;

static uint32_t active_record_address = UINT32_MAX;

static bool QSPI_WaitNotBusy(uint32_t timeout_ms)
{
    const uint32_t start = HAL_GetTick();

    while ((QUADSPI->SR & QUADSPI_SR_BUSY) != 0U)
    {
        if ((HAL_GetTick() - start) >= timeout_ms)
        {
            return false;
        }
    }

    return true;
}

static bool QSPI_WaitTransferComplete(uint32_t timeout_ms)
{
    const uint32_t start = HAL_GetTick();

    while ((QUADSPI->SR & QUADSPI_SR_TCF) == 0U)
    {
        if ((QUADSPI->SR & QUADSPI_SR_TEF) != 0U)
        {
            QUADSPI->FCR = QUADSPI_FCR_CTEF | QUADSPI_FCR_CTCF;
            return false;
        }

        if ((HAL_GetTick() - start) >= timeout_ms)
        {
            QUADSPI->CR |= QUADSPI_CR_ABORT;
            (void)QSPI_WaitNotBusy(QSPI_COMMAND_TIMEOUT_MS);
            QUADSPI->FCR = QUADSPI_FCR_CTEF | QUADSPI_FCR_CTCF;
            return false;
        }
    }

    QUADSPI->FCR = QUADSPI_FCR_CTCF | QUADSPI_FCR_CTEF;
    return true;
}

static uint32_t QSPI_MakeCcr(uint8_t instruction,
                             bool has_address,
                             bool has_data,
                             bool read)
{
    uint32_t ccr = (uint32_t)instruction | QUADSPI_CCR_IMODE_0;

    if (has_address)
    {
        ccr |= QUADSPI_CCR_ADMODE_0 | QUADSPI_CCR_ADSIZE_1;
    }
    if (has_data)
    {
        ccr |= QUADSPI_CCR_DMODE_0;
    }
    if (read)
    {
        ccr |= QUADSPI_CCR_FMODE_0;
    }

    return ccr;
}

static bool QSPI_CommandOnly(uint8_t instruction,
                             uint32_t address,
                             bool has_address)
{
    if (!QSPI_WaitNotBusy(QSPI_COMMAND_TIMEOUT_MS))
    {
        return false;
    }

    QUADSPI->FCR = QUADSPI_FCR_CTCF | QUADSPI_FCR_CTEF |
                   QUADSPI_FCR_CSMF | QUADSPI_FCR_CTOF;
    QUADSPI->DLR = 0U;
    QUADSPI->CCR = QSPI_MakeCcr(instruction,
                                has_address,
                                false,
                                false);
    if (has_address)
    {
        QUADSPI->AR = address;
    }

    return QSPI_WaitTransferComplete(QSPI_COMMAND_TIMEOUT_MS);
}

static bool QSPI_Read(uint8_t instruction,
                      uint32_t address,
                      bool has_address,
                      uint8_t *data,
                      uint32_t length)
{
    uint32_t index;

    if ((data == NULL) || (length == 0U) ||
        (!QSPI_WaitNotBusy(QSPI_COMMAND_TIMEOUT_MS)))
    {
        return false;
    }

    QUADSPI->FCR = QUADSPI_FCR_CTCF | QUADSPI_FCR_CTEF |
                   QUADSPI_FCR_CSMF | QUADSPI_FCR_CTOF;
    QUADSPI->DLR = length - 1U;
    QUADSPI->CCR = QSPI_MakeCcr(instruction,
                                has_address,
                                true,
                                true);
    if (has_address)
    {
        QUADSPI->AR = address;
    }

    for (index = 0U; index < length; index++)
    {
        const uint32_t start = HAL_GetTick();

        while ((QUADSPI->SR & QUADSPI_SR_FLEVEL) == 0U)
        {
            if ((QUADSPI->SR & QUADSPI_SR_TEF) != 0U)
            {
                QUADSPI->FCR = QUADSPI_FCR_CTEF |
                               QUADSPI_FCR_CTCF;
                return false;
            }
            if ((HAL_GetTick() - start) >= QSPI_COMMAND_TIMEOUT_MS)
            {
                QUADSPI->CR |= QUADSPI_CR_ABORT;
                (void)QSPI_WaitNotBusy(QSPI_COMMAND_TIMEOUT_MS);
                return false;
            }
        }

        data[index] = *(__IO uint8_t *)&QUADSPI->DR;
    }

    return QSPI_WaitTransferComplete(QSPI_COMMAND_TIMEOUT_MS);
}

static bool QSPI_Write(uint8_t instruction,
                       uint32_t address,
                       const uint8_t *data,
                       uint32_t length)
{
    uint32_t index;

    if ((data == NULL) || (length == 0U) ||
        (!QSPI_WaitNotBusy(QSPI_COMMAND_TIMEOUT_MS)))
    {
        return false;
    }

    QUADSPI->FCR = QUADSPI_FCR_CTCF | QUADSPI_FCR_CTEF |
                   QUADSPI_FCR_CSMF | QUADSPI_FCR_CTOF;
    QUADSPI->DLR = length - 1U;
    QUADSPI->CCR = QSPI_MakeCcr(instruction,
                                true,
                                true,
                                false);
    QUADSPI->AR = address;

    for (index = 0U; index < length; index++)
    {
        const uint32_t start = HAL_GetTick();

        while ((QUADSPI->SR & QUADSPI_SR_FTF) == 0U)
        {
            if ((QUADSPI->SR & QUADSPI_SR_TEF) != 0U)
            {
                QUADSPI->FCR = QUADSPI_FCR_CTEF |
                               QUADSPI_FCR_CTCF;
                return false;
            }
            if ((HAL_GetTick() - start) >= QSPI_COMMAND_TIMEOUT_MS)
            {
                QUADSPI->CR |= QUADSPI_CR_ABORT;
                (void)QSPI_WaitNotBusy(QSPI_COMMAND_TIMEOUT_MS);
                return false;
            }
        }

        *(__IO uint8_t *)&QUADSPI->DR = data[index];
    }

    return QSPI_WaitTransferComplete(QSPI_COMMAND_TIMEOUT_MS);
}

static bool QSPI_HardwareInit(void)
{
    GPIO_InitTypeDef gpio = {0};

    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOE_CLK_ENABLE();
    __HAL_RCC_QSPI_CLK_ENABLE();

    gpio.Pin = GPIO_PIN_2;
    gpio.Mode = GPIO_MODE_AF_PP;
    gpio.Pull = GPIO_NOPULL;
    gpio.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    gpio.Alternate = GPIO_AF9_QUADSPI;
    HAL_GPIO_Init(GPIOB, &gpio);

    gpio.Pin = GPIO_PIN_6;
    gpio.Alternate = GPIO_AF10_QUADSPI;
    HAL_GPIO_Init(GPIOB, &gpio);

    gpio.Pin = GPIO_PIN_11 | GPIO_PIN_12;
    gpio.Alternate = GPIO_AF9_QUADSPI;
    HAL_GPIO_Init(GPIOD, &gpio);

    /* Single-line SPI uses IO2 and IO3 as active-low /WP and /HOLD. */
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_2, GPIO_PIN_SET);
    gpio.Pin = GPIO_PIN_2;
    gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOE, &gpio);

    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);
    gpio.Pin = GPIO_PIN_13;
    HAL_GPIO_Init(GPIOD, &gpio);

    __HAL_RCC_QSPI_FORCE_RESET();
    __HAL_RCC_QSPI_RELEASE_RESET();

    /* D1 HCLK=240 MHz, PRESCALER=5 -> 40 MHz.  FSIZE=22 -> 8 MiB. */
    MODIFY_REG(RCC->D1CCIPR, RCC_D1CCIPR_QSPISEL, 0U);
    QUADSPI->CR = (5UL << QUADSPI_CR_PRESCALER_Pos);
    QUADSPI->DCR = (22UL << QUADSPI_DCR_FSIZE_Pos) |
                   (2UL << QUADSPI_DCR_CSHT_Pos);
    QUADSPI->CR |= QUADSPI_CR_EN;

    return QSPI_WaitNotBusy(QSPI_COMMAND_TIMEOUT_MS);
}

static bool W25Q64_ReadStatus(uint8_t *status)
{
    return QSPI_Read(W25Q64_CMD_READ_STATUS_1,
                     0U, false, status, 1U);
}

static bool W25Q64_WaitReady(uint32_t timeout_ms)
{
    const uint32_t start = HAL_GetTick();
    uint8_t status;

    do
    {
        if (!W25Q64_ReadStatus(&status))
        {
            return false;
        }
        if ((status & W25Q64_STATUS_BUSY) == 0U)
        {
            return true;
        }
    } while ((HAL_GetTick() - start) < timeout_ms);

    return false;
}

static bool W25Q64_WriteEnable(void)
{
    uint8_t status;

    return QSPI_CommandOnly(W25Q64_CMD_WRITE_ENABLE, 0U, false) &&
           W25Q64_ReadStatus(&status) &&
           ((status & W25Q64_STATUS_WEL) != 0U);
}

static bool W25Q64_Read(uint32_t address,
                        void *data,
                        uint32_t length)
{
    if ((address >= W25Q64_CAPACITY_BYTES) ||
        (length > (W25Q64_CAPACITY_BYTES - address)))
    {
        return false;
    }

    return QSPI_Read(W25Q64_CMD_READ_DATA, address, true,
                     (uint8_t *)data, length);
}

static bool W25Q64_EraseSector(uint32_t address)
{
    const uint32_t sector_address =
        address & ~(W25Q64_SECTOR_SIZE - 1UL);

    return W25Q64_WriteEnable() &&
           QSPI_CommandOnly(W25Q64_CMD_SECTOR_ERASE,
                            sector_address, true) &&
           W25Q64_WaitReady(W25Q64_ERASE_TIMEOUT_MS);
}

static bool W25Q64_Program(uint32_t address,
                           const void *data,
                           uint32_t length)
{
    if ((length == 0U) || (length > 256U) ||
        (((address & 0xFFU) + length) > 256U))
    {
        return false;
    }

    return W25Q64_WriteEnable() &&
           QSPI_Write(W25Q64_CMD_PAGE_PROGRAM, address,
                      (const uint8_t *)data, length) &&
           W25Q64_WaitReady(W25Q64_PROGRAM_TIMEOUT_MS);
}

static uint32_t CalibrationStore_Crc32(const void *data,
                                       uint32_t length)
{
    const uint8_t *bytes = (const uint8_t *)data;
    uint32_t crc = 0xFFFFFFFFUL;
    uint32_t index;

    for (index = 0U; index < length; index++)
    {
        uint8_t bit;

        crc ^= bytes[index];
        for (bit = 0U; bit < 8U; bit++)
        {
            crc = (crc >> 1U) ^
                  ((0U - (crc & 1U)) & 0xEDB88320UL);
        }
    }

    return ~crc;
}

static bool CalibrationStore_RecordValid(
    const calibration_record_t *record)
{
    uint32_t expected_crc;

    if ((record == NULL) ||
        (record->magic != CALIBRATION_MAGIC) ||
        (record->version != CALIBRATION_VERSION) ||
        (record->length != sizeof(*record)) ||
        (!isfinite(record->gain)) ||
        (!isfinite(record->bias_voltage)) ||
        (record->gain < 0.01F) || (record->gain > 100.0F) ||
        (record->bias_voltage < 0.0F) ||
        (record->bias_voltage > 3.6F))
    {
        return false;
    }

    expected_crc = CalibrationStore_Crc32(
        record,
        (uint32_t)offsetof(calibration_record_t, crc32));
    return expected_crc == record->crc32;
}

static bool CalibrationStore_SequenceNewer(uint32_t first,
                                           uint32_t second)
{
    return (int32_t)(first - second) > 0;
}

bool CalibrationStore_Init(float *gain, float *bias_voltage)
{
    calibration_record_t first;
    calibration_record_t second;
    const calibration_record_t *selected = NULL;
    bool first_valid;
    bool second_valid;
    uint8_t id[3];

    calibration_store_status = 0U;
    calibration_store_jedec_id = 0U;
    calibration_store_sequence = 0U;
    active_record_address = UINT32_MAX;

    if ((gain == NULL) || (bias_voltage == NULL) ||
        (!QSPI_HardwareInit()) ||
        (!QSPI_CommandOnly(W25Q64_CMD_RESET_ENABLE, 0U, false)) ||
        (!QSPI_CommandOnly(W25Q64_CMD_RESET, 0U, false)))
    {
        calibration_store_status = CALIBRATION_STORE_STATUS_IO_ERROR;
        return false;
    }

    HAL_Delay(1U);
    if ((!W25Q64_WaitReady(QSPI_COMMAND_TIMEOUT_MS)) ||
        (!QSPI_Read(W25Q64_CMD_JEDEC_ID, 0U, false,
                    id, sizeof(id))))
    {
        calibration_store_status = CALIBRATION_STORE_STATUS_IO_ERROR;
        return false;
    }

    calibration_store_jedec_id =
        ((uint32_t)id[0] << 16U) |
        ((uint32_t)id[1] << 8U) | (uint32_t)id[2];
    if (calibration_store_jedec_id != W25Q64_EXPECTED_JEDEC_ID)
    {
        calibration_store_status = CALIBRATION_STORE_STATUS_ID_ERROR;
        return false;
    }

    calibration_store_status = CALIBRATION_STORE_STATUS_READY;
    first_valid = W25Q64_Read(CALIBRATION_SECTOR_A,
                              &first, sizeof(first)) &&
                  CalibrationStore_RecordValid(&first);
    second_valid = W25Q64_Read(CALIBRATION_SECTOR_B,
                               &second, sizeof(second)) &&
                   CalibrationStore_RecordValid(&second);

    if (first_valid && second_valid)
    {
        if (CalibrationStore_SequenceNewer(first.sequence,
                                           second.sequence))
        {
            selected = &first;
            active_record_address = CALIBRATION_SECTOR_A;
        }
        else
        {
            selected = &second;
            active_record_address = CALIBRATION_SECTOR_B;
        }
    }
    else if (first_valid)
    {
        selected = &first;
        active_record_address = CALIBRATION_SECTOR_A;
    }
    else if (second_valid)
    {
        selected = &second;
        active_record_address = CALIBRATION_SECTOR_B;
    }

    if (selected != NULL)
    {
        *gain = selected->gain;
        *bias_voltage = selected->bias_voltage;
        calibration_store_sequence = selected->sequence;
        calibration_store_status |= CALIBRATION_STORE_STATUS_LOADED;
    }

    return true;
}

bool CalibrationStore_Save(float gain, float bias_voltage)
{
    calibration_record_t record;
    calibration_record_t verification;
    uint32_t target_address;

    calibration_store_status &=
        ~(CALIBRATION_STORE_STATUS_SAVED |
          CALIBRATION_STORE_STATUS_IO_ERROR |
          CALIBRATION_STORE_STATUS_VERIFY_ERROR);

    if (((calibration_store_status &
          CALIBRATION_STORE_STATUS_READY) == 0U) ||
        (!isfinite(gain)) || (!isfinite(bias_voltage)) ||
        (gain < 0.01F) || (gain > 100.0F) ||
        (bias_voltage < 0.0F) || (bias_voltage > 3.6F))
    {
        calibration_store_status |= CALIBRATION_STORE_STATUS_IO_ERROR;
        return false;
    }

    target_address =
        (active_record_address == CALIBRATION_SECTOR_A) ?
            CALIBRATION_SECTOR_B : CALIBRATION_SECTOR_A;

    memset(&record, 0, sizeof(record));
    record.magic = CALIBRATION_MAGIC;
    record.version = CALIBRATION_VERSION;
    record.length = sizeof(record);
    record.sequence = calibration_store_sequence + 1U;
    if (record.sequence == 0U)
    {
        record.sequence = 1U;
    }
    record.gain = gain;
    record.bias_voltage = bias_voltage;
    record.crc32 = CalibrationStore_Crc32(
        &record,
        (uint32_t)offsetof(calibration_record_t, crc32));

    if ((!W25Q64_EraseSector(target_address)) ||
        (!W25Q64_Program(target_address, &record, sizeof(record))) ||
        (!W25Q64_Read(target_address, &verification,
                      sizeof(verification))))
    {
        calibration_store_status |= CALIBRATION_STORE_STATUS_IO_ERROR;
        return false;
    }

    if ((!CalibrationStore_RecordValid(&verification)) ||
        (memcmp(&record, &verification, sizeof(record)) != 0))
    {
        calibration_store_status |=
            CALIBRATION_STORE_STATUS_VERIFY_ERROR;
        return false;
    }

    active_record_address = target_address;
    calibration_store_sequence = record.sequence;
    calibration_store_status |= CALIBRATION_STORE_STATUS_LOADED |
                                CALIBRATION_STORE_STATUS_SAVED;
    return true;
}
