import fs from "node:fs/promises";
import path from "node:path";
import { Workbook, SpreadsheetFile } from "@oai/artifact-tool";

const outputDir = "C:/Users/dell/Downloads/H743/H743/outputs/stm32h743_batch_test_plan";
const outputPath = path.join(outputDir, "STM32H743_现场测试数据填写表.xlsx");
const previewPath = path.join(outputDir, "现场测试数据填写表_预览.png");
const wb = Workbook.create();
const ws = wb.worksheets.add("测试填写表");
ws.showGridLines = false;

const headers = [
  "编号", "信号发生器设置（照此操作）", "基波f0 (kHz)", "基波分量Vpp (mV)",
  "谐波1次数", "谐波1分量Vpp (mV)", "谐波1相位 (°)",
  "谐波2次数", "谐波2分量Vpp (mV)", "谐波2相位 (°)",
  "噪声频率 (MHz)", "噪声Vpp (mV)",
  "实测整波Vpp (mV)", "实测真有效值 (mV)", "实测基波频率 (kHz)", "实测基波幅值A1峰值 (mV)",
  "实测谐波1频率 (kHz)", "实测谐波1幅值峰值 (mV)", "实测谐波2频率 (kHz)", "实测谐波2幅值峰值 (mV)",
  "整轮耗时 (ms)", "串口屏/异常现象备注",
];

const single = [
  ["S01",10,50],["S02",10,100],["S03",10,250],["S04",20,80],["S05",50,150],
  ["S06",80,200],["S07",100,50],["S08",100,100],["S09",100,250],["S10",150,120],
  ["S11",200,180],["S12",250,100],["S13",300,150],["S14",350,200],["S15",400,50],
  ["S16",400,100],["S17",450,150],["S18",480,200],["S19",500,100],["S20",510,250],
].map(([id,f,v]) => [id,`正弦波；f=${f} kHz；Vpp=${v} mV；设置后在串口屏触发一次采样`,f,v,null,null,null,null,null,null,null,null,...Array(10).fill(null)]);

const one = [
  ["H101",10,60,2,30,0],["H102",10,100,5,40,30],["H103",20,150,3,50,90],["H104",25,200,4,40,45],
  ["H105",40,80,2,40,-45],["H106",50,120,3,60,0],["H107",60,160,5,50,90],["H108",80,200,2,40,30],
  ["H109",100,100,2,50,-90],["H110",100,180,5,40,60],["H111",120,120,3,30,45],["H112",150,200,2,20,0],
  ["H113",160,140,3,40,-30],["H114",180,100,2,60,90],["H115",200,180,2,50,30],["H116",225,200,2,30,-60],
  ["H117",240,120,2,50,45],["H118",250,160,2,40,0],["H119",250,100,2,40,90],["H120",50,120,10,20,-90],
].map(([id,f,v1,n,vh,p]) => [id,`基波 ${f} kHz/${v1} mVpp；叠加${n}次谐波 ${f*n} kHz/${vh} mVpp/相位${p}°；触发采样`,f,v1,n,vh,p,null,null,null,null,null,...Array(10).fill(null)]);

const two = [
  ["H201",10,60,2,30,0,3,20,90],["H202",10,100,5,35,30,9,20,-45],["H203",20,120,2,40,-30,5,20,60],["H204",25,160,3,40,45,7,25,90],
  ["H205",40,80,2,30,-45,4,20,30],["H206",50,120,2,50,0,5,20,90],["H207",60,150,3,40,30,5,30,-60],["H208",80,180,2,40,90,6,20,45],
  ["H209",100,100,2,50,-90,4,25,30],["H210",100,160,3,40,60,5,20,-45],["H211",120,120,2,35,45,4,20,90],["H212",125,180,2,30,0,4,20,-60],
  ["H213",150,120,2,50,30,3,30,90],["H214",160,150,2,40,-30,3,20,45],["H215",165,100,2,40,90,3,30,-45],["H216",20,180,10,25,45,20,15,-90],
  ["H217",40,200,5,25,-60,10,15,30],["H218",50,100,4,50,90,10,20,0],["H219",80,140,3,40,30,6,20,60],["H220",100,200,2,25,-45,5,15,90],
].map(([id,f,v1,n2,v2,p2,n3,v3,p3]) => [id,`基波 ${f} kHz/${v1} mVpp；叠加${n2}次 ${f*n2} kHz/${v2} mVpp/${p2}°；再叠加${n3}次 ${f*n3} kHz/${v3} mVpp/${p3}°；触发采样`,f,v1,n2,v2,p2,n3,v3,p3,null,null,...Array(10).fill(null)]);

const noiseFreqs = [1.0,1.2,2.4,3.0,4.3,4.8,5.3,5.5,5.75,6.0,6.5,9.8,11.5,12.0,14.7,17.5,18.0,18.7,19.6,20.0];
const noise = noiseFreqs.map((fj,i) => [
  `N${String(i+1).padStart(2,"0")}`,
  `有效波固定：基波100 kHz/120 mVpp + 2次谐波200 kHz/40 mVpp/30° + 4次谐波400 kHz/20 mVpp/-45°；只把200 mVpp噪声改为 ${fj} MHz；触发采样`,
  100,120,2,40,30,4,20,-45,fj,200,...Array(10).fill(null),
]);

const sections = [
  ["一、单个正弦基波（20组）", "只设置一个正弦波；填写整波Vpp、真有效值、基波频率、基波峰值幅值。", single],
  ["二、基波 + 一个谐波（20组）", "幅值输入栏均是各正弦分量自身的Vpp；串口屏返回的频谱幅值按峰值填写。", one],
  ["三、基波 + 两个谐波（20组）", "每个谐波的频率均为基波整数倍；若设备不支持直接叠加，请用任意波/多音模式。", two],
  ["四、有效波 + 1–20 MHz噪声（20组）", "本区只改变噪声频率；有效波和噪声200 mVpp保持不变。采样率由软件自动处理，不要人工修改。", noise],
];

ws.getRange("A1:V1").merge();
ws.getRange("A1").values = [["STM32H743 现场测试数据填写表"]];
ws.getRange("A1:V1").format = { fill:"#16324F", font:{bold:true,color:"#FFFFFF",size:18}, verticalAlignment:"center" };
ws.getRange("A1:V1").format.rowHeight = 34;
ws.getRange("A2:V2").merge();
ws.getRange("A2").values = [["操作方法：照第二列修改信号发生器 → 在串口屏手动触发一次采样 → 等软件完整输出 → 把结果填写到黄色区域。不要修改采样率、串口协议或软件参数。"]];
ws.getRange("A2:V2").format = { fill:"#D9EAF2", font:{bold:true,color:"#1F2937"}, wrapText:true };
ws.getRange("A2:V2").format.rowHeight = 38;

let row = 4;
for (const [title,note,data] of sections) {
  ws.getRange(`A${row}:V${row}`).merge();
  ws.getRange(`A${row}`).values = [[title]];
  ws.getRange(`A${row}:V${row}`).format = { fill:"#006D77", font:{bold:true,color:"#FFFFFF",size:14} };
  row += 1;
  ws.getRange(`A${row}:V${row}`).merge();
  ws.getRange(`A${row}`).values = [[note]];
  ws.getRange(`A${row}:V${row}`).format = { fill:"#E2F0D9", font:{color:"#1F2937",italic:true}, wrapText:true };
  row += 1;
  ws.getRange(`A${row}:V${row}`).values = [headers];
  ws.getRange(`A${row}:V${row}`).format = { fill:"#0A9396", font:{bold:true,color:"#FFFFFF",size:10}, wrapText:true, horizontalAlignment:"center", verticalAlignment:"center", borders:{preset:"all",style:"thin",color:"#CBD5E1"} };
  ws.getRange(`A${row}:V${row}`).format.rowHeight = 46;
  row += 1;
  const start = row;
  const end = row + data.length - 1;
  ws.getRange(`A${start}:V${end}`).values = data;
  ws.getRange(`A${start}:L${end}`).format = { fill:"#DCEEFF", borders:{preset:"all",style:"thin",color:"#CBD5E1"}, verticalAlignment:"center" };
  ws.getRange(`M${start}:V${end}`).format = { fill:"#FFF2CC", borders:{preset:"all",style:"thin",color:"#CBD5E1"}, verticalAlignment:"center" };
  ws.getRange(`B${start}:B${end}`).format.wrapText = true;
  ws.getRange(`A${start}:V${end}`).format.rowHeight = 32;
  ws.getRange(`C${start}:U${end}`).format.numberFormat = "0.0000";
  row = end + 4;
}

const widths = {A:9,B:76,C:14,D:18,E:12,F:19,G:15,H:12,I:19,J:15,K:17,L:15,M:18,N:18,O:18,P:22,Q:19,R:22,S:19,T:22,U:14,V:30};
for (const [col,w] of Object.entries(widths)) ws.getRange(`${col}:${col}`).format.columnWidth = w;
ws.freezePanes.freezeRows(2);
ws.freezePanes.freezeColumns(2);

await fs.mkdir(outputDir,{recursive:true});
const file = await SpreadsheetFile.exportXlsx(wb);
await file.save(outputPath);
const preview = await wb.render({sheetName:"测试填写表",range:"A1:V104",autoCrop:"all",scale:0.48,format:"png"});
await fs.writeFile(previewPath,new Uint8Array(await preview.arrayBuffer()));
const check = await wb.inspect({kind:"region",sheetId:"测试填写表",range:"A1:V30",maxChars:3500});
const errors = await wb.inspect({kind:"match",searchTerm:"#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",options:{useRegex:true,maxResults:100},maxChars:2500});
console.log(JSON.stringify({outputPath,previewPath,check:check.ndjson??check,errors:errors.ndjson??errors},null,2));
