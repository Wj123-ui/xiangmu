#ifndef CALIBRATION_STORE_H
#define CALIBRATION_STORE_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include <stdint.h>

enum
{
    CALIBRATION_STORE_STATUS_READY = (1UL << 0),
    CALIBRATION_STORE_STATUS_LOADED = (1UL << 1),
    CALIBRATION_STORE_STATUS_SAVED = (1UL << 2),
    CALIBRATION_STORE_STATUS_IO_ERROR = (1UL << 3),
    CALIBRATION_STORE_STATUS_ID_ERROR = (1UL << 4),
    CALIBRATION_STORE_STATUS_VERIFY_ERROR = (1UL << 5)
};

/* Visible over SWD without changing the fixed HMI protocol. */
extern volatile uint32_t calibration_store_status;
extern volatile uint32_t calibration_store_jedec_id;
extern volatile uint32_t calibration_store_sequence;

bool CalibrationStore_Init(float *gain, float *bias_voltage);
bool CalibrationStore_Save(float gain, float bias_voltage);

#ifdef __cplusplus
}
#endif

#endif
