import fs from "node:fs/promises";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const outputDir = "C:/Users/yqh/Desktop/H743/26G/outputs/calibration_20260801";
const previewDir = "C:/Users/yqh/Desktop/H743/.codex_work/calibration_20260801/previews";
const outputPath = `${outputDir}/G题软件校准数据收集表.xlsx`;

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const workbook = Workbook.create();
const guide = workbook.worksheets.add("填写说明");
const sine = workbook.worksheets.add("单正弦录入");
const matrix = workbook.worksheets.add("单正弦系数矩阵");
const harmonic = workbook.worksheets.add("正弦加谐波录入");

const colors = {
  navy: "#17365D",
  blue: "#2F75B5",
  lightBlue: "#D9EAF7",
  paleBlue: "#EAF3F8",
  yellow: "#FFF2CC",
  green: "#E2F0D9",
  red: "#FCE4D6",
  gray: "#E7E6E6",
  white: "#FFFFFF",
  border: "#B4C6E7",
};

function titleStyle(range) {
  range.format = {
    fill: colors.navy,
    font: { bold: true, color: colors.white, size: 16 },
    horizontalAlignment: "center",
    verticalAlignment: "center",
  };
}

function headerStyle(range) {
  range.format = {
    fill: colors.blue,
    font: { bold: true, color: colors.white, size: 10 },
    horizontalAlignment: "center",
    verticalAlignment: "center",
    wrapText: true,
    borders: { preset: "all", style: "thin", color: colors.border },
  };
}

function sectionStyle(range) {
  range.format = {
    fill: colors.lightBlue,
    font: { bold: true, color: colors.navy, size: 11 },
    verticalAlignment: "center",
  };
}

function bodyBorders(range) {
  range.format.borders = {
    insideHorizontal: { style: "thin", color: "#D9E2F3" },
    insideVertical: { style: "thin", color: "#E7E6E6" },
    bottom: { style: "thin", color: colors.border },
  };
}

// --------------------------------------------------------------------------
// 填写说明
// --------------------------------------------------------------------------
guide.showGridLines = false;
guide.getRange("A1:H2").merge();
guide.getRange("A1").values = [["G题软件校准数据收集表"]];
titleStyle(guide.getRange("A1:H2"));
guide.getRange("A1:H2").format.rowHeight = 28;

guide.getRange("A4:H4").merge();
guide.getRange("A4").values = [["一、量纲与串口字段"]];
sectionStyle(guide.getRange("A4:H4"));
guide.getRange("A5:C10").values = [
  ["字段", "输出定义", "单位"],
  ["x0.val", "完整输入叠加波形的总峰峰值", "mVpp"],
  ["x1.val", "完整输入叠加波形去直流后的真有效值", "mVrms"],
  ["x2.val", "基波频率", "kHz"],
  ["x3.val", "仅基波分量的峰值幅度", "mV峰值"],
  ["x4/x5、x6/x7", "两组谐波的频率/各自峰值幅度", "kHz / mV峰值"],
];
headerStyle(guide.getRange("A5:C5"));
bodyBorders(guide.getRange("A6:C10"));

guide.getRange("A12:H12").merge();
guide.getRange("A12").values = [["二、校准节点"]];
sectionStyle(guide.getRange("A12:H12"));
guide.getRange("A13:B18").values = [
  ["项目", "设置"],
  ["频率节点", "10 kHz边界点；其后25、50、75……500 kHz"],
  ["总峰峰值节点", "50、60、70……250 mVpp，每10 mVpp一档"],
  ["单正弦标称峰值", "标称Vpp÷2"],
  ["单正弦理论RMS", "标称Vpp÷(2√2)"],
  ["谐波约束", "每个有效分量频率均不得超过500 kHz"],
];
headerStyle(guide.getRange("A13:B13"));
bodyBorders(guide.getRange("A14:B18"));

guide.getRange("A20:H20").merge();
guide.getRange("A20").values = [["三、测试顺序"]];
sectionStyle(guide.getRange("A20:H20"));
guide.getRange("A21:H27").values = [
  ["1", "先焊接最终RC网络，之后不要更换电阻、电容、线缆、负载模式或模拟前端。", null, null, null, null, null, null],
  ["2", "信号发生器设置为高阻负载显示模式；正弦波直流偏置为0 V。", null, null, null, null, null, null],
  ["3", "采集软件未经过新二维查表补偿的原始结果，避免重复补偿。", null, null, null, null, null, null],
  ["4", "单正弦表用于生成频率×幅度二维分量校正系数；黄色单元格为人工填写。", null, null, null, null, null, null],
  ["5", "正弦+谐波表用于核对总Vpp、总RMS和分量分离；不要把相位相关的总Vpp诊断系数直接当成分量查表系数。", null, null, null, null, null, null],
  ["6", "每个节点建议连续测18次，删除4个最大值和4个最小值，再填写中间10次平均值。", null, null, null, null, null, null],
  ["7", "题目判据：频率绝对误差≤1 kHz；总Vpp、总RMS及各频谱分量幅值绝对误差≤5 mV。", null, null, null, null, null, null],
];
guide.getRange("B21:H27").merge(true);
guide.getRange("A21:H27").format = {
  verticalAlignment: "center",
  wrapText: true,
  borders: { preset: "all", style: "thin", color: "#D9E2F3" },
};
guide.getRange("A21:A27").format = {
  fill: colors.paleBlue,
  font: { bold: true, color: colors.navy },
  horizontalAlignment: "center",
};

guide.getRange("A29:H29").merge();
guide.getRange("A29").values = [["四、测试环境（黄色格填写）"]];
sectionStyle(guide.getRange("A29:H29"));
guide.getRange("A30:B37").values = [
  ["项目", "填写值"],
  ["测试日期", null],
  ["固件版本/压缩包", null],
  ["RC网络元件值", null],
  ["信号源型号", null],
  ["信号源负载模式", null],
  ["板载3.3 V实测", null],
  ["备注", null],
];
headerStyle(guide.getRange("A30:B30"));
guide.getRange("B31:B37").format.fill = colors.yellow;
bodyBorders(guide.getRange("A31:B37"));
guide.getRange("A:A").format.columnWidth = 22;
guide.getRange("B:B").format.columnWidth = 64;
guide.getRange("C:H").format.columnWidth = 12;
guide.getRange("A1:H37").format.verticalAlignment = "center";
guide.getRange("A5:H37").format.rowHeight = 24;
guide.freezePanes.freezeRows(2);

// --------------------------------------------------------------------------
// 单正弦录入（21频率 × 21 Vpp = 441点）
// --------------------------------------------------------------------------
const frequencies = [10, ...Array.from({ length: 20 }, (_, i) => (i + 1) * 25)];
const vpps = Array.from({ length: 21 }, (_, i) => 50 + i * 10);

sine.showGridLines = false;
sine.getRange("A1:R2").merge();
sine.getRange("A1").values = [["单正弦二维校准原始数据（黄色格填写）"]];
titleStyle(sine.getRange("A1:R2"));
sine.getRange("A3:R3").merge();
sine.getRange("A3").values = [["用途：生成频率×幅度二维查表系数。标称峰值=Vpp/2；所有实测字段填写中间10次平均值。"]];
sine.getRange("A3:R3").format = {
  fill: colors.paleBlue,
  font: { color: colors.navy, italic: true },
  wrapText: true,
};

const sineHeaders = [
  "编号", "输入频率\n(kHz)", "标称总Vpp\n(mVpp)", "标称基波峰值\n(mV)", "理论总RMS\n(mV)",
  "x0实测总Vpp\n(mVpp)", "x1实测总RMS\n(mV)", "x2实测基频\n(kHz)", "x3实测基波峰值\n(mV)",
  "总Vpp误差\n(mV)", "RMS误差\n(mV)", "频率误差\n(kHz)", "基波幅值误差\n(mV)",
  "总Vpp诊断系数", "总RMS诊断系数", "分量幅值校正系数", "判定", "备注"
];
sine.getRange("A4:R4").values = [sineHeaders];
headerStyle(sine.getRange("A4:R4"));
sine.getRange("A4:R4").format.rowHeight = 48;

const sineRows = [];
let sineId = 1;
let sineExcelRow = 5;
for (const f of frequencies) {
  for (const vpp of vpps) {
    sineRows.push([
      sineId++, f, vpp,
      `=C${sineExcelRow}/2`,
      `=D${sineExcelRow}/SQRT(2)`,
      null, null, null, null,
      `=IF(F${sineExcelRow}="","",F${sineExcelRow}-C${sineExcelRow})`,
      `=IF(G${sineExcelRow}="","",G${sineExcelRow}-E${sineExcelRow})`,
      `=IF(H${sineExcelRow}="","",H${sineExcelRow}-B${sineExcelRow})`,
      `=IF(I${sineExcelRow}="","",I${sineExcelRow}-D${sineExcelRow})`,
      `=IF(F${sineExcelRow}>0,C${sineExcelRow}/F${sineExcelRow},"")`,
      `=IF(G${sineExcelRow}>0,E${sineExcelRow}/G${sineExcelRow},"")`,
      `=IF(I${sineExcelRow}>0,D${sineExcelRow}/I${sineExcelRow},"")`,
      `=IF(COUNT(F${sineExcelRow}:I${sineExcelRow})<4,"待填写",IF(AND(ABS(J${sineExcelRow})<=5,ABS(K${sineExcelRow})<=5,ABS(L${sineExcelRow})<=1,ABS(M${sineExcelRow})<=5),"合格","超差"))`,
      null,
    ]);
    sineExcelRow++;
  }
}
const sineLastRow = sineExcelRow - 1;
sine.getRange(`A5:R${sineLastRow}`).values = sineRows;
sine.getRange(`F5:I${sineLastRow}`).format.fill = colors.yellow;
sine.getRange(`R5:R${sineLastRow}`).format.fill = colors.yellow;
sine.getRange(`D5:E${sineLastRow}`).format.fill = colors.gray;
sine.getRange(`J5:Q${sineLastRow}`).format.fill = colors.paleBlue;
bodyBorders(sine.getRange(`A5:R${sineLastRow}`));
sine.getRange(`B5:P${sineLastRow}`).format.numberFormat = "0.000";
sine.getRange(`N5:P${sineLastRow}`).format.numberFormat = "0.000000";
sine.getRange(`A5:A${sineLastRow}`).format.numberFormat = "0";
sine.getRange(`Q5:Q${sineLastRow}`).conditionalFormats.add("containsText", {
  text: "合格", format: { fill: colors.green, font: { color: "#375623", bold: true } }
});
sine.getRange(`Q5:Q${sineLastRow}`).conditionalFormats.add("containsText", {
  text: "超差", format: { fill: colors.red, font: { color: "#9C0006", bold: true } }
});
sine.getRange(`Q5:Q${sineLastRow}`).conditionalFormats.add("containsText", {
  text: "待填写", format: { fill: colors.gray, font: { color: "#666666" } }
});
const sineTable = sine.tables.add(`A4:R${sineLastRow}`, true, "SingleSineCalibrationTable");
sineTable.style = "TableStyleMedium2";
sine.freezePanes.freezeRows(4);
sine.freezePanes.freezeColumns(3);
sine.getRange("A:A").format.columnWidth = 8;
sine.getRange("B:C").format.columnWidth = 13;
sine.getRange("D:P").format.columnWidth = 15;
sine.getRange("Q:Q").format.columnWidth = 11;
sine.getRange("R:R").format.columnWidth = 24;

// --------------------------------------------------------------------------
// 单正弦系数矩阵
// --------------------------------------------------------------------------
matrix.showGridLines = false;
matrix.getRange("A1:V2").merge();
matrix.getRange("A1").values = [["单正弦二维查表系数矩阵（由录入表自动生成）"]];
titleStyle(matrix.getRange("A1:V2"));

function buildCoefficientMatrix(startRow, title, sourceColumn) {
  matrix.getRange(`A${startRow}:V${startRow}`).merge();
  matrix.getRange(`A${startRow}`).values = [[title]];
  sectionStyle(matrix.getRange(`A${startRow}:V${startRow}`));
  const headerRow = startRow + 1;
  matrix.getRange(`A${headerRow}`).values = [["频率(kHz)\\Vpp(mVpp)"]];
  matrix.getRangeByIndexes(headerRow - 1, 1, 1, vpps.length).values = [vpps];
  headerStyle(matrix.getRange(`A${headerRow}:V${headerRow}`));
  const dataStart = headerRow + 1;
  matrix.getRangeByIndexes(dataStart - 1, 0, frequencies.length, 1).values = frequencies.map(v => [v]);
  const formulas = [];
  for (let fi = 0; fi < frequencies.length; fi++) {
    const row = [];
    for (let vi = 0; vi < vpps.length; vi++) {
      const sourceRow = 5 + fi * vpps.length + vi;
      row.push(`=IF('单正弦录入'!${sourceColumn}${sourceRow}="","",'单正弦录入'!${sourceColumn}${sourceRow})`);
    }
    formulas.push(row);
  }
  matrix.getRangeByIndexes(dataStart - 1, 1, frequencies.length, vpps.length).formulas = formulas;
  const body = matrix.getRangeByIndexes(dataStart - 1, 0, frequencies.length, vpps.length + 1);
  bodyBorders(body);
  matrix.getRangeByIndexes(dataStart - 1, 1, frequencies.length, vpps.length).format = {
    numberFormat: "0.000000",
    horizontalAlignment: "center",
    fill: colors.paleBlue,
  };
  return dataStart + frequencies.length - 1;
}

let matrixEnd = buildCoefficientMatrix(4, "A. 分量幅值校正系数（用于x3/x5/x7二维插值）", "P");
matrixEnd = buildCoefficientMatrix(matrixEnd + 3, "B. 总Vpp诊断系数（单正弦核对用）", "N");
matrixEnd = buildCoefficientMatrix(matrixEnd + 3, "C. 总RMS诊断系数（单正弦核对用）", "O");
matrix.freezePanes.freezeRows(5);
matrix.freezePanes.freezeColumns(1);
matrix.getRange("A:A").format.columnWidth = 22;
matrix.getRange("B:V").format.columnWidth = 11;

// --------------------------------------------------------------------------
// 正弦 + 谐波组合录入（11个基频 × 21个总Vpp = 231组）
// --------------------------------------------------------------------------
const harmonicBaseFrequencies = [10, ...Array.from({ length: 10 }, (_, i) => (i + 1) * 25)];
harmonic.showGridLines = false;
harmonic.getRange("A1:AK2").merge();
harmonic.getRange("A1").values = [["正弦 + 谐波组合校准/验收数据（黄色格填写）"]];
titleStyle(harmonic.getRange("A1:AK2"));
harmonic.getRange("A3:AK3").merge();
harmonic.getRange("A3").values = [["先调节各分量幅值与相位，使示波器测得完整叠加波形Vpp等于目标总Vpp；默认第一谐波为二次谐波，第二谐波可选。"]];
harmonic.getRange("A3:AK3").format = {
  fill: colors.paleBlue,
  font: { color: colors.navy, italic: true },
  wrapText: true,
};

const harmonicHeaders = [
  "编号", "基波f0\n(kHz)", "目标总Vpp\n(mVpp)", "标称基波峰值A1\n(mV)",
  "谐波1次数", "谐波1标称频率\n(kHz)", "谐波1标称峰值\n(mV)", "谐波1相对相位\n(°)",
  "谐波2次数\n(可空)", "谐波2标称频率\n(kHz)", "谐波2标称峰值\n(mV)", "谐波2相对相位\n(°)",
  "理论总RMS\n(mV)", "x0实测总Vpp\n(mVpp)", "x1实测总RMS\n(mV)", "x2实测基频\n(kHz)",
  "x3实测基波峰值\n(mV)", "x4实测谐波1频率\n(kHz)", "x5实测谐波1峰值\n(mV)",
  "x6实测谐波2频率\n(kHz)", "x7实测谐波2峰值\n(mV)",
  "总Vpp误差\n(mV)", "总RMS误差\n(mV)", "基频误差\n(kHz)", "基波幅值误差\n(mV)",
  "谐波1频率误差\n(kHz)", "谐波1幅值误差\n(mV)", "谐波2频率误差\n(kHz)", "谐波2幅值误差\n(mV)",
  "总Vpp诊断系数", "总RMS诊断系数", "基波校正系数", "谐波1校正系数", "谐波2校正系数",
  "参数检查", "判定", "备注"
];
harmonic.getRange("A4:AK4").values = [harmonicHeaders];
headerStyle(harmonic.getRange("A4:AK4"));
harmonic.getRange("A4:AK4").format.rowHeight = 58;

const harmonicRows = [];
let harmonicId = 1;
let harmonicExcelRow = 5;
for (const f0 of harmonicBaseFrequencies) {
  for (const vpp of vpps) {
    const r = harmonicExcelRow;
    harmonicRows.push([
      harmonicId++, f0, vpp, null, 2,
      `=IF(E${r}="","",B${r}*E${r})`, null, null, null,
      `=IF(I${r}="","",B${r}*I${r})`, null, null,
      `=IF(COUNT(D${r},G${r})<2,"",SQRT((D${r}^2+G${r}^2+IF(K${r}="",0,K${r}^2))/2))`,
      null, null, null, null, null, null, null, null,
      `=IF(N${r}="","",N${r}-C${r})`,
      `=IF(OR(O${r}="",M${r}=""),"",O${r}-M${r})`,
      `=IF(P${r}="","",P${r}-B${r})`,
      `=IF(OR(Q${r}="",D${r}=""),"",Q${r}-D${r})`,
      `=IF(R${r}="","",R${r}-F${r})`,
      `=IF(OR(S${r}="",G${r}=""),"",S${r}-G${r})`,
      `=IF(I${r}="","",IF(T${r}="","",T${r}-J${r}))`,
      `=IF(I${r}="","",IF(OR(U${r}="",K${r}=""),"",U${r}-K${r}))`,
      `=IF(N${r}>0,C${r}/N${r},"")`,
      `=IF(O${r}>0,M${r}/O${r},"")`,
      `=IF(Q${r}>0,D${r}/Q${r},"")`,
      `=IF(S${r}>0,G${r}/S${r},"")`,
      `=IF(AND(I${r}<>"",U${r}>0),K${r}/U${r},"")`,
      `=IF(OR(F${r}>500,J${r}>500),"频率越界",IF(OR(D${r}="",G${r}=""),"待设幅值","可测"))`,
      `=IF(AI${r}<>"可测",AI${r},IF(COUNT(N${r}:S${r})<6,"待填写",IF(AND(ABS(V${r})<=5,ABS(W${r})<=5,ABS(X${r})<=1,ABS(Y${r})<=5,ABS(Z${r})<=1,ABS(AA${r})<=5,IF(I${r}="",1=1,AND(COUNT(T${r}:U${r})=2,ABS(AB${r})<=1,ABS(AC${r})<=5))),"合格","超差")))`,
      null,
    ]);
    harmonicExcelRow++;
  }
}
const harmonicLastRow = harmonicExcelRow - 1;
harmonic.getRange(`A5:AK${harmonicLastRow}`).values = harmonicRows;
harmonic.getRange(`F5:F${harmonicLastRow}`).format.fill = colors.gray;
harmonic.getRange(`J5:J${harmonicLastRow}`).format.fill = colors.gray;
harmonic.getRange(`M5:AJ${harmonicLastRow}`).format.fill = colors.paleBlue;
harmonic.getRange(`D5:E${harmonicLastRow}`).format.fill = colors.yellow;
harmonic.getRange(`G5:I${harmonicLastRow}`).format.fill = colors.yellow;
harmonic.getRange(`K5:L${harmonicLastRow}`).format.fill = colors.yellow;
harmonic.getRange(`N5:U${harmonicLastRow}`).format.fill = colors.yellow;
harmonic.getRange(`AK5:AK${harmonicLastRow}`).format.fill = colors.yellow;
bodyBorders(harmonic.getRange(`A5:AK${harmonicLastRow}`));
harmonic.getRange(`B5:AH${harmonicLastRow}`).format.numberFormat = "0.000";
harmonic.getRange(`AD5:AH${harmonicLastRow}`).format.numberFormat = "0.000000";
harmonic.getRange(`A5:A${harmonicLastRow}`).format.numberFormat = "0";
harmonic.getRange(`E5:E${harmonicLastRow}`).dataValidation = {
  rule: { type: "whole", operator: "between", formula1: 2, formula2: 20 }
};
harmonic.getRange(`I5:I${harmonicLastRow}`).dataValidation = {
  rule: { type: "whole", operator: "between", formula1: 2, formula2: 20 }
};
harmonic.getRange(`H5:H${harmonicLastRow}`).dataValidation = {
  rule: { type: "decimal", operator: "between", formula1: -180, formula2: 180 }
};
harmonic.getRange(`L5:L${harmonicLastRow}`).dataValidation = {
  rule: { type: "decimal", operator: "between", formula1: -180, formula2: 180 }
};
harmonic.getRange(`AJ5:AJ${harmonicLastRow}`).conditionalFormats.add("containsText", {
  text: "合格", format: { fill: colors.green, font: { color: "#375623", bold: true } }
});
harmonic.getRange(`AJ5:AJ${harmonicLastRow}`).conditionalFormats.add("containsText", {
  text: "超差", format: { fill: colors.red, font: { color: "#9C0006", bold: true } }
});
harmonic.getRange(`AI5:AJ${harmonicLastRow}`).conditionalFormats.add("containsText", {
  text: "频率越界", format: { fill: colors.red, font: { color: "#9C0006", bold: true } }
});
const harmonicTable = harmonic.tables.add(`A4:AK${harmonicLastRow}`, true, "HarmonicCalibrationTable");
harmonicTable.style = "TableStyleMedium2";
harmonic.freezePanes.freezeRows(4);
harmonic.freezePanes.freezeColumns(3);
harmonic.getRange("A:A").format.columnWidth = 8;
harmonic.getRange("B:C").format.columnWidth = 13;
harmonic.getRange("D:M").format.columnWidth = 15;
harmonic.getRange("N:AH").format.columnWidth = 15;
harmonic.getRange("AI:AJ").format.columnWidth = 12;
harmonic.getRange("AK:AK").format.columnWidth = 24;

// Compact verification before export.
console.log((await workbook.inspect({
  kind: "table",
  range: "单正弦录入!A1:R12",
  include: "values,formulas",
  tableMaxRows: 12,
  tableMaxCols: 18,
  maxChars: 10000,
})).ndjson);
console.log((await workbook.inspect({
  kind: "table",
  range: "正弦加谐波录入!A1:AK10",
  include: "values,formulas",
  tableMaxRows: 10,
  tableMaxCols: 37,
  maxChars: 12000,
})).ndjson);
console.log((await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "final formula error scan",
})).ndjson);

for (const [sheetName, range, fileName] of [
  ["填写说明", "A1:H37", "01_填写说明.png"],
  ["单正弦录入", "A1:R16", "02_单正弦录入.png"],
  ["单正弦系数矩阵", `A1:V${matrixEnd}`, "03_单正弦系数矩阵.png"],
  ["正弦加谐波录入", "A1:AK14", "04_正弦加谐波录入.png"],
]) {
  const preview = await workbook.render({ sheetName, range, scale: 1, format: "png" });
  await fs.writeFile(`${previewDir}/${fileName}`, new Uint8Array(await preview.arrayBuffer()));
}

const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);
console.log(JSON.stringify({ outputPath, sineRows: sineRows.length, harmonicRows: harmonicRows.length, matrixEnd }));
