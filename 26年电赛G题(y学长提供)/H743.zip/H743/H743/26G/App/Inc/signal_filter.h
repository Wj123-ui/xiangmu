#ifndef SIGNAL_FILTER_H
#define SIGNAL_FILTER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include <stdint.h>

#include "signal_config.h"

#define SIGNAL_FILTER_SAMPLE_RATE_HZ SIGNAL_ADC_SAMPLE_RATE_HZ
#define SIGNAL_FILTER_CUTOFF_HZ 575000.0f
#define SIGNAL_FILTER_TAP_COUNT 449U
#define SIGNAL_FILTER_INPUT_BLOCK_SIZE 384U
#define SIGNAL_FILTER_MAX_BLOCK_SIZE SIGNAL_FILTER_INPUT_BLOCK_SIZE
#define SIGNAL_FILTER_OUTPUT_BLOCK_SIZE \
    (SIGNAL_FILTER_INPUT_BLOCK_SIZE / SIGNAL_DECIMATION_FACTOR)
#define SIGNAL_FILTER_GROUP_DELAY_SAMPLES \
    ((SIGNAL_FILTER_TAP_COUNT - 1U) / 2U)

#define SIGNAL_POST_FILTER_SAMPLE_RATE_HZ \
    SIGNAL_ANALYSIS_SAMPLE_RATE_HZ
#define SIGNAL_POST_FILTER_CUTOFF_HZ 625000.0f
#define SIGNAL_POST_FILTER_TAP_COUNT 257U
#define SIGNAL_POST_FILTER_GROUP_DELAY_SAMPLES \
    ((SIGNAL_POST_FILTER_TAP_COUNT - 1U) / 2U)

bool Signal_Filter_Init(void);
bool Signal_Filter_InitForSampleRate(float sample_rate_hz);
void Signal_Filter_Reset(void);

bool Signal_Filter_ProcessDecimate(const float *input,
                                   float *output,
                                   uint32_t input_sample_count);

float Signal_Filter_AdcToFloat(const uint16_t *adc_samples,
                               float *output,
                               uint32_t sample_count,
                               float units_per_adc_code);

float Signal_Filter_RemoveDc(float *samples, uint32_t sample_count);
float Signal_Filter_CalculateRms(const float *samples,
                                 uint32_t sample_count);

#ifdef __cplusplus
}
#endif

#endif
