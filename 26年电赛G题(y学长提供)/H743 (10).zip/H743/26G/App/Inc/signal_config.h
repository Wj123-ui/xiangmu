#ifndef SIGNAL_CONFIG_H
#define SIGNAL_CONFIG_H

/*
 * STM32H743 ADC1/ADC2 dual-interleaved sampling:
 * 24 MHz ADC clock / 4-cycle uniform interleave phase = 6.0000000 MSPS.
 * The complete 6.0000000 MSPS stream is retained for the 16384-point FFT.
 * A linear-phase FIR rejects out-of-band interference without discarding
 * samples; peak search remains limited to the requested 600 kHz band.
 */
#define SIGNAL_ADC_SAMPLE_RATE_HZ      (24000000.0f / 4.0f)
#define SIGNAL_DECIMATION_FACTOR       1U
#define SIGNAL_ANALYSIS_SAMPLE_RATE_HZ \
    (SIGNAL_ADC_SAMPLE_RATE_HZ / (float)SIGNAL_DECIMATION_FACTOR)
#define SIGNAL_MINIMUM_FREQUENCY_HZ 9500.0f
#define SIGNAL_MAXIMUM_FREQUENCY_HZ 600000.0f

#endif
