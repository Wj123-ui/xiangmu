#!/usr/bin/env python3
"""Synchronize final F407 application regions into the H743 main source.

The F407 tree is opened read-only.  MCU-family initialization regions stay
owned by the H743 project and are adapted separately.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


F407_MAIN = Path(r"C:\Users\yqh\Desktop\F407_2\Core\Src\main.c")
H743_MAIN = Path(__file__).resolve().parents[1] / "Core" / "Src" / "main.c"
REGIONS = (
    "Includes",
    "PTD",
    "PD",
    "PV",
    "PFP",
    "0",
    "2",
    "WHILE",
    "3",
    "4",
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def region_pattern(label: str) -> re.Pattern[str]:
    return re.compile(
        rf"(?s)(/\* USER CODE BEGIN {re.escape(label)} \*/)"
        rf"(.*?)"
        rf"(/\* USER CODE END {re.escape(label)} \*/)"
    )


def extract_region(text: str, label: str) -> str:
    match = region_pattern(label).search(text)
    if match is None:
        raise RuntimeError(f"missing F407 USER CODE region: {label}")
    return match.group(2)


def adapt_uart(text: str) -> str:
    return (
        text.replace("huart1", "huart2")
        .replace("USART1", "USART2")
        .replace("->DR", "->RDR")
    )


def main() -> int:
    source_before = F407_MAIN.read_bytes()
    f407_text = source_before.decode("utf-8").replace("\r\n", "\n")
    h743_text = H743_MAIN.read_text(encoding="utf-8").replace("\r\n", "\n")

    replacements: list[dict[str, int | str]] = []
    for label in REGIONS:
        source_region = adapt_uart(extract_region(f407_text, label))
        pattern = region_pattern(label)
        target_match = pattern.search(h743_text)
        if target_match is None:
            raise RuntimeError(f"missing H743 USER CODE region: {label}")
        h743_text = (
            h743_text[: target_match.start(2)]
            + source_region
            + h743_text[target_match.end(2) :]
        )
        replacements.append(
            {"region": label, "characters": len(source_region)}
        )

    H743_MAIN.write_text(h743_text, encoding="utf-8", newline="\n")

    source_after = F407_MAIN.read_bytes()
    if source_after != source_before:
        raise RuntimeError("F407 source changed during synchronization")

    print(
        json.dumps(
            {
                "status": "PASS",
                "f407_sha256": digest(source_after),
                "h743_sha256": digest(H743_MAIN.read_bytes()),
                "regions": replacements,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
