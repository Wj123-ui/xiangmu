from pathlib import Path
import cmath
import math

from PIL import Image, ImageDraw, ImageFont


OUT = Path(__file__).resolve().parent
FONT_FILE = Path(r"C:\Windows\Fonts\msyh.ttc")
if not FONT_FILE.exists():
    FONT_FILE = Path(r"C:\Windows\Fonts\simhei.ttf")


def font(size, bold=False):
    candidate = Path(r"C:\Windows\Fonts\msyhbd.ttc") if bold else FONT_FILE
    if not candidate.exists():
        candidate = FONT_FILE
    return ImageFont.truetype(str(candidate), size)


def centered_text(draw, box, text, fnt, fill="#152B3C", spacing=5):
    x0, y0, x1, y1 = box
    bounds = draw.multiline_textbbox((0, 0), text, font=fnt, spacing=spacing,
                                     align="center")
    w, h = bounds[2] - bounds[0], bounds[3] - bounds[1]
    draw.multiline_text(((x0 + x1 - w) / 2, (y0 + y1 - h) / 2), text,
                        font=fnt, fill=fill, spacing=spacing, align="center")


def box(draw, bounds, text, fnt, fill="#F5F9FD", outline="#284B63", radius=18):
    draw.rounded_rectangle(bounds, radius=radius, fill=fill, outline=outline, width=3)
    centered_text(draw, bounds, text, fnt)


def arrow(draw, start, end, color="#284B63", width=4):
    x0, y0 = start
    x1, y1 = end
    draw.line((x0, y0, x1, y1), fill=color, width=width)
    angle = math.atan2(y1 - y0, x1 - x0)
    size = 14
    p1 = (x1, y1)
    p2 = (x1 - size * math.cos(angle - 0.55), y1 - size * math.sin(angle - 0.55))
    p3 = (x1 - size * math.cos(angle + 0.55), y1 - size * math.sin(angle + 0.55))
    draw.polygon((p1, p2, p3), fill=color)


def overall_flow():
    im = Image.new("RGB", (2200, 1050), "white")
    d = ImageDraw.Draw(im)
    centered_text(d, (0, 20, 2200, 100), "系统信号链与数据处理流程", font(42, True))
    xs = [150, 490, 830, 1170, 1510, 1900]
    labels = [
        "信号源\n10~500 kHz", "前级抗混叠滤波\n抑制高频泄漏",
        "偏置与增益\n1.65 V / 约6倍", "ADC1/ADC2\n12位交错6 MSPS",
        "89抽头线性相位FIR\n保留全部采样点", "16384点FFT\n幅值与相位估计",
    ]
    widths = [250, 290, 290, 300, 310, 260]
    top_boxes = []
    for x, label, w in zip(xs, labels, widths):
        b = (x - w // 2, 190, x + w // 2, 360)
        top_boxes.append(b)
        box(d, b, label, font(27))
    for left, right in zip(top_boxes[:-1], top_boxes[1:]):
        arrow(d, (left[2] + 5, 275), (right[0] - 5, 275))

    lower = [
        (140, 520, 700, 700, "18轮采集\n频谱功率与相干分量累加"),
        (820, 520, 1370, 700, "500 Hz网格保护校准\n基波与最多两组谐波确认"),
        (1500, 520, 2130, 700, "统一重构Vpp与真有效值\n生成1/3周期波形及离散谱"),
    ]
    for b in lower:
        box(d, b[:4], b[4], font(28), fill="#F3FAF7", outline="#2E6F5E")
    arrow(d, (2030, 370), (420, 510), "#2E6F5E")
    arrow(d, (700, 610), (810, 610), "#2E6F5E")
    arrow(d, (1370, 610), (1490, 610), "#2E6F5E")
    box(d, (1530, 815, 2110, 980), "USART2触摸屏显示\n数值、单周期、三周期、频谱",
        font(27), fill="#FFF8EE", outline="#9A5B13")
    arrow(d, (1815, 710), (1815, 805), "#9A5B13")
    box(d, (150, 815, 720, 980), "命令9：500 kHz标定\n增益/偏置写入W25Q64",
        font(27), fill="#FFF8EE", outline="#9A5B13")
    arrow(d, (420, 710), (420, 805), "#9A5B13")
    im.save(OUT / "overall_flow.png", dpi=(180, 180))


def fir_coefficients(taps=89, cutoff=800_000.0, fs=6_000_000.0):
    result = []
    center = (taps - 1) // 2
    for n in range(taps):
        offset = n - center
        phase = 2 * math.pi * n / (taps - 1)
        window = (0.35875 - 0.48829 * math.cos(phase)
                  + 0.14128 * math.cos(2 * phase)
                  - 0.01168 * math.cos(3 * phase))
        if offset == 0:
            ideal = 2 * cutoff / fs
        else:
            ideal = math.sin(2 * math.pi * cutoff / fs * offset) / (math.pi * offset)
        result.append(ideal * window)
    total = sum(result)
    return [v / total for v in result]


def response_magnitude(h, frequency, fs=6_000_000.0):
    omega = -2j * math.pi * frequency / fs
    return abs(sum(value * cmath.exp(omega * n) for n, value in enumerate(h)))


def filter_response():
    w, h_px = 2100, 1000
    im = Image.new("RGB", (w, h_px), "white")
    d = ImageDraw.Draw(im)
    centered_text(d, (0, 20, w, 100), "单级89抽头线性相位FIR幅频响应", font(42, True))
    left, top, right, bottom = 180, 150, 2020, 840
    x = lambda khz: left + (right - left) * khz / 3000
    y = lambda db: top + (bottom - top) * (3 - db) / 153
    d.rectangle((x(10), top, x(500), bottom), fill="#E4F0FA")
    d.rectangle((x(1000), top, x(2400), bottom), fill="#FAEAEA")
    for khz in range(0, 3001, 500):
        d.line((x(khz), top, x(khz), bottom), fill="#D5DCE2", width=2)
        label = str(khz)
        d.text((x(khz) - 20, bottom + 14), label, font=font(22), fill="#333")
    for db in [0, -30, -60, -90, -120, -150]:
        d.line((left, y(db), right, y(db)), fill="#D5DCE2", width=2)
        d.text((90, y(db) - 13), str(db), font=font(22), fill="#333")
    d.line((left, top, left, bottom), fill="#222", width=3)
    d.line((left, bottom, right, bottom), fill="#222", width=3)
    h = fir_coefficients()
    points = []
    for i in range(3001):
        f = i * 1000.0
        mag = response_magnitude(h, f)
        db = max(-150.0, 20 * math.log10(max(mag, 1e-12)))
        points.append((x(i), y(db)))
    d.line(points, fill="#1261A0", width=4)
    centered_text(d, (left, 870, right, 940), "频率 / kHz", font(28))
    d.text((12, 440), "幅频响应 / dB", font=font(27), fill="#152B3C")
    d.text((x(65), top + 20), "有效信号：10~500 kHz", font=font(24), fill="#284B63")
    d.text((x(1370), top + 20), "软件抑制：1~2.4 MHz", font=font(24), fill="#8A3333")
    d.text((x(560), y(-18)), "500 kHz带内误差 < 0.00003 dB", font=font(24), fill="#333")
    d.text((x(1120), y(-48)), "1 MHz：200 mVpp干扰残留约0.363 mVpp",
           font=font(24), fill="#333")
    im.save(OUT / "filter_response.png", dpi=(180, 180))


def program_flow():
    im = Image.new("RGB", (1600, 1600), "white")
    d = ImageDraw.Draw(im)
    centered_text(d, (0, 15, 1600, 90), "主程序测量与标定流程", font(42, True))
    center = 650
    ys = [145, 335, 525, 715, 905, 1095, 1285]
    labels = [
        "等待USART2命令", "命令0：启动测量\n清零18轮累加器",
        "DMA采集16512点\n去128点FIR预热，保留16384点",
        "89抽头FIR + 16384点FFT\n估计频率、峰值与相位",
        "累计频谱和相干分量\n未满18轮则继续采集",
        "18轮平均、谐波确认\n500 Hz网格保护校准",
        "重构Vpp/RMS与波形\n锁存结果并发送HMI",
    ]
    widths = [430, 500, 610, 610, 590, 570, 570]
    boxes = []
    for cy, label, width in zip(ys, labels, widths):
        b = (center - width // 2, cy - 65, center + width // 2, cy + 65)
        boxes.append(b)
        box(d, b, label, font(26))
    for a, b in zip(boxes[:-1], boxes[1:]):
        arrow(d, (center, a[3] + 3), (center, b[1] - 3))
    box(d, (1050, 270, 1510, 435), "命令9：标定增益/偏置\nCRC校验写入W25Q64",
        font(25), fill="#FFF8EE", outline="#9A5B13")
    arrow(d, (870, 145), (1120, 260), "#9A5B13")
    arrow(d, (1280, 445), (965, 525), "#9A5B13")
    im.save(OUT / "program_flow.png", dpi=(180, 180))


def simulation_validation():
    width, height = 2100, 1320
    im = Image.new("RGB", (width, height), "white")
    d = ImageDraw.Draw(im)
    centered_text(d, (0, 15, width, 90), "带外干扰条件下的波形恢复与谐波识别", font(40, True))
    fs = 6_000_000.0
    count_total = 13_000
    gain, bias, vref = 6.0, 1.65, 3.3
    raw = []
    wanted = []
    for n in range(count_total):
        t = n / fs
        wv = (0.050 * math.sin(2 * math.pi * 100_000 * t + 0.2)
              + 0.020 * math.sin(2 * math.pi * 200_000 * t + 0.05)
              + 0.010 * math.sin(2 * math.pi * 300_000 * t + 1.15))
        rv = wv + 0.100 * math.sin(2 * math.pi * 1_200_000 * t - 0.7)
        code = max(0, min(4095, round((bias + gain * rv) / vref * 4095)))
        raw.append((code / 4095 * vref - bias) / gain)
        wanted.append(wv)
    coeff = fir_coefficients()
    filtered = [0.0] * count_total
    for n in range(len(coeff) - 1, count_total):
        filtered[n] = sum(coeff[k] * raw[n - k] for k in range(len(coeff)))
    delay = (len(coeff) - 1) // 2

    left, top, right, bottom = 180, 150, 2020, 700
    start, samples = 12_000, 120
    x = lambda idx: left + (right - left) * idx / (samples - 1)
    y = lambda mv: top + (bottom - top) * (170 - mv) / 340
    for mv in [-150, -100, -50, 0, 50, 100, 150]:
        d.line((left, y(mv), right, y(mv)), fill="#E1E5E8", width=2)
        d.text((90, y(mv) - 12), str(mv), font=font(20), fill="#444")
    for us in [0, 5, 10, 15, 20]:
        xx = left + (right - left) * us / 20
        d.line((xx, top, xx, bottom), fill="#E1E5E8", width=2)
        d.text((xx - 12, bottom + 10), str(us), font=font(20), fill="#444")
    raw_points = [(x(i), y(raw[start + i] * 1000)) for i in range(samples)]
    wanted_points = [(x(i), y(wanted[start + i] * 1000)) for i in range(samples)]
    filt_points = [(x(i), y(filtered[start + delay + i] * 1000)) for i in range(samples)]
    d.line(raw_points, fill="#A0A8AF", width=3)
    d.line(wanted_points, fill="#1261A0", width=4)
    d.line(filt_points, fill="#D1495B", width=3)
    d.line((left, top, left, bottom), fill="#222", width=3)
    d.line((left, bottom, right, bottom), fill="#222", width=3)
    d.text((880, 710), "时间 / μs", font=font(25), fill="#152B3C")
    d.text((10, 400), "电压 / mV", font=font(25), fill="#152B3C")
    d.line((250, 110, 330, 110), fill="#A0A8AF", width=5)
    d.text((340, 92), "ADC输入（含1.2 MHz、200 mVpp干扰）", font=font(21), fill="#333")
    d.line((900, 110, 980, 110), fill="#1261A0", width=5)
    d.text((990, 92), "理论有效信号", font=font(21), fill="#333")
    d.line((1370, 110, 1450, 110), fill="#D1495B", width=5)
    d.text((1460, 92), "89抽头FIR输出", font=font(21), fill="#333")

    chart_top, chart_bottom = 850, 1230
    chart_left, chart_right = 310, 1840
    d.line((chart_left, chart_top, chart_left, chart_bottom), fill="#222", width=3)
    d.line((chart_left, chart_bottom, chart_right, chart_bottom), fill="#222", width=3)
    expected = [50.0, 20.0, 10.0]
    measured = [49.73793, 19.71972, 10.10762]
    freqs = [100, 200, 300]
    scale = (chart_bottom - chart_top) / 58
    for i, (freq, exp, mea) in enumerate(zip(freqs, expected, measured)):
        cx = chart_left + 320 + i * 450
        bw = 90
        d.rectangle((cx - bw, chart_bottom - exp * scale, cx - 5, chart_bottom), fill="#8CC2E5")
        d.rectangle((cx + 5, chart_bottom - mea * scale, cx + bw, chart_bottom), fill="#2E6F5E")
        d.text((cx - 55, chart_bottom + 12), f"{freq} kHz", font=font(22), fill="#333")
        d.text((cx + 2, chart_bottom - mea * scale - 34), f"{mea:.3f}", font=font(19), fill="#333")
    for mv in [0, 10, 20, 30, 40, 50]:
        yy = chart_bottom - mv * scale
        d.line((chart_left, yy, chart_right, yy), fill="#E1E5E8", width=2)
        d.text((245, yy - 12), str(mv), font=font(20), fill="#444")
    d.text((20, 1025), "峰值 / mV", font=font(25), fill="#152B3C")
    d.rectangle((1480, 800, 1525, 825), fill="#8CC2E5")
    d.text((1535, 795), "理论峰值", font=font(21), fill="#333")
    d.rectangle((1710, 800, 1755, 825), fill="#2E6F5E")
    d.text((1765, 795), "MCU同路径仿真", font=font(21), fill="#333")
    im.save(OUT / "simulation_validation.png", dpi=(180, 180))


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    overall_flow()
    filter_response()
    program_flow()
    simulation_validation()
    print("generated", [p.name for p in sorted(OUT.glob("*.png"))])
