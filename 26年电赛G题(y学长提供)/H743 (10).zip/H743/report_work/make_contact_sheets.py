from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageOps, ImageDraw


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    pages = sorted(args.input.glob("page-*.png"), key=lambda p: int(p.stem.split("-")[-1]))
    for pair_index in range(0, len(pages), 2):
        pair = pages[pair_index:pair_index + 2]
        opened = [Image.open(path).convert("RGB") for path in pair]
        width = sum(image.width for image in opened) + 30 * (len(opened) + 1)
        height = max(image.height for image in opened) + 80
        sheet = Image.new("RGB", (width, height), "#d9d9d9")
        draw = ImageDraw.Draw(sheet)
        x = 30
        for path, page in zip(pair, opened):
            sheet.paste(ImageOps.expand(page, border=1, fill="black"), (x, 45))
            draw.text((x, 15), path.stem, fill="black")
            x += page.width + 30
        sheet.save(args.output / f"sheet-{pair_index // 2 + 1}.png")


if __name__ == "__main__":
    main()
