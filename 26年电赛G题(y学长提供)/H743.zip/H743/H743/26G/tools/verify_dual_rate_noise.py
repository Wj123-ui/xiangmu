#!/usr/bin/env python3
"""Exhaustive dual-rate alias-selection check for the contest noise range."""

from __future__ import annotations

import json
import math
import random

FJ_START_HZ = 1_000_000
FJ_STOP_HZ = 20_000_000
FJ_STEP_HZ = 500
USEFUL_MIN_HZ = 5_000.0
USEFUL_MAX_HZ = 510_000.0
OOB_START_HZ = 550_000.0
FFT_SIZE = 16_384
RATE_RATIO = 1.5
MATCH_TOLERANCE_HZ = 3.0 * 6_000_000.0 / FFT_SIZE
NOISE_PEAK_V = 0.100
MIN_UNMATCHED_V = 0.002
VALID_COMPONENTS = ((100_000.0, 0.060),
                    (200_000.0, 0.020),
                    (400_000.0, 0.010))


def alias_hz(frequency_hz: float, sample_rate_hz: float) -> float:
    folded = frequency_hz % sample_rate_hz
    return min(folded, sample_rate_hz - folded)


def in_useful_band(frequency_hz: float) -> bool:
    return USEFUL_MIN_HZ <= frequency_hz <= USEFUL_MAX_HZ


def unmatched_peak(source: list[tuple[float, float]],
                   other: list[tuple[float, float]]) -> float:
    value = 0.0
    for frequency_hz, amplitude_v in source:
        if amplitude_v < MIN_UNMATCHED_V:
            continue
        if any(abs(frequency_hz - other_frequency_hz) <= MATCH_TOLERANCE_HZ
               for other_frequency_hz, _ in other):
            continue
        value = max(value, amplitude_v)
    return value


def run_round(name: str, clock_correction: float,
              add_gain_imbalance: bool) -> dict[str, object]:
    fs6 = 6_000_000.0 * clock_correction
    fs48 = 4_800_000.0 * clock_correction
    rng = random.Random(0x743 + int(clock_correction * 1_000_000))
    failures: list[dict[str, float | str]] = []
    selected_6m = 0
    selected_48m = 0
    worst_selected_alias_hz = 0.0
    minimum_clean_margin_hz = math.inf

    for fj_hz in range(FJ_START_HZ, FJ_STOP_HZ + 1, FJ_STEP_HZ):
        a6 = alias_hz(float(fj_hz), fs6)
        a48 = alias_hz(float(fj_hz), fs48)
        gain6 = rng.uniform(0.82, 1.18) if add_gain_imbalance else 1.0
        gain48 = rng.uniform(0.82, 1.18) if add_gain_imbalance else 1.0

        peaks6 = list(VALID_COMPONENTS)
        peaks48 = list(VALID_COMPONENTS)
        if in_useful_band(a6):
            peaks6.append((a6, NOISE_PEAK_V * gain6))
        if in_useful_band(a48):
            peaks48.append((a48, NOISE_PEAK_V * gain48))

        unmatched6 = unmatched_peak(peaks6, peaks48)
        unmatched48 = unmatched_peak(peaks48, peaks6)
        oob6 = NOISE_PEAK_V * gain6 if a6 >= OOB_START_HZ else 0.0
        oob48 = NOISE_PEAK_V * gain48 if a48 >= OOB_START_HZ else 0.0

        if (unmatched6 >= MIN_UNMATCHED_V and
                unmatched6 > RATE_RATIO * unmatched48):
            selected = "4.8M"
            selected_alias = a48
            selected_48m += 1
        elif (unmatched48 >= MIN_UNMATCHED_V and
              unmatched48 > RATE_RATIO * unmatched6):
            selected = "6M"
            selected_alias = a6
            selected_6m += 1
        elif oob6 > RATE_RATIO * oob48:
            selected = "6M"
            selected_alias = a6
            selected_6m += 1
        else:
            selected = "4.8M"
            selected_alias = a48
            selected_48m += 1

        clean_alias = max(a6, a48)
        minimum_clean_margin_hz = min(
            minimum_clean_margin_hz, clean_alias - USEFUL_MAX_HZ)
        worst_selected_alias_hz = min(
            worst_selected_alias_hz or selected_alias, selected_alias)

        if in_useful_band(selected_alias):
            failures.append({
                "noise_hz": float(fj_hz),
                "alias_6m_hz": a6,
                "alias_4m8_hz": a48,
                "selected": selected,
                "selected_alias_hz": selected_alias,
            })

    case_count = ((FJ_STOP_HZ - FJ_START_HZ) // FJ_STEP_HZ) + 1
    return {
        "round": name,
        "case_count": case_count,
        "clock_correction": clock_correction,
        "gain_imbalance": add_gain_imbalance,
        "selected_6m": selected_6m,
        "selected_4m8": selected_48m,
        "minimum_at_least_one_rate_margin_above_510k_hz":
            round(minimum_clean_margin_hz, 3),
        "minimum_selected_alias_hz": round(worst_selected_alias_hz, 3),
        "failure_count": len(failures),
        "failure_examples": failures[:10],
    }


def main() -> int:
    rounds = [
        run_round("nominal_sample_clocks", 1.0, False),
        run_round("corrected_clocks_with_rate_gain_imbalance",
                  1.00002513, True),
    ]
    status = "PASS" if all(r["failure_count"] == 0 for r in rounds) else "FAIL"
    print(json.dumps({
        "status": status,
        "noise_range_hz": [FJ_START_HZ, FJ_STOP_HZ, FJ_STEP_HZ],
        "selection_match_tolerance_hz": MATCH_TOLERANCE_HZ,
        "rounds": rounds,
        "note": (
            "PASS proves the implemented alias-selection geometry for stable "
            "single-tone noise. Final <1 mV/<20 Hz accuracy still requires "
            "the hardware sweep recorded in the generated workbook."
        ),
    }, ensure_ascii=False, indent=2))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
