/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "hmi.h"
#include "calibration_store.h"
#include "signal_fft.h"
#include "signal_filter.h"
#include "arm_math.h"

#include <float.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

typedef struct
{
  uint8_t harmonic_order;
  float frequency_ratio;
  float amplitude_peak;
  float relative_phase_radians;
} app_raw_wave_component_t;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* Nominal analog front end: Vadc = ADC_DC_BIAS_VOLTAGE +
 *                                  ADC_FRONTEND_GAIN * Vin.
 * The final hardware uses the board 3.3 V rail as the external VREF+ source.
 * Command '9' measures and replaces both values at run time from a
 * 500 kHz, 0.100 Vpp, 0 V offset sine-wave calibration input.  A successful
 * command '9' update is committed to the board W25Q64 for the next power-up.
 */
#define ADC_REFERENCE_NOMINAL_VOLTAGE 3.300F
#define ADC_DC_BIAS_VOLTAGE     1.6103245F
#define ADC_FRONTEND_GAIN       6.8694482F
#define ADC_CALIBRATION_REFERENCE_VPP 0.1000F
#define ADC_CALIBRATION_REFERENCE_DC_OFFSET 0.0000F
#define ADC_CALIBRATION_FREQUENCY_HZ 500000.0F
#define ADC_CALIBRATION_FREQUENCY_TOLERANCE_HZ 5000.0F
#define APP_CALIBRATION_BUSY_DISPLAY_VALUE 111.0F
#define APP_SINGLE_TONE_HIGH_VPP_THRESHOLD 0.210F
#define APP_SINGLE_TONE_HIGH_VPP_CORRECTION 0.001F
#define APP_FREQUENCY_DISPLAY_OFFSET_KHZ 0.0106F
#define ADC_FULL_SCALE_CODE     4095.0F
#define ADC_CLIP_LOW_CODE       4U
#define ADC_CLIP_HIGH_CODE      4091U
#define ADC_CLIP_SAMPLE_LIMIT   4U

/*
 * Hardware validation switch:
 *   0: acquire the real PA6 signal through dual-interleaved ADC + DMA
 *   1: inject deterministic 12-bit ADC codes into the same FIR/FFT path
 *
 * Keep this at 0 in the final measurement firmware.
 */
#ifndef APP_ADC_SIMULATION_MODE
#define APP_ADC_SIMULATION_MODE 0U
#endif

/*
 * Keep the analog acquisition path disabled in the default waiting build.
 * The real build explicitly sets this to 0 after the VREF+/VDDA wiring is
 * confirmed and the user requests that acquisition be enabled.
 */
#ifndef APP_ANALOG_SAFE_MODE
#define APP_ANALOG_SAFE_MODE 1U
#endif

/* 512 full-rate samples keep the 16384-point frame aligned to 384-sample
 * FIR blocks and comfortably cover the 513-tap FIR settling interval. */
#define ADC_FILTER_WARMUP_SAMPLES 512U
#define ADC_RAW_WARMUP_SAMPLES \
    (ADC_FILTER_WARMUP_SAMPLES * SIGNAL_DECIMATION_FACTOR)
#define ADC_DECIMATED_COUNT \
    (SIGNAL_FFT_SIZE + ADC_FILTER_WARMUP_SAMPLES)
#define ADC_CAPTURE_COUNT \
    (ADC_DECIMATED_COUNT * SIGNAL_DECIMATION_FACTOR)
#define APP_MEASUREMENT_CAPTURE_COUNT 18U
#define APP_MEASUREMENT_TRIM_COUNT 4U
#define APP_CALIBRATION_CAPTURE_COUNT 18U
#define APP_CALIBRATION_TRIM_COUNT 4U
#define APP_CALIBRATION_MAX_GAIN_SPAN_RATIO 0.05F
#define APP_CALIBRATION_MAX_BIAS_SPAN_VOLTAGE 0.050F
#define APP_CAPTURE_FREQUENCY_CONSISTENCY_HZ 1500.0F
#define HMI_WAVE_POINT_COUNT    1024U
#define APP_FOLDED_EXTREME_CANDIDATE_COUNT 9U
#define APP_FOLDED_EXTREME_DISCARD_COUNT 1U
#define HMI_WAVE_HEIGHT         180
#define HMI_SPECTRUM_DYNAMIC_RANGE_DB 72.0F
#define APP_TWO_PI              6.28318530717958647692F
#define APP_SQUARE_RAW_EVEN_ENERGY_MAX 0.25F
#define APP_SQUARE_RAW_ODD_ENERGY_MIN 0.16F
#define APP_SQUARE_RAW_3_RATIO_MIN 0.13F
#define APP_SQUARE_RAW_3_RATIO_MAX 1.20F
#define APP_SQUARE_RAW_5_RATIO_MIN 0.015F
#define APP_SQUARE_RAW_5_RATIO_MAX 1.20F
#define APP_SQUARE_RAW_7_RATIO_MIN 0.008F
#define APP_SQUARE_RAW_7_RATIO_MAX 1.20F
#define APP_SQUARE_RAW_MIN_FUNDAMENTAL_CODES 8.0F
#define APP_SQUARE_RAW_MIN_7TH_CODES 0.20F
#define APP_SQUARE_HARMONIC_SNR_MIN 5.0F
#define APP_RAW_TONE_NOISE_FLOOR_CODES 0.05F
#define APP_RAW_COMPONENT_MIN_AMPLITUDE_VOLTAGE 0.001F
#define APP_RAW_HARMONIC_FFT_SIZE 4096U
#define APP_RAW_HARMONIC_TARGET_HALF_WIDTH 2
#define APP_RAW_HARMONIC_GUARD_FIRST 4
#define APP_RAW_HARMONIC_GUARD_LAST 5
#define APP_RAW_WAVE_MAX_COMPONENTS SIGNAL_FFT_MAX_PEAKS
#define APP_MAX_REPORTABLE_HARMONICS 2U
#define APP_MAX_SEPARATED_COMPONENTS \
    (1U + APP_MAX_REPORTABLE_HARMONICS)
#define APP_COHERENT_DETECTION_MIN_AMPLITUDE_VOLTAGE 0.00075F
#define APP_COHERENT_DETECTION_NOISE_MULTIPLIER 4.0F
#define APP_REPORTABLE_COMPONENT_MIN_AMPLITUDE_VOLTAGE 0.0020F
#define APP_COHERENT_MAX_HARMONIC_ORDER 60U
#define APP_COHERENT_MIN_CAPTURE_COUNT 10U
#define APP_COHERENT_MIN_PHASE_COHERENCE 0.40F
#define APP_RAW_WAVE_METRIC_POINTS 32768U
#define APP_CAPTURE_VPP_PHASE_POINTS 8192U
#define APP_RAW_HARMONIC_MAX_TARGET_HZ \
    ((((float)(APP_RAW_HARMONIC_FFT_SIZE / 2U) - \
       (float)APP_RAW_HARMONIC_GUARD_LAST - 1.0F) * \
      SIGNAL_ADC_SAMPLE_RATE_HZ) / \
     (float)APP_RAW_HARMONIC_FFT_SIZE)

#define HMI_VPP_ADDRESS         "x0.val"
#define HMI_RMS_ADDRESS         "x1.val"
#define HMI_FUNDAMENTAL_ADDRESS "x2.val"
#define HMI_FUNDAMENTAL_AMPLITUDE_ADDRESS "x3.val"
#define HMI_HARMONIC_1_FREQUENCY_ADDRESS  "x4.val"
#define HMI_HARMONIC_1_AMPLITUDE_ADDRESS  "x5.val"
#define HMI_HARMONIC_2_FREQUENCY_ADDRESS  "x6.val"
#define HMI_HARMONIC_2_AMPLITUDE_ADDRESS  "x7.val"
#define HMI_WAVE_ADDRESS         "s2.id"

_Static_assert((ADC_CAPTURE_COUNT % 2U) == 0U,
               "Dual ADC packed DMA requires an even sample count");
_Static_assert(
    (ADC_CAPTURE_COUNT % SIGNAL_FILTER_INPUT_BLOCK_SIZE) == 0U,
    "Capture count must contain complete FIR-decimator blocks");
_Static_assert(
    (ADC_RAW_WARMUP_SAMPLES + APP_RAW_HARMONIC_FFT_SIZE) <=
        ADC_CAPTURE_COUNT,
    "Raw harmonic FFT must fit inside the captured ADC block");
_Static_assert(
    APP_MAX_SEPARATED_COMPONENTS <= APP_RAW_WAVE_MAX_COMPONENTS,
    "Separated component storage is too small");
_Static_assert(
    (2U * APP_CALIBRATION_TRIM_COUNT) < APP_CALIBRATION_CAPTURE_COUNT,
    "Calibration trimming must leave at least one capture");
_Static_assert(
    (2U * APP_MEASUREMENT_TRIM_COUNT) < APP_MEASUREMENT_CAPTURE_COUNT,
    "Measurement trimming must leave at least one Vpp result");
_Static_assert(
    APP_FOLDED_EXTREME_DISCARD_COUNT <
        APP_FOLDED_EXTREME_CANDIDATE_COUNT,
    "Folded extreme trimming must leave at least one phase point");

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

static uint16_t adc_sample_buffer[ADC_CAPTURE_COUNT]
    __attribute__((section(".dma_buffer.adc"), aligned(32)));
static float adc_float_buffer[SIGNAL_FILTER_INPUT_BLOCK_SIZE];
static float filtered_sample_buffer[ADC_DECIMATED_COUNT]
    __attribute__((section(".ccmram"), aligned(4)));
static float spectrum_power_accumulator[
    SIGNAL_FFT_SPECTRUM_BIN_COUNT]
    __attribute__((section(".ccmram"), aligned(4)));
static float hmi_work_buffer[HMI_WAVE_POINT_COUNT];
static float hmi_folded_cycle_buffer[HMI_WAVE_POINT_COUNT];
static float hmi_fold_weight_buffer[HMI_WAVE_POINT_COUNT];
static signal_fft_result_t measurement_results[
    APP_MEASUREMENT_CAPTURE_COUNT];
static int saved_one_period_wave[HMI_WAVE_POINT_COUNT];
static int saved_three_period_wave[HMI_WAVE_POINT_COUNT];
static int saved_spectrum_graph[HMI_WAVE_POINT_COUNT];
static app_raw_wave_component_t raw_wave_components[
    APP_RAW_WAVE_MAX_COMPONENTS];
static uint8_t raw_wave_component_count;
static float coherent_harmonic_sine_sum[
    APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
static float coherent_harmonic_cosine_sum[
    APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
static float coherent_harmonic_amplitude_sum[
    APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
static uint8_t coherent_harmonic_capture_count[
    APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
static uint8_t coherent_harmonic_evidence_count[
    APP_COHERENT_MAX_HARMONIC_ORDER + 1U];

static volatile uint8_t adc_block_ready;
static volatile uint8_t adc_capture_error;
static uint8_t measurement_start_request;
static uint8_t fft_measurement_active;
static uint8_t adc_capture_retry_count;
static signal_fft_result_t fft_work_result;
static signal_fft_result_t latest_fft_result;
static uint8_t latest_fft_valid;
static uint8_t saved_spectrum_valid;
static uint8_t hmi_folded_cycle_valid;
static uint8_t measurement_result_ready;
static uint8_t calibration_result_output_pending;
static uint8_t calibration_measurement_active;
static uint8_t calibration_capture_count;
static uint8_t measurement_capture_count;
static uint8_t spectrum_accumulation_count;
static float measurement_trimmed_vpp;
static float calibration_gain_candidates[
    APP_CALIBRATION_CAPTURE_COUNT];
static float calibration_bias_candidates[
    APP_CALIBRATION_CAPTURE_COUNT];
/* VREF+ is driven externally from the board 3.3 V rail.  Command '9'
 * calibrates the analog-front-end bias and gain in situ. */
static float adc_reference_voltage = ADC_REFERENCE_NOMINAL_VOLTAGE;
static float adc_dc_bias_voltage = ADC_DC_BIAS_VOLTAGE;
static float adc_frontend_gain = ADC_FRONTEND_GAIN;
/* Kept volatile so the VREFINT startup measurement can be inspected over
 * SWD without adding anything to the fixed UART/HMI protocol. */
volatile uint32_t adc_vrefint_average_code;
volatile uint32_t adc_vrefint_millivolts;
volatile uint32_t adc_vrefint_status;
volatile uint32_t device_revision_id;
#if APP_ADC_SIMULATION_MODE
static volatile uint32_t app_debug_processing_ms;
#endif

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MPU_Config(void);
/* USER CODE BEGIN PFP */

void fft_porc(void);
void uart_proc(void);

#if !APP_ANALOG_SAFE_MODE
static bool VREF_ExternalConfig(void);
#endif
static HAL_StatusTypeDef ADC_Capture_Start(void);
static HAL_StatusTypeDef ADC_Capture_Stop(void);
static HAL_StatusTypeDef FFT_StartMeasurement(void);
#if APP_ADC_SIMULATION_MODE
static void ADC_FillSimulatedSamples(void);
#endif
static void ADC_ConvertBlockToInputVoltage(uint32_t input_offset,
                                           uint32_t sample_count);
static bool ADC_BlockIsClipped(void);
static bool ADC_EstimateRawTone(float frequency_hz,
                                float mean_code,
                                float *amplitude,
                                float *phase_radians);
static bool App_EstimateFilteredHarmonicBank(
    float fundamental_frequency_hz,
    uint16_t maximum_harmonic_order,
    float *amplitudes,
    float *phases_radians);
static bool App_AnalyzeCapturedBlock(signal_fft_result_t *result);
static bool App_AccumulateSpectrum(void);
static bool App_AccumulateCoherentComponents(
    const signal_fft_result_t *result);
static float App_GetFrontendAmplitudeCorrection(
    float frequency_hz);
static bool App_UpdateFrontendCalibration(
    const signal_fft_result_t *result);
static bool App_CollectFrontendCalibration(
    const signal_fft_result_t *result);
static void App_SortFloatAscending(float *values,
                                   uint8_t count);
static bool App_BuildSeparatedWaveComponents(
    signal_fft_result_t *result);
static bool App_CalculateSeparatedVoltageMetrics(
    signal_fft_result_t *result);
static bool App_CalculateCaptureSpectralVpp(
    signal_fft_result_t *result);
static bool App_FinalizeMeasurementResults(void);
static void App_SetMeasurementUnavailable(void);
static float App_EstimateFundamentalHz(void);
static float App_GetSeparatedFundamentalAmplitude(void);
static bool App_GetSeparatedHarmonic(
    uint8_t separated_harmonic_index,
    float *frequency_hz,
    float *amplitude_peak);
static bool App_AccumulateFilteredFoldedCapture(
    const signal_fft_result_t *result);
static bool App_FinalizeFoldedCycle(void);
static bool App_CalculateFoldedVoltageMetrics(
    signal_fft_result_t *result);
static void App_SaveSpectrumGraph(void);
static bool App_PrepareTimeWave(uint8_t cycle_count,
                                int *wave_buffer);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

int _write(int file, char *data, int length)
{
  (void)file;

  if ((data == NULL) || (length <= 0))
  {
    return 0;
  }

  if (HAL_UART_Transmit(&huart2,
                        (uint8_t *)data,
                        (uint16_t)length,
                        HAL_MAX_DELAY) != HAL_OK)
  {
    return -1;
  }

  return length;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MPU Configuration--------------------------------------------------------*/
  MPU_Config();

  /* Enable the CPU caches.  DMA1 uses an MPU-marked non-cacheable buffer. */
  SCB_EnableICache();
  SCB_EnableDCache();

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  device_revision_id = HAL_GetREVID();
  if (device_revision_id != REV_ID_V)
  {
    /*
     * This high-performance build targets Rev.V.  Older revisions cannot
     * safely combine the selected 480 MHz CPU clock and Rev.V ADC clock
     * topology.  Leave the revision visible to the debugger and stop safely.
     */
    Error_Handler();
  }

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  if ((HAL_RCC_GetSysClockFreq() != 480000000U) ||
      (HAL_RCC_GetHCLKFreq() != 240000000U) ||
      (HAL_RCC_GetPCLK1Freq() != 120000000U) ||
      (HAL_RCC_GetPCLK2Freq() != 120000000U))
  {
    Error_Handler();
  }

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
#if !APP_ADC_SIMULATION_MODE
  /* Load the newest CRC-validated W25Q64 calibration record.  A blank,
   * disconnected or corrupt flash is non-fatal and leaves the compiled
   * defaults in adc_frontend_gain/adc_dc_bias_voltage. */
  if (CalibrationStore_Init(&adc_frontend_gain,
                            &adc_dc_bias_voltage) &&
      ((calibration_store_status &
        CALIBRATION_STORE_STATUS_LOADED) == 0U))
  {
    /* First boot with a blank W25Q64: establish a validated baseline once.
     * Subsequent boots load it and perform no erase/program operation. */
    (void)CalibrationStore_Save(adc_frontend_gain,
                                adc_dc_bias_voltage);
  }
#endif
  MX_DMA_Init();
#if !APP_ANALOG_SAFE_MODE
  /*
   * PA20/VREF+ is driven by the board 3.3 V rail.  Disable the internal
   * VREFBUF and leave its output in high impedance to prevent contention.
   */
  if (!VREF_ExternalConfig())
  {
    Error_Handler();
  }
  MX_ADC2_Init();
  MX_ADC1_Init();
  /*
   * PLL2P supplies 48 MHz.  Rev.V devices contain the documented fixed
   * divide-by-two ADC path, so the converter clock is 24 MHz.
   */
  if (HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_ADC) != 48000000U)
  {
    Error_Handler();
  }
#endif
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  setvbuf(stdout, NULL, _IONBF, 0);

  if (!HMI_UART_StartReceive())
  {
    Error_Handler();
  }

  if (!Signal_Filter_Init())
  {
    Error_Handler();
  }

  if (!Signal_FFT_Init(NULL))
  {
    Error_Handler();
  }

#if APP_ADC_SIMULATION_MODE
  /* The host verification script advances the deterministic cases with the
   * unchanged '0' command.  Do not auto-run here: an autonomous measurement
   * stream can otherwise overlap a host command on the same UART. */
  measurement_start_request = 0U;
#endif
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    uart_proc();
    fft_porc();
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE0);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 5;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_2;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }

  /*
   * ST recommends the I/O compensation cell at high bus/GPIO speeds.
   * CSI is used only as the compensation-cell clock, not as SYSCLK.
   */
  __HAL_RCC_CSI_ENABLE();
  __HAL_RCC_SYSCFG_CLK_ENABLE();
  HAL_EnableCompensationCell();
}

/* USER CODE BEGIN 4 */

#if !APP_ANALOG_SAFE_MODE
static bool VREF_ExternalConfig(void)
{
  /*
   * The board 3.3 V rail drives VREF+ directly.  Do not enable the internal
   * VREFBUF while that connection is present.  Its high-impedance state is
   * checked here before either real ADC is initialized.
   */
  adc_vrefint_average_code = 0U;
  adc_vrefint_millivolts = 3300U;
  adc_vrefint_status = 0U;
  adc_reference_voltage = ADC_REFERENCE_NOMINAL_VOLTAGE;

  __HAL_RCC_VREF_CLK_ENABLE();
  HAL_SYSCFG_DisableVREFBUF();
  HAL_SYSCFG_VREFBUF_HighImpedanceConfig(
      SYSCFG_VREFBUF_HIGH_IMPEDANCE_ENABLE);

  if (((VREFBUF->CSR & VREFBUF_CSR_ENVR) != 0U) ||
      ((VREFBUF->CSR & VREFBUF_CSR_HIZ) == 0U))
  {
    adc_vrefint_status = 1U;
    return false;
  }

  adc_vrefint_status = 6U;
  return true;
}
#endif

static HAL_StatusTypeDef ADC_Capture_Stop(void)
{
#if APP_ADC_SIMULATION_MODE || APP_ANALOG_SAFE_MODE
  return HAL_OK;
#else
  /*
   * MultiModeStop disables both ADC1 and ADC2 and aborts the master DMA.
   * Avoid stopping an already-idle handle because HAL_DMA_Abort reports an
   * error when no DMA transfer has ever been started.
   */
  if ((HAL_ADC_GetState(&hadc1) &
       (HAL_ADC_STATE_REG_BUSY | HAL_ADC_STATE_INJ_BUSY)) != 0U)
  {
    return HAL_ADCEx_MultiModeStop_DMA(&hadc1);
  }

  return HAL_OK;
#endif
}

static HAL_StatusTypeDef ADC_Capture_Start(void)
{
#if APP_ADC_SIMULATION_MODE
  ADC_FillSimulatedSamples();
  adc_block_ready = 1U;
  return HAL_OK;
#elif APP_ANALOG_SAFE_MODE
  return HAL_ERROR;
#else
  /*
   * H743 dual-interleaved packed mode transfers two chronological 12-bit
   * samples per 32-bit DMA word.  On Cortex-M little-endian memory the
   * uint16_t buffer is already ordered ADC1, ADC2, ADC1, ADC2, ...
   */
  if (ADC_Capture_Stop() != HAL_OK)
  {
    return HAL_ERROR;
  }

  __HAL_ADC_CLEAR_FLAG(
      &hadc1,
      ADC_FLAG_EOC | ADC_FLAG_EOS | ADC_FLAG_OVR);
  __HAL_ADC_CLEAR_FLAG(
      &hadc2,
      ADC_FLAG_EOC | ADC_FLAG_EOS | ADC_FLAG_OVR);
  HAL_NVIC_ClearPendingIRQ(ADC_IRQn);
  HAL_NVIC_ClearPendingIRQ(DMA1_Stream0_IRQn);

  /*
   * Drain the packed common data register once before arming DMA so a prior
   * capture cannot leave a stale word or overrun indication.
   */
  (void)HAL_ADCEx_MultiModeGetValue(&hadc1);
  __HAL_ADC_CLEAR_FLAG(
      &hadc1,
      ADC_FLAG_EOC | ADC_FLAG_EOS | ADC_FLAG_OVR);
  __HAL_ADC_CLEAR_FLAG(
      &hadc2,
      ADC_FLAG_EOC | ADC_FLAG_EOS | ADC_FLAG_OVR);
  HAL_NVIC_ClearPendingIRQ(ADC_IRQn);

  if (HAL_ADCEx_MultiModeStart_DMA(
          &hadc1,
          (uint32_t *)adc_sample_buffer,
          ADC_CAPTURE_COUNT / 2U) != HAL_OK)
  {
    (void)ADC_Capture_Stop();
    return HAL_ERROR;
  }

  return HAL_OK;
#endif
}

#if APP_ADC_SIMULATION_MODE
typedef enum
{
  ADC_SIMULATION_SINE = 0,
  ADC_SIMULATION_SQUARE,
  ADC_SIMULATION_HARMONICS,
  ADC_SIMULATION_TRUNCATED_SQUARE,
  ADC_SIMULATION_TRIANGLE,
  ADC_SIMULATION_SAWTOOTH,
  ADC_SIMULATION_PULSE_25,
  ADC_SIMULATION_CLIPPED_SINE
} adc_simulation_waveform_t;

typedef struct
{
  adc_simulation_waveform_t waveform;
  float fundamental_hz;
  float fundamental_peak;
  uint8_t harmonic_2_order;
  float harmonic_2_peak;
  uint8_t harmonic_3_order;
  float harmonic_3_peak;
  float interference_hz;
  float interference_peak;
  float harmonic_2_phase;
  float harmonic_3_phase;
  uint8_t custom_harmonic_phases;
} adc_simulation_case_t;

static const adc_simulation_case_t adc_simulation_cases[] =
{
  /* Requested end-to-end checks: 1.000 Vpp, 100 kHz. */
  {ADC_SIMULATION_SINE,
   100000.0F, 0.1250F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},
  {ADC_SIMULATION_SQUARE,
   100000.0F, 0.1250F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},
  {ADC_SIMULATION_SQUARE,
   200000.0F, 0.1250F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},
  {ADC_SIMULATION_SQUARE,
   400000.0F, 0.1250F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},
  {ADC_SIMULATION_SQUARE,
   500000.0F, 0.1250F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},

  /* Official-range multi-tone example from the problem statement. */
  {ADC_SIMULATION_HARMONICS,
   10500.0F, 0.0500F, 3U, 0.0200F, 4U, 0.0100F, 0.0F, 0.0F},

  /* Extended upper-band check. */
  {ADC_SIMULATION_SINE,
   550000.0F, 0.1000F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},

  /* Requirement 3: target signal plus 200 mVpp at 1.2 MHz. */
  {ADC_SIMULATION_HARMONICS,
   100000.0F, 0.0500F, 2U, 0.0200F, 3U, 0.0100F,
   1200000.0F, 0.1000F},

  /* Official amplitude/frequency boundary checks. */
  {ADC_SIMULATION_SINE,
   10000.0F, 0.0250F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},
  {ADC_SIMULATION_SINE,
   200000.0F, 0.1250F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},
  {ADC_SIMULATION_SINE,
   500000.0F, 0.0250F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},
  {ADC_SIMULATION_SINE,
   500000.0F, 0.1250F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},
  {ADC_SIMULATION_SINE,
   599000.0F, 0.1250F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},

  /*
   * Regression: a normal fundamental + third harmonic must not be mistaken
   * for a square wave merely because A3/A1 falls inside the old threshold.
   */
  {ADC_SIMULATION_HARMONICS,
   100000.0F, 0.0500F, 3U, 0.0200F, 0U, 0.0F, 0.0F, 0.0F},

  /* Upper-band phase/amplitude check including an exact 600 kHz line. */
  {ADC_SIMULATION_HARMONICS,
   200000.0F, 0.0500F, 2U, 0.0200F, 3U, 0.0100F, 0.0F, 0.0F},

  /*
   * Legal finite A1+A3+A5 input with square-like low-band ratios/phases.
   * It must retain its reconstructed 112 mVpp instead of being promoted
   * to an ideal square wave (94.25 mVpp).
   */
  {ADC_SIMULATION_TRUNCATED_SQUARE,
   100000.0F, 0.0600F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},

  /*
   * Out-of-spec robustness waveforms.  These have infinitely many
   * harmonics, so the measured waveform is intentionally the part below
   * the configured 600 kHz analysis limit.
   */
  {ADC_SIMULATION_TRIANGLE,
   100000.0F, 0.1250F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},
  {ADC_SIMULATION_SAWTOOTH,
   80000.0F, 0.1000F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},
  {ADC_SIMULATION_PULSE_25,
   60000.0F, 0.1000F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},
  {ADC_SIMULATION_CLIPPED_SINE,
   120000.0F, 0.1000F, 0U, 0.0F, 0U, 0.0F, 0.0F, 0.0F},

  /*
   * Finite, legal asymmetric-phase signal.  Its relative phases are
   * deliberately non-zero so the saved 1/3-cycle waves can be checked
   * against phase-free reconstruction errors.
   */
  {ADC_SIMULATION_HARMONICS,
   75000.0F, 0.0700F, 2U, 0.0250F, 5U, 0.0120F, 0.0F, 0.0F},

  /* Additional G-problem stress matrix: frequency, amplitude and phase. */
  {ADC_SIMULATION_HARMONICS,
   10000.0F, 0.0080F, 2U, 0.0300F, 5U, 0.0200F,
   0.0F, 0.0F, 1.10F, -0.80F, 1U},
  {ADC_SIMULATION_HARMONICS,
   12500.0F, 0.0400F, 3U, 0.0250F, 7U, 0.0150F,
   0.0F, 0.0F, 0.90F, -1.20F, 1U},
  {ADC_SIMULATION_HARMONICS,
   37500.0F, 0.0450F, 2U, 0.0300F, 5U, 0.0180F,
   0.0F, 0.0F, -1.10F, 0.75F, 1U},
  {ADC_SIMULATION_HARMONICS,
   83000.0F, 0.0350F, 2U, 0.0280F, 4U, 0.0410F,
   0.0F, 0.0F, 1.25F, -0.65F, 1U},
  {ADC_SIMULATION_HARMONICS,
   125000.0F, 0.0500F, 2U, 0.0250F, 4U, 0.0150F,
   0.0F, 0.0F, -0.90F, 1.40F, 1U},
  {ADC_SIMULATION_HARMONICS,
   160000.0F, 0.0250F, 2U, 0.0500F, 3U, 0.0200F,
   0.0F, 0.0F, 0.60F, -1.00F, 1U},
  {ADC_SIMULATION_HARMONICS,
   250000.0F, 0.0600F, 2U, 0.0400F, 0U, 0.0F,
   0.0F, 0.0F, 1.30F, 0.0F, 1U},
  {ADC_SIMULATION_HARMONICS,
   50000.0F, 0.0400F, 3U, 0.0250F, 7U, 0.0150F,
   1050000.0F, 0.1000F, -0.45F, 1.10F, 1U}
};

static uint32_t adc_simulation_case_index;

static void ADC_FillSimulatedSamples(void)
{
  const uint32_t case_count =
      sizeof(adc_simulation_cases) /
      sizeof(adc_simulation_cases[0]);
  const adc_simulation_case_t *test_case =
      &adc_simulation_cases[
          (adc_simulation_case_index /
           APP_MEASUREMENT_CAPTURE_COUNT) %
          case_count];
  const uint32_t capture_index =
      adc_simulation_case_index %
      APP_MEASUREMENT_CAPTURE_COUNT;
  const float capture_phase =
      0.20F + 0.73F * (float)capture_index;
  uint32_t index;

  adc_simulation_case_index++;

  for (index = 0U; index < ADC_CAPTURE_COUNT; index++)
  {
    const float time_seconds =
        (float)index / SIGNAL_ADC_SAMPLE_RATE_HZ;
    const float base_phase =
        APP_TWO_PI * test_case->fundamental_hz *
            time_seconds +
        capture_phase;
    const float aligned_phase = base_phase;
    float input_voltage;

    if (test_case->waveform == ADC_SIMULATION_SQUARE)
    {
      uint32_t odd_harmonic;
      const float base_sine = sinf(aligned_phase);
      const float sine_squared = base_sine * base_sine;
      const float sine_cubed =
          base_sine * sine_squared;
      const float sine_fifth =
          sine_cubed * sine_squared;
      const float sine_seventh =
          sine_fifth * sine_squared;
      const float odd_sines[4] =
      {
        base_sine,
        3.0F * base_sine - 4.0F * sine_cubed,
        5.0F * base_sine - 20.0F * sine_cubed +
            16.0F * sine_fifth,
        7.0F * base_sine - 56.0F * sine_cubed +
            112.0F * sine_fifth - 64.0F * sine_seventh
      };

      /*
       * The real analog front end is bandwidth limited.  Generate the
       * first four odd Fourier components instead of an infinite-edge
       * digital square; otherwise components above the 7.20 MSPS Nyquist
       * limit alias and a 500 kHz self-test can falsely appear at 100 kHz.
       * fundamental_peak remains the intended square-wave half Vpp.
       */
      input_voltage = 0.0F;

      for (odd_harmonic = 1U;
           odd_harmonic <= 7U;
           odd_harmonic += 2U)
      {
        const float harmonic_frequency =
            (float)odd_harmonic *
            test_case->fundamental_hz;

        if (harmonic_frequency >=
            (0.49F * SIGNAL_ADC_SAMPLE_RATE_HZ))
        {
          break;
        }

        input_voltage +=
            (8.0F * test_case->fundamental_peak /
             APP_TWO_PI) *
            odd_sines[(odd_harmonic - 1U) / 2U] /
            (float)odd_harmonic;
      }
    }
    else if (test_case->waveform ==
             ADC_SIMULATION_TRUNCATED_SQUARE)
    {
      input_voltage =
          test_case->fundamental_peak *
              (sinf(aligned_phase) +
               sinf(3.0F * aligned_phase) / 3.0F +
               sinf(5.0F * aligned_phase) / 5.0F);
    }
    else if (test_case->waveform == ADC_SIMULATION_TRIANGLE)
    {
      const float cycle_fraction =
          aligned_phase / APP_TWO_PI -
          floorf(aligned_phase / APP_TWO_PI);

      input_voltage =
          test_case->fundamental_peak *
          (1.0F - 4.0F * fabsf(cycle_fraction - 0.5F));
    }
    else if (test_case->waveform == ADC_SIMULATION_SAWTOOTH)
    {
      const float cycle_fraction =
          aligned_phase / APP_TWO_PI -
          floorf(aligned_phase / APP_TWO_PI);

      input_voltage =
          test_case->fundamental_peak *
          (2.0F * cycle_fraction - 1.0F);
    }
    else if (test_case->waveform == ADC_SIMULATION_PULSE_25)
    {
      const float cycle_fraction =
          aligned_phase / APP_TWO_PI -
          floorf(aligned_phase / APP_TWO_PI);

      input_voltage =
          (cycle_fraction < 0.25F) ?
              test_case->fundamental_peak :
              -test_case->fundamental_peak;
    }
    else if (test_case->waveform == ADC_SIMULATION_CLIPPED_SINE)
    {
      float clipped = 1.6F * sinf(aligned_phase);

      if (clipped > 1.0F)
      {
        clipped = 1.0F;
      }
      else if (clipped < -1.0F)
      {
        clipped = -1.0F;
      }

      input_voltage = test_case->fundamental_peak * clipped;
    }
    else
    {
      input_voltage =
          test_case->fundamental_peak *
              sinf(aligned_phase);

      if (test_case->waveform == ADC_SIMULATION_HARMONICS)
      {
        const float harmonic_2_phase =
            (test_case->custom_harmonic_phases != 0U) ?
                test_case->harmonic_2_phase : -0.35F;
        const float harmonic_3_phase =
            (test_case->custom_harmonic_phases != 0U) ?
                test_case->harmonic_3_phase : 0.55F;

        input_voltage +=
            test_case->harmonic_2_peak *
                sinf((float)test_case->harmonic_2_order *
                         base_phase +
                     harmonic_2_phase) +
            test_case->harmonic_3_peak *
                sinf((float)test_case->harmonic_3_order *
                         base_phase +
                     harmonic_3_phase);
      }
    }

    if (test_case->interference_peak > 0.0F)
    {
      input_voltage +=
          test_case->interference_peak *
              sinf(APP_TWO_PI *
                       test_case->interference_hz *
                       time_seconds +
                   0.75F +
                   0.47F * (float)capture_index);
    }

    {
    const float adc_voltage =
        adc_dc_bias_voltage +
        adc_frontend_gain * input_voltage;
    int32_t adc_code =
        (int32_t)lrintf(
            adc_voltage * ADC_FULL_SCALE_CODE /
            adc_reference_voltage);

    if (adc_code < 0)
    {
      adc_code = 0;
    }
    else if (adc_code > (int32_t)ADC_FULL_SCALE_CODE)
    {
      adc_code = (int32_t)ADC_FULL_SCALE_CODE;
    }

    adc_sample_buffer[index] = (uint16_t)adc_code;
    }
  }
}
#endif

static HAL_StatusTypeDef FFT_StartMeasurement(void)
{
  adc_block_ready = 0U;
  adc_capture_error = 0U;
  adc_capture_retry_count = 0U;

  if (ADC_Capture_Start() != HAL_OK)
  {
    fft_measurement_active = 0U;
    return HAL_ERROR;
  }

  fft_measurement_active = 1U;
  return HAL_OK;
}

static void ADC_ConvertBlockToInputVoltage(uint32_t input_offset,
                                           uint32_t sample_count)
{
    uint32_t index;
  const float input_volts_per_code =
      adc_reference_voltage /
      (ADC_FULL_SCALE_CODE * adc_frontend_gain);
  const float input_dc_offset =
      adc_dc_bias_voltage / adc_frontend_gain;

  for (index = 0U; index < sample_count; index++)
  {
    adc_float_buffer[index] =
        (float)adc_sample_buffer[input_offset + index] *
            input_volts_per_code -
        input_dc_offset;
  }
}

static bool ADC_BlockIsClipped(void)
{
#if APP_ADC_SIMULATION_MODE
  return false;
#else
  uint32_t index;
  uint32_t saturated_sample_count = 0U;

  for (index = ADC_RAW_WARMUP_SAMPLES;
       index < ADC_CAPTURE_COUNT;
       index++)
  {
    if ((adc_sample_buffer[index] <= ADC_CLIP_LOW_CODE) ||
        (adc_sample_buffer[index] >= ADC_CLIP_HIGH_CODE))
    {
      saturated_sample_count++;

      if (saturated_sample_count >= ADC_CLIP_SAMPLE_LIMIT)
      {
        return true;
      }
    }
  }

  return false;
#endif
}

static bool ADC_EstimateRawTone(float frequency_hz,
                                float mean_code,
                                float *amplitude,
                                float *phase_radians)
{
  const float angular_step =
      APP_TWO_PI * frequency_hz /
      SIGNAL_ADC_SAMPLE_RATE_HZ;
  const float window_angular_step =
      APP_TWO_PI / (float)(ADC_CAPTURE_COUNT - 1U);
  const float step_sine = sinf(angular_step);
  const float step_cosine = cosf(angular_step);
  const float window_step_sine =
      sinf(window_angular_step);
  const float window_step_cosine =
      cosf(window_angular_step);
  float oscillator_sine = 0.0F;
  float oscillator_cosine = 1.0F;
  float window_sine = 0.0F;
  float window_cosine = 1.0F;
  float sine_coefficient = 0.0F;
  float cosine_coefficient = 0.0F;
  float window_sum = 0.0F;
  uint32_t index;

  if ((amplitude == NULL) ||
      (phase_radians == NULL) ||
      (!isfinite(frequency_hz)) ||
      (frequency_hz <= 0.0F) ||
      (frequency_hz >=
       (0.5F * SIGNAL_ADC_SAMPLE_RATE_HZ)))
  {
    return false;
  }

  for (index = 0U; index < ADC_CAPTURE_COUNT; index++)
  {
    const float window = 0.5F - 0.5F * window_cosine;
    const float sample =
        ((float)adc_sample_buffer[index] - mean_code) * window;
    float next_sine;
    float next_window_sine;

    sine_coefficient += sample * oscillator_sine;
    cosine_coefficient += sample * oscillator_cosine;
    window_sum += window;

    next_sine =
        oscillator_sine * step_cosine +
        oscillator_cosine * step_sine;
    oscillator_cosine =
        oscillator_cosine * step_cosine -
        oscillator_sine * step_sine;
    oscillator_sine = next_sine;

    next_window_sine =
        window_sine * window_step_cosine +
        window_cosine * window_step_sine;
    window_cosine =
        window_cosine * window_step_cosine -
        window_sine * window_step_sine;
    window_sine = next_window_sine;

    if ((index & 0xFFU) == 0xFFU)
    {
      float inverse_length =
          1.0F /
          sqrtf(oscillator_sine * oscillator_sine +
                oscillator_cosine * oscillator_cosine);
      float inverse_window_length =
          1.0F /
          sqrtf(window_sine * window_sine +
                window_cosine * window_cosine);

      oscillator_sine *= inverse_length;
      oscillator_cosine *= inverse_length;
      window_sine *= inverse_window_length;
      window_cosine *= inverse_window_length;
    }
  }

  if (window_sum <= 0.0F)
  {
    return false;
  }

  *amplitude =
      2.0F *
      sqrtf(sine_coefficient * sine_coefficient +
            cosine_coefficient * cosine_coefficient) /
      window_sum;
  *phase_radians =
      atan2f(cosine_coefficient, sine_coefficient);
  return isfinite(*amplitude) && isfinite(*phase_radians);
}

static bool App_EstimateFilteredHarmonicBank(
    float fundamental_frequency_hz,
    uint16_t maximum_harmonic_order,
    float *amplitudes,
    float *phases_radians)
{
  const float window_step =
      APP_TWO_PI / (float)(SIGNAL_FFT_SIZE - 1U);
  const float window_step_sine = sinf(window_step);
  const float window_step_cosine = cosf(window_step);
  float tone_step_sine[APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
  float tone_step_cosine[APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
  float tone_sine[APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
  float tone_cosine[APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
  float sine_coefficient[APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
  float cosine_coefficient[APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
  float window_sine = 0.0F;
  float window_cosine = 1.0F;
  float window_sum = 0.0F;
  uint32_t index;
  uint16_t harmonic_order;

  if ((amplitudes == NULL) ||
      (phases_radians == NULL) ||
      (!isfinite(fundamental_frequency_hz)) ||
      (fundamental_frequency_hz <= 0.0F) ||
      (maximum_harmonic_order == 0U) ||
      (maximum_harmonic_order > APP_COHERENT_MAX_HARMONIC_ORDER) ||
      (((float)maximum_harmonic_order *
        fundamental_frequency_hz) >=
       (0.5F * SIGNAL_ANALYSIS_SAMPLE_RATE_HZ)))
  {
    return false;
  }

  memset(amplitudes,
         0,
         (APP_COHERENT_MAX_HARMONIC_ORDER + 1U) *
             sizeof(amplitudes[0]));
  memset(phases_radians,
         0,
         (APP_COHERENT_MAX_HARMONIC_ORDER + 1U) *
             sizeof(phases_radians[0]));
  memset(sine_coefficient, 0, sizeof(sine_coefficient));
  memset(cosine_coefficient, 0, sizeof(cosine_coefficient));

  for (harmonic_order = 1U;
       harmonic_order <= maximum_harmonic_order;
       harmonic_order++)
  {
    const float tone_step =
        APP_TWO_PI * (float)harmonic_order *
        fundamental_frequency_hz /
        SIGNAL_ANALYSIS_SAMPLE_RATE_HZ;

    tone_step_sine[harmonic_order] = sinf(tone_step);
    tone_step_cosine[harmonic_order] = cosf(tone_step);
    tone_sine[harmonic_order] = 0.0F;
    tone_cosine[harmonic_order] = 1.0F;
  }

  /*
   * Hann-windowed synchronous projections at every exact integer multiple
   * of the measured fundamental. The previous implementation traversed the
   * same 16384 samples and regenerated the identical Hann window once per
   * harmonic. Sharing that window and sample load leaves every projection
   * equation unchanged while avoiding up to sixty redundant traversals.
   */
  for (index = 0U; index < SIGNAL_FFT_SIZE; index++)
  {
    const float window = 0.5F - 0.5F * window_cosine;
    const float sample =
        filtered_sample_buffer[
            ADC_FILTER_WARMUP_SAMPLES + index] *
        window;
    float next_window_sine;

    for (harmonic_order = 1U;
         harmonic_order <= maximum_harmonic_order;
         harmonic_order++)
    {
      const float next_tone_sine =
          tone_sine[harmonic_order] *
              tone_step_cosine[harmonic_order] +
          tone_cosine[harmonic_order] *
              tone_step_sine[harmonic_order];

      sine_coefficient[harmonic_order] +=
          sample * tone_sine[harmonic_order];
      cosine_coefficient[harmonic_order] +=
          sample * tone_cosine[harmonic_order];
      tone_cosine[harmonic_order] =
          tone_cosine[harmonic_order] *
              tone_step_cosine[harmonic_order] -
          tone_sine[harmonic_order] *
              tone_step_sine[harmonic_order];
      tone_sine[harmonic_order] = next_tone_sine;
    }
    window_sum += window;

    next_window_sine =
        window_sine * window_step_cosine +
        window_cosine * window_step_sine;
    window_cosine =
        window_cosine * window_step_cosine -
        window_sine * window_step_sine;
    window_sine = next_window_sine;

    if ((index & 0xFFU) == 0xFFU)
    {
      const float inverse_window_length =
          1.0F /
          sqrtf(window_sine * window_sine +
                window_cosine * window_cosine);

      for (harmonic_order = 1U;
           harmonic_order <= maximum_harmonic_order;
           harmonic_order++)
      {
        const float inverse_tone_length =
            1.0F /
            sqrtf(tone_sine[harmonic_order] *
                      tone_sine[harmonic_order] +
                  tone_cosine[harmonic_order] *
                      tone_cosine[harmonic_order]);

        tone_sine[harmonic_order] *= inverse_tone_length;
        tone_cosine[harmonic_order] *= inverse_tone_length;
      }
      window_sine *= inverse_window_length;
      window_cosine *= inverse_window_length;
    }
  }

  if (window_sum <= 0.0F)
  {
    return false;
  }

  for (harmonic_order = 1U;
       harmonic_order <= maximum_harmonic_order;
       harmonic_order++)
  {
    amplitudes[harmonic_order] =
        2.0F *
        sqrtf(sine_coefficient[harmonic_order] *
                  sine_coefficient[harmonic_order] +
              cosine_coefficient[harmonic_order] *
                  cosine_coefficient[harmonic_order]) /
        window_sum;
    phases_radians[harmonic_order] =
        atan2f(cosine_coefficient[harmonic_order],
               sine_coefficient[harmonic_order]);

    if ((!isfinite(amplitudes[harmonic_order])) ||
        (!isfinite(phases_radians[harmonic_order])))
    {
      return false;
    }
  }

  return true;
}

#if 0
/* Retained as migration evidence only.  Raw square-wave classification is
 * intentionally not part of the generic unknown-waveform analysis path. */
static bool ADC_AnalyzeRawHarmonics(
    float fundamental_frequency_hz,
    float amplitudes[8],
    float signal_to_noise_ratios[8])
{
  const float fft_bin_width_hz =
      SIGNAL_ADC_SAMPLE_RATE_HZ /
      (float)APP_RAW_HARMONIC_FFT_SIZE;
  const float window_angular_step =
      APP_TWO_PI /
      (float)(APP_RAW_HARMONIC_FFT_SIZE - 1U);
  const float window_step_sine =
      sinf(window_angular_step);
  const float window_step_cosine =
      cosf(window_angular_step);
  float mean_code = 0.0F;
  float window_sine = 0.0F;
  float window_cosine = 1.0F;
  float window_sum = 0.0F;
  uint32_t index;
  uint32_t harmonic;

  if ((amplitudes == NULL) ||
      (signal_to_noise_ratios == NULL) ||
      (!isfinite(fundamental_frequency_hz)) ||
      (fundamental_frequency_hz <= 0.0F) ||
      ((7.0F * fundamental_frequency_hz) >=
       APP_RAW_HARMONIC_MAX_TARGET_HZ))
  {
    return false;
  }

  /*
   * One 4096-point FFT replaces nineteen full-block sinusoidal
   * projections.  A Hann window and five-bin root-sum-square estimate
   * retain a tone when its frequency lies between FFT bins.  This keeps
   * the three-capture measurement below the two-second requirement.
   */
  for (index = 0U;
       index < APP_RAW_HARMONIC_FFT_SIZE;
       index++)
  {
    mean_code +=
        (float)adc_sample_buffer[
            ADC_RAW_WARMUP_SAMPLES + index];
  }
  mean_code /= (float)APP_RAW_HARMONIC_FFT_SIZE;

  for (index = 0U;
       index < APP_RAW_HARMONIC_FFT_SIZE;
       index++)
  {
    const float window =
        0.5F - 0.5F * window_cosine;
    const float sample =
        (float)adc_sample_buffer[
            ADC_RAW_WARMUP_SAMPLES + index] -
        mean_code;
    float next_window_sine;

    raw_harmonic_fft_buffer[index] = sample * window;
    window_sum += window;

    next_window_sine =
        window_sine * window_step_cosine +
        window_cosine * window_step_sine;
    window_cosine =
        window_cosine * window_step_cosine -
        window_sine * window_step_sine;
    window_sine = next_window_sine;

    if ((index & 0xFFU) == 0xFFU)
    {
      const float inverse_window_length =
          1.0F /
          sqrtf(window_sine * window_sine +
                window_cosine * window_cosine);

      window_sine *= inverse_window_length;
      window_cosine *= inverse_window_length;
    }
  }

  if (window_sum <= 0.0F)
  {
    return false;
  }

  arm_rfft_fast_f32(&raw_harmonic_fft_instance,
                    raw_harmonic_fft_buffer,
                    filtered_sample_buffer,
                    0U);

  memset(amplitudes, 0, 8U * sizeof(amplitudes[0]));
  memset(signal_to_noise_ratios,
         0,
         8U * sizeof(signal_to_noise_ratios[0]));

  for (harmonic = 1U; harmonic <= 7U; harmonic++)
  {
    const float target_frequency =
        (float)harmonic * fundamental_frequency_hz;
    const int32_t center_bin =
        (int32_t)lrintf(target_frequency /
                        fft_bin_width_hz);
    float target_energy = 0.0F;
    float guard_energy = 0.0F;
    uint32_t guard_count = 0U;
    int32_t offset;

    if ((center_bin <=
         APP_RAW_HARMONIC_GUARD_LAST) ||
        (center_bin >=
         ((int32_t)(APP_RAW_HARMONIC_FFT_SIZE / 2U) -
          APP_RAW_HARMONIC_GUARD_LAST)))
    {
      return false;
    }

    for (offset = -APP_RAW_HARMONIC_TARGET_HALF_WIDTH;
         offset <= APP_RAW_HARMONIC_TARGET_HALF_WIDTH;
         offset++)
    {
      const uint32_t bin =
          (uint32_t)(center_bin + offset);
      const float real_part =
          filtered_sample_buffer[2U * bin];
      const float imaginary_part =
          filtered_sample_buffer[2U * bin + 1U];
      const float magnitude =
          2.0F *
          sqrtf(real_part * real_part +
                imaginary_part * imaginary_part) /
          window_sum;

      target_energy += magnitude * magnitude;
    }

    for (offset = APP_RAW_HARMONIC_GUARD_FIRST;
         offset <= APP_RAW_HARMONIC_GUARD_LAST;
         offset++)
    {
      const uint32_t lower_bin =
          (uint32_t)(center_bin - offset);
      const uint32_t upper_bin =
          (uint32_t)(center_bin + offset);
      const float lower_real =
          filtered_sample_buffer[2U * lower_bin];
      const float lower_imaginary =
          filtered_sample_buffer[2U * lower_bin + 1U];
      const float upper_real =
          filtered_sample_buffer[2U * upper_bin];
      const float upper_imaginary =
          filtered_sample_buffer[2U * upper_bin + 1U];
      const float lower_magnitude =
          2.0F *
          sqrtf(lower_real * lower_real +
                lower_imaginary * lower_imaginary) /
          window_sum;
      const float upper_magnitude =
          2.0F *
          sqrtf(upper_real * upper_real +
                upper_imaginary * upper_imaginary) /
          window_sum;

      guard_energy +=
          lower_magnitude * lower_magnitude +
          upper_magnitude * upper_magnitude;
      guard_count += 2U;
    }

    amplitudes[harmonic] = sqrtf(target_energy);

    {
      float local_noise =
          sqrtf(guard_energy / (float)guard_count);

      if (local_noise < APP_RAW_TONE_NOISE_FLOOR_CODES)
      {
        local_noise = APP_RAW_TONE_NOISE_FLOOR_CODES;
      }

      signal_to_noise_ratios[harmonic] =
          amplitudes[harmonic] / local_noise;
    }

    if ((!isfinite(amplitudes[harmonic])) ||
        (!isfinite(
            signal_to_noise_ratios[harmonic])))
    {
      return false;
    }
  }

  return true;
}
#endif

static bool App_AnalyzeCapturedBlock(signal_fft_result_t *result)
{
  uint32_t input_offset;
  uint32_t output_offset = 0U;

  if (result == NULL)
  {
    return false;
  }

  Signal_Filter_Reset();

  for (input_offset = 0U;
       input_offset < ADC_CAPTURE_COUNT;
       input_offset += SIGNAL_FILTER_INPUT_BLOCK_SIZE)
  {
    ADC_ConvertBlockToInputVoltage(
        input_offset,
        SIGNAL_FILTER_INPUT_BLOCK_SIZE);

    if (!Signal_Filter_ProcessDecimate(
            adc_float_buffer,
            &filtered_sample_buffer[output_offset],
            SIGNAL_FILTER_INPUT_BLOCK_SIZE))
    {
      return false;
    }

    output_offset +=
        SIGNAL_FILTER_INPUT_BLOCK_SIZE /
        SIGNAL_DECIMATION_FACTOR;
  }

  if (output_offset != ADC_DECIMATED_COUNT)
  {
    return false;
  }

  Signal_Filter_RemoveDc(
      &filtered_sample_buffer[ADC_FILTER_WARMUP_SAMPLES],
      SIGNAL_FFT_SIZE);

  return Signal_FFT_Analyze(
      &filtered_sample_buffer[ADC_FILTER_WARMUP_SAMPLES],
      result);
}

static bool App_AccumulateSpectrum(void)
{
  uint32_t spectrum_count;
  uint32_t bin;
  const float *spectrum =
      Signal_FFT_GetSpectrum(&spectrum_count);

  if ((spectrum == NULL) ||
      (spectrum_count != SIGNAL_FFT_SPECTRUM_BIN_COUNT) ||
      (spectrum_accumulation_count >=
       APP_MEASUREMENT_CAPTURE_COUNT))
  {
    return false;
  }

  /*
   * Average power, not display pixels.  Every acquisition has its own
   * 16384-point FFT; incoherent ADC/noise energy falls with the 18-record
   * average while harmonic magnitudes remain unbiased.  The final 1024-point
   * graph is generated only after all records have contributed.
   */
  for (bin = 0U; bin < spectrum_count; bin++)
  {
    spectrum_power_accumulator[bin] +=
        spectrum[bin] * spectrum[bin];
  }

  spectrum_accumulation_count++;
  return true;
}

static bool App_AccumulateCoherentComponents(
    const signal_fft_result_t *result)
{
  float harmonic_amplitudes[
      APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
  float harmonic_phases[
      APP_COHERENT_MAX_HARMONIC_ORDER + 1U];
  float fundamental_amplitude;
  float fundamental_phase;
  float amplitude_threshold;
  uint16_t maximum_harmonic_order;
  uint16_t harmonic_order;

  if ((result == NULL) ||
      (result->peak_count == 0U) ||
      (!isfinite(result->fundamental_frequency_hz)) ||
      (result->fundamental_frequency_hz <= 0.0F))
  {
    return false;
  }

  /*
   * Do not make a weak real harmonic pass the full final-report threshold in
   * every individual record.  Eighteen phase-normalized complex records are
   * averaged later, so incoherent ADC noise is rejected there.  This lower
   * per-record evidence threshold lets a nominal 5 mV component survive a
   * few records affected by front-end attenuation or phase jitter, while the
   * independent 2 mV final coherent-amplitude floor still suppresses spurs.
   */
  amplitude_threshold =
      result->estimated_noise_floor *
      APP_COHERENT_DETECTION_NOISE_MULTIPLIER;
  if (amplitude_threshold <
      APP_COHERENT_DETECTION_MIN_AMPLITUDE_VOLTAGE)
  {
    amplitude_threshold =
        APP_COHERENT_DETECTION_MIN_AMPLITUDE_VOLTAGE;
  }

  maximum_harmonic_order = (uint16_t)floorf(
      (SIGNAL_MAXIMUM_FREQUENCY_HZ +
       2.0F * result->frequency_bin_width_hz) /
      result->fundamental_frequency_hz);
  if (maximum_harmonic_order >
      APP_COHERENT_MAX_HARMONIC_ORDER)
  {
    maximum_harmonic_order =
        APP_COHERENT_MAX_HARMONIC_ORDER;
  }

  if (!App_EstimateFilteredHarmonicBank(
          result->fundamental_frequency_hz,
          maximum_harmonic_order,
          harmonic_amplitudes,
          harmonic_phases))
  {
    return false;
  }

  fundamental_amplitude = harmonic_amplitudes[1U];
  fundamental_phase = harmonic_phases[1U];
  if (fundamental_amplitude <
      APP_RAW_COMPONENT_MIN_AMPLITUDE_VOLTAGE)
  {
    return false;
  }

  /*
   * Project every allowed integer harmonic from the complete filtered
   * record, not only peaks found by the generic local-maximum detector.
   * For x_m=A_m*sin(m*w0*t+phi_m), remove the unrelated acquisition phase
   * by accumulating phi_m-m*phi_1.
   */
  for (harmonic_order = 1U;
       harmonic_order <= maximum_harmonic_order;
       harmonic_order++)
  {
    float amplitude;
    float phase;
    float relative_phase;

    amplitude = harmonic_amplitudes[harmonic_order];
    phase = harmonic_phases[harmonic_order];

    relative_phase =
        phase -
        (float)harmonic_order * fundamental_phase;

    coherent_harmonic_sine_sum[harmonic_order] +=
        amplitude * cosf(relative_phase);
    coherent_harmonic_cosine_sum[harmonic_order] +=
        amplitude * sinf(relative_phase);
    coherent_harmonic_amplitude_sum[harmonic_order] +=
        amplitude;

    if (coherent_harmonic_capture_count[harmonic_order] <
        APP_MEASUREMENT_CAPTURE_COUNT)
    {
      coherent_harmonic_capture_count[harmonic_order]++;
    }

    /*
     * Every valid complex projection participates in the final average.
     * The threshold is only a per-record presence vote; discarding the whole
     * phasor here biased weak harmonics upward and could leave them with fewer
     * than the required majority of records.
     */
    if ((harmonic_order == 1U) ||
        (amplitude >= amplitude_threshold))
    {
      if (coherent_harmonic_evidence_count[harmonic_order] <
          APP_MEASUREMENT_CAPTURE_COUNT)
      {
        coherent_harmonic_evidence_count[harmonic_order]++;
      }
    }
  }

  return coherent_harmonic_capture_count[1U] > 0U;
}

static float App_GetFrontendAmplitudeCorrection(
    float frequency_hz)
{
  /*
   * Command '9' supplies the current board-level scalar gain.  The previous
   * frequency-response anchors belonged to an older calibration/wiring state
   * and introduced up to +8.47% low-frequency error after recalibration.
   * Keep the response flat until a new multi-frequency characterization is
   * explicitly measured; do not invent or interpolate an unverified table.
   */
  (void)frequency_hz;
  return 1.0F;
}

static bool App_UpdateFrontendCalibration(
    const signal_fft_result_t *result)
{
  float mean_code = 0.0F;
  float amplitude_code;
  float second_harmonic_code;
  float third_harmonic_code;
  float phase_radians;
  float harmonic_phase;
  float calibrated_bias;
  float calibrated_gain;
  uint32_t index;

  if ((result == NULL) ||
      (result->peak_count == 0U) ||
      (!isfinite(result->fundamental_frequency_hz)) ||
      (result->fundamental_frequency_hz <
       SIGNAL_MINIMUM_FREQUENCY_HZ) ||
      (result->fundamental_frequency_hz >
       SIGNAL_MAXIMUM_FREQUENCY_HZ) ||
      (fabsf(result->fundamental_frequency_hz -
             ADC_CALIBRATION_FREQUENCY_HZ) >
       ADC_CALIBRATION_FREQUENCY_TOLERANCE_HZ))
  {
    return false;
  }

  for (index = ADC_RAW_WARMUP_SAMPLES;
       index < ADC_CAPTURE_COUNT;
       index++)
  {
    mean_code += (float)adc_sample_buffer[index];
  }

  mean_code /=
      (float)(ADC_CAPTURE_COUNT - ADC_RAW_WARMUP_SAMPLES);

  if (!ADC_EstimateRawTone(
          result->fundamental_frequency_hz,
          mean_code,
          &amplitude_code,
          &phase_radians) ||
      !ADC_EstimateRawTone(
          2.0F * result->fundamental_frequency_hz,
          mean_code,
          &second_harmonic_code,
          &harmonic_phase) ||
      !ADC_EstimateRawTone(
          3.0F * result->fundamental_frequency_hz,
          mean_code,
          &third_harmonic_code,
          &harmonic_phase) ||
      (amplitude_code < 16.0F) ||
      (second_harmonic_code > (0.05F * amplitude_code)) ||
      (third_harmonic_code > (0.05F * amplitude_code)))
  {
    return false;
  }

  (void)phase_radians;

  calibrated_gain =
      2.0F * amplitude_code * adc_reference_voltage /
      (ADC_FULL_SCALE_CODE * ADC_CALIBRATION_REFERENCE_VPP);
  calibrated_bias =
      mean_code * adc_reference_voltage /
          ADC_FULL_SCALE_CODE -
      calibrated_gain *
          ADC_CALIBRATION_REFERENCE_DC_OFFSET;

  if ((!isfinite(calibrated_bias)) ||
      (!isfinite(calibrated_gain)) ||
      (calibrated_bias <= 0.05F) ||
      (calibrated_bias >= (adc_reference_voltage - 0.05F)) ||
      (calibrated_gain < 0.10F) ||
      (calibrated_gain > 10.0F))
  {
    return false;
  }

  adc_dc_bias_voltage = calibrated_bias;
  adc_frontend_gain = calibrated_gain;
  return true;
}

static void App_SortFloatAscending(float *values,
                                   uint8_t count)
{
  uint8_t index;

  if (values == NULL)
  {
    return;
  }

  for (index = 1U; index < count; index++)
  {
    const float value = values[index];
    uint8_t position = index;

    while ((position > 0U) &&
           (values[position - 1U] > value))
    {
      values[position] = values[position - 1U];
      position--;
    }

    values[position] = value;
  }
}

static bool App_CollectFrontendCalibration(
    const signal_fft_result_t *result)
{
  const float previous_gain = adc_frontend_gain;
  const float previous_bias = adc_dc_bias_voltage;
  float sorted_gains[APP_CALIBRATION_CAPTURE_COUNT];
  float sorted_biases[APP_CALIBRATION_CAPTURE_COUNT];
  float calibrated_gain;
  float calibrated_bias;
  float gain_sum = 0.0F;
  float bias_sum = 0.0F;
  const uint8_t retained_count =
      APP_CALIBRATION_CAPTURE_COUNT -
      2U * APP_CALIBRATION_TRIM_COUNT;
  uint8_t capture;

  if ((calibration_capture_count >=
       APP_CALIBRATION_CAPTURE_COUNT) ||
      !App_UpdateFrontendCalibration(result))
  {
    adc_frontend_gain = previous_gain;
    adc_dc_bias_voltage = previous_bias;
    return false;
  }

  calibration_gain_candidates[calibration_capture_count] =
      adc_frontend_gain;
  calibration_bias_candidates[calibration_capture_count] =
      adc_dc_bias_voltage;
  calibration_capture_count++;

  /* A candidate is not made live until all eighteen independent captures pass.
   * This also ensures every calibration frame is analysed on the same scale. */
  adc_frontend_gain = previous_gain;
  adc_dc_bias_voltage = previous_bias;

  if (calibration_capture_count <
      APP_CALIBRATION_CAPTURE_COUNT)
  {
    return true;
  }

  memcpy(sorted_gains,
         calibration_gain_candidates,
         sizeof(sorted_gains));
  memcpy(sorted_biases,
         calibration_bias_candidates,
         sizeof(sorted_biases));
  App_SortFloatAscending(sorted_gains,
                         APP_CALIBRATION_CAPTURE_COUNT);
  App_SortFloatAscending(sorted_biases,
                         APP_CALIBRATION_CAPTURE_COUNT);

  for (capture = APP_CALIBRATION_TRIM_COUNT;
       capture <
           (APP_CALIBRATION_CAPTURE_COUNT -
            APP_CALIBRATION_TRIM_COUNT);
       capture++)
  {
    gain_sum += sorted_gains[capture];
    bias_sum += sorted_biases[capture];
  }

  calibrated_gain = gain_sum / (float)retained_count;
  calibrated_bias = bias_sum / (float)retained_count;

  /* Reject an unstable generator/cable rather than saving an inaccurate but
   * superficially valid pair. */
  if (((sorted_gains[APP_CALIBRATION_CAPTURE_COUNT -
                     APP_CALIBRATION_TRIM_COUNT - 1U] -
        sorted_gains[APP_CALIBRATION_TRIM_COUNT]) >
       (APP_CALIBRATION_MAX_GAIN_SPAN_RATIO * calibrated_gain)) ||
      ((sorted_biases[APP_CALIBRATION_CAPTURE_COUNT -
                      APP_CALIBRATION_TRIM_COUNT - 1U] -
        sorted_biases[APP_CALIBRATION_TRIM_COUNT]) >
       APP_CALIBRATION_MAX_BIAS_SPAN_VOLTAGE))
  {
    return false;
  }

  adc_frontend_gain = calibrated_gain;
  adc_dc_bias_voltage = calibrated_bias;
  return true;
}

#if 0
/* Waveform-specific raw harmonic reconstruction is intentionally disabled.
 * The H743 path analyses unknown waveforms generically after the specified
 * anti-alias filtering rather than classifying them as square waves. */
static void App_ConfirmSquareWave(signal_fft_result_t *result)
{
  float amplitudes[8];
  float signal_to_noise_ratios[8];
  float ratio_3;
  float ratio_5;
  float ratio_7;
  float even_energy_ratio;
  float odd_energy_ratio;

  if ((result == NULL) ||
      (result->fundamental_frequency_hz <= 0.0F))
  {
    return;
  }

  /*
   * The 6.000 MSPS analysis stream retains every ADC sample while its
   * linear-phase FIR rejects content outside the requested measurement
   * band. Confirm square-wave evidence from the unfiltered 6.00 MSPS block;
   * use the seventh harmonic only when it remains below the raw Nyquist
   * limit and can distinguish a real square wave from a finite A1+A3+A5
   * input.
   *
   * Do not require high-order phase alignment here. The measured analog
   * front end has appreciable magnitude and phase roll-off above 1 MHz.
   * Odd-harmonic ratios, monotonic decay and a bounded even harmonic give
   * a robust decision without discarding the real high-frequency square.
   */
  result->square_wave_detected = 0U;

  if ((7.0F * result->fundamental_frequency_hz) >=
      APP_RAW_HARMONIC_MAX_TARGET_HZ)
  {
    return;
  }

  if ((!ADC_AnalyzeRawHarmonics(
           result->fundamental_frequency_hz,
           amplitudes,
           signal_to_noise_ratios)) ||
      (amplitudes[1] <
       APP_SQUARE_RAW_MIN_FUNDAMENTAL_CODES))
  {
    return;
  }

  ratio_3 = amplitudes[3] / amplitudes[1];
  ratio_5 = amplitudes[5] / amplitudes[1];
  ratio_7 = amplitudes[7] / amplitudes[1];
  even_energy_ratio =
      sqrtf(amplitudes[2] * amplitudes[2] +
            amplitudes[4] * amplitudes[4] +
            amplitudes[6] * amplitudes[6]) /
      amplitudes[1];
  odd_energy_ratio =
      sqrtf(amplitudes[3] * amplitudes[3] +
            amplitudes[5] * amplitudes[5] +
            amplitudes[7] * amplitudes[7]) /
      amplitudes[1];

  if ((even_energy_ratio > APP_SQUARE_RAW_EVEN_ENERGY_MAX) ||
      (odd_energy_ratio < APP_SQUARE_RAW_ODD_ENERGY_MIN) ||
      (signal_to_noise_ratios[3] <
       APP_SQUARE_HARMONIC_SNR_MIN) ||
      (signal_to_noise_ratios[5] <
       APP_SQUARE_HARMONIC_SNR_MIN) ||
      (signal_to_noise_ratios[7] <
       APP_SQUARE_HARMONIC_SNR_MIN) ||
      (ratio_3 < APP_SQUARE_RAW_3_RATIO_MIN) ||
      (ratio_3 > APP_SQUARE_RAW_3_RATIO_MAX) ||
      (ratio_5 < APP_SQUARE_RAW_5_RATIO_MIN) ||
      (ratio_5 > APP_SQUARE_RAW_5_RATIO_MAX) ||
      (ratio_7 < APP_SQUARE_RAW_7_RATIO_MIN) ||
      (ratio_7 > APP_SQUARE_RAW_7_RATIO_MAX) ||
      (amplitudes[7] < APP_SQUARE_RAW_MIN_7TH_CODES))
  {
    return;
  }

  result->square_wave_detected = 1U;
}

static bool App_BuildSeparatedWaveComponents(
    signal_fft_result_t *result)
{
  float absolute_phases[
      APP_RAW_WAVE_MAX_COMPONENTS];
  float mean_code = 0.0F;
  float fundamental_phase = 0.0F;
  float minimum_voltage = FLT_MAX;
  float maximum_voltage = -FLT_MAX;
  float sum_of_squares = 0.0F;
  uint32_t index;
  uint8_t component;

  if ((result == NULL) ||
      (result->peak_count == 0U) ||
      (!isfinite(result->fundamental_frequency_hz)) ||
      (result->fundamental_frequency_hz <= 0.0F))
  {
    return false;
  }

  memset(raw_wave_components,
         0,
         sizeof(raw_wave_components));
  raw_wave_component_count = 0U;

  if (result->square_wave_detected != 0U)
  {
    float harmonic_fft_amplitudes[8];
    float harmonic_signal_to_noise_ratios[8];
    uint8_t harmonic;

    if (!ADC_AnalyzeRawHarmonics(
            result->fundamental_frequency_hz,
            harmonic_fft_amplitudes,
            harmonic_signal_to_noise_ratios))
    {
      return false;
    }

    for (index = ADC_RAW_WARMUP_SAMPLES;
         index < ADC_CAPTURE_COUNT;
         index++)
    {
      mean_code += (float)adc_sample_buffer[index];
    }
    mean_code /=
        (float)(ADC_CAPTURE_COUNT -
                ADC_RAW_WARMUP_SAMPLES);

    /*
     * A high-frequency square wave has useful components above the
     * 600 kHz analysis band.  Extract every measurable 1st...7th component
     * from the real 7.20 MSPS ADC block; no ideal-square amplitudes or phases
     * are inserted.
     */
    for (harmonic = 1U;
         harmonic <= APP_RAW_WAVE_MAX_COMPONENTS;
         harmonic++)
    {
      const float frequency_hz =
          (float)harmonic *
          result->fundamental_frequency_hz;
      float amplitude_code;
      float amplitude_voltage;
      float phase_radians;

      if (frequency_hz >=
          APP_RAW_HARMONIC_MAX_TARGET_HZ)
      {
        break;
      }

      if (!ADC_EstimateRawTone(frequency_hz,
                               mean_code,
                               &amplitude_code,
                               &phase_radians))
      {
        raw_wave_component_count = 0U;
        return false;
      }

      amplitude_voltage =
          amplitude_code * adc_reference_voltage /
          (ADC_FULL_SCALE_CODE * adc_frontend_gain);

      /*
       * Do not turn raw ADC noise into a displayed harmonic.  The
       * fundamental is always retained; every following component must pass
       * both the local FFT SNR test and the 1 mV amplitude floor.  Returning
       * zero for anything below 1 mV remains safely inside the required
       * +/-5 mV component-amplitude error.
       */
      if ((harmonic > 1U) &&
          ((harmonic_signal_to_noise_ratios[harmonic] <
            APP_SQUARE_HARMONIC_SNR_MIN) ||
           (amplitude_voltage <
            APP_RAW_COMPONENT_MIN_AMPLITUDE_VOLTAGE)))
      {
        continue;
      }

      raw_wave_components[
          raw_wave_component_count].harmonic_order =
          harmonic;
      raw_wave_components[
          raw_wave_component_count].frequency_ratio =
          (float)harmonic;
      raw_wave_components[
          raw_wave_component_count].amplitude_peak =
          amplitude_voltage;
      absolute_phases[raw_wave_component_count] =
          phase_radians;
      raw_wave_component_count++;
    }
  }
  else
  {
    /*
     * General periodic or mixed input: copy every component separated by
     * the main FFT.  Use the measured frequency ratio rather than forcing
     * an integer harmonic, so irregular but repeatable inputs keep their
     * real phase evolution.
     */
    for (component = 0U;
         (component < result->peak_count) &&
         (component < APP_RAW_WAVE_MAX_COMPONENTS);
         component++)
    {
      const signal_fft_peak_t *peak =
          &result->peaks[component];

      raw_wave_components[
          raw_wave_component_count].harmonic_order =
          (uint8_t)peak->harmonic_order;
      raw_wave_components[
          raw_wave_component_count].frequency_ratio =
          peak->frequency_hz /
          result->fundamental_frequency_hz;
      raw_wave_components[
          raw_wave_component_count].amplitude_peak =
          peak->amplitude_peak;
      absolute_phases[raw_wave_component_count] =
          peak->phase_radians;
      raw_wave_component_count++;
    }
  }

  if ((raw_wave_component_count == 0U) ||
      (!isfinite(
          raw_wave_components[0].amplitude_peak)) ||
      (raw_wave_components[0].amplitude_peak <= 0.0F))
  {
    raw_wave_component_count = 0U;
    return false;
  }

  /*
   * Peaks are frequency-sorted.  Prefer the component nearest the measured
   * fundamental as the phase reference, without assuming it is index zero.
   */
  {
    float smallest_ratio_error = FLT_MAX;

    for (component = 0U;
         component < raw_wave_component_count;
         component++)
    {
      const float ratio_error =
          fabsf(raw_wave_components[component]
                    .frequency_ratio -
                1.0F);

      if (ratio_error < smallest_ratio_error)
      {
        smallest_ratio_error = ratio_error;
        fundamental_phase =
            absolute_phases[component] /
            raw_wave_components[component]
                .frequency_ratio;
      }
    }
  }

  for (component = 0U;
       component < raw_wave_component_count;
       component++)
  {
    float relative_phase =
        absolute_phases[component] -
        raw_wave_components[component]
            .frequency_ratio *
        fundamental_phase;

    while (relative_phase > (0.5F * APP_TWO_PI))
    {
      relative_phase -= APP_TWO_PI;
    }

    while (relative_phase < (-0.5F * APP_TWO_PI))
    {
      relative_phase += APP_TWO_PI;
    }

    raw_wave_components[component]
        .relative_phase_radians =
        relative_phase;
  }

  /*
   * Numerically integrate one reconstructed period.  RMS and Vpp therefore
   * come from the same separated amplitudes/phases that are sent to the
   * display; no sine or ideal-square voltage formula is used.
   */
  for (index = 0U;
       index < APP_RAW_WAVE_METRIC_POINTS;
       index++)
  {
    const float base_phase =
        APP_TWO_PI * (float)index /
        (float)APP_RAW_WAVE_METRIC_POINTS;
    float voltage = 0.0F;

    for (component = 0U;
         component < raw_wave_component_count;
         component++)
    {
      voltage +=
          raw_wave_components[component]
              .amplitude_peak *
          sinf(raw_wave_components[component]
                       .frequency_ratio *
                   base_phase +
               raw_wave_components[component]
                   .relative_phase_radians);
    }

    if (voltage < minimum_voltage)
    {
      minimum_voltage = voltage;
    }

    if (voltage > maximum_voltage)
    {
      maximum_voltage = voltage;
    }

    sum_of_squares += voltage * voltage;
  }

  /* The folded waveform supplies the displayed shape and a fallback Vpp.
   * The published scalar follows the requested eighteen-record statistic:
   * remove the four largest and four smallest independent Vpp values, then
   * average the middle ten. */
  result->voltage_peak_to_peak =
      (isfinite(measurement_trimmed_vpp) &&
       (measurement_trimmed_vpp > 0.0F)) ?
          measurement_trimmed_vpp :
          (maximum_voltage - minimum_voltage);
  result->voltage_rms =
      sqrtf(sum_of_squares /
            (float)APP_RAW_WAVE_METRIC_POINTS);

  return isfinite(result->voltage_peak_to_peak) &&
         isfinite(result->voltage_rms);
}

#endif

static bool App_BuildSeparatedWaveComponents(
    signal_fft_result_t *result)
{
  uint16_t harmonic_order;

  if ((result == NULL) ||
      (result->peak_count == 0U) ||
      (!isfinite(result->fundamental_frequency_hz)) ||
      (result->fundamental_frequency_hz <= 0.0F))
  {
    return false;
  }

  memset(raw_wave_components, 0, sizeof(raw_wave_components));
  raw_wave_component_count = 0U;

  /*
   * Convert the eighteen phase-normalized complex accumulators into real
   * Fourier components.  The fundamental is mandatory in all 18 records. Every
   * valid projection contributes to the complex mean, while a higher harmonic
   * needs above-threshold evidence in at least five records.  The majority
   * vote, phase-coherence test and final 2 mV floor reject noise without
   * discarding useful low-amplitude phasors before averaging.
   */
  for (harmonic_order = 1U;
       harmonic_order <= APP_COHERENT_MAX_HARMONIC_ORDER;
       harmonic_order++)
  {
    const uint8_t capture_count =
        coherent_harmonic_capture_count[harmonic_order];
    const uint8_t evidence_count =
        coherent_harmonic_evidence_count[harmonic_order];
    float sine_coefficient;
    float cosine_coefficient;
    float amplitude;
    float coherent_amplitude;
    float mean_observed_amplitude;
    float phase_coherence;
    uint8_t destination;

    if (((harmonic_order == 1U) &&
         (capture_count != APP_MEASUREMENT_CAPTURE_COUNT)) ||
        ((harmonic_order > 1U) &&
         ((capture_count != APP_MEASUREMENT_CAPTURE_COUNT) ||
          (evidence_count < APP_COHERENT_MIN_CAPTURE_COUNT))) ||
        (((float)harmonic_order *
          result->fundamental_frequency_hz) >
         (SIGNAL_MAXIMUM_FREQUENCY_HZ +
          2.0F * result->frequency_bin_width_hz)))
    {
      continue;
    }

    sine_coefficient =
        coherent_harmonic_sine_sum[harmonic_order] /
        (float)capture_count;
    cosine_coefficient =
        coherent_harmonic_cosine_sum[harmonic_order] /
        (float)capture_count;
    coherent_amplitude = sqrtf(
        sine_coefficient * sine_coefficient +
        cosine_coefficient * cosine_coefficient);
    mean_observed_amplitude =
        coherent_harmonic_amplitude_sum[harmonic_order] /
        (float)capture_count;
    phase_coherence =
        (mean_observed_amplitude > 1.0e-12F) ?
            (coherent_amplitude /
             mean_observed_amplitude) : 0.0F;
    /* Report the coherent complex mean.  Averaging scalar magnitudes creates
     * a deterministic positive (Rician) bias for weak harmonics because noise
     * magnitude cannot cancel.  The complex mean cancels incoherent noise and
     * uses the same phase reference as the coherence decision. */
    amplitude = coherent_amplitude;
    amplitude *= App_GetFrontendAmplitudeCorrection(
        (float)harmonic_order *
        result->fundamental_frequency_hz);

    if ((!isfinite(amplitude)) ||
        (!isfinite(phase_coherence)) ||
        (amplitude < APP_RAW_COMPONENT_MIN_AMPLITUDE_VOLTAGE) ||
        ((harmonic_order > 1U) &&
         ((amplitude <
           APP_REPORTABLE_COMPONENT_MIN_AMPLITUDE_VOLTAGE) ||
          (phase_coherence <
           APP_COHERENT_MIN_PHASE_COHERENCE))))
    {
      continue;
    }

    if (raw_wave_component_count <
        APP_MAX_SEPARATED_COMPONENTS)
    {
      destination = raw_wave_component_count;
      raw_wave_component_count++;
    }
    else
    {
      uint8_t weakest = 1U;
      uint8_t component;

      /*
       * Slot zero is the fundamental and is never replaced.  The official
       * input contains at most two harmonics, so retain the two strongest
       * repeatable higher components.  Other measured bins remain visible
       * in the qualitative spectrum but cannot displace the required
       * quantitative harmonic fields with low-level ADC/front-end spurs.
       */
      for (component = 2U;
           component < raw_wave_component_count;
           component++)
      {
        if (raw_wave_components[component].amplitude_peak <
            raw_wave_components[weakest].amplitude_peak)
        {
          weakest = component;
        }
      }

      if (amplitude <=
          raw_wave_components[weakest].amplitude_peak)
      {
        continue;
      }

      destination = weakest;
    }

    raw_wave_components[destination].harmonic_order =
        (uint8_t)harmonic_order;
    raw_wave_components[destination].frequency_ratio =
        (float)harmonic_order;
    raw_wave_components[destination].amplitude_peak =
        amplitude;
    raw_wave_components[destination].relative_phase_radians =
        atan2f(cosine_coefficient, sine_coefficient);
  }

  /*
   * Keep the public component order deterministic: fundamental first, then
   * increasing harmonic order.  This also makes x4/x5 and x6/x7 report the
   * first two real harmonics rather than whichever amplitude was strongest.
   */
  {
    uint8_t first;

    for (first = 0U; first < raw_wave_component_count; first++)
    {
      uint8_t second;

      for (second = (uint8_t)(first + 1U);
           second < raw_wave_component_count;
           second++)
      {
        if (raw_wave_components[second].harmonic_order <
            raw_wave_components[first].harmonic_order)
        {
          app_raw_wave_component_t temporary =
              raw_wave_components[first];
          raw_wave_components[first] =
              raw_wave_components[second];
          raw_wave_components[second] = temporary;
        }
      }
    }
  }

  return (raw_wave_component_count > 0U) &&
         (raw_wave_components[0].harmonic_order == 1U);
}

static bool App_CalculateSeparatedVoltageMetrics(
    signal_fft_result_t *result)
{
  float minimum_voltage = FLT_MAX;
  float maximum_voltage = -FLT_MAX;
  float mean_square = 0.0F;
  float oscillator_sine[APP_MAX_SEPARATED_COMPONENTS];
  float oscillator_cosine[APP_MAX_SEPARATED_COMPONENTS];
  float step_sine[APP_MAX_SEPARATED_COMPONENTS];
  float step_cosine[APP_MAX_SEPARATED_COMPONENTS];
  uint32_t point;
  uint8_t component;

  if ((result == NULL) ||
      (raw_wave_component_count == 0U) ||
      (raw_wave_components[0].harmonic_order != 1U))
  {
    return false;
  }

  /*
   * The official input has no DC component and consists of a fundamental
   * plus at most two integer harmonics.  Distinct integer harmonics are
   * orthogonal over one complete fundamental period, therefore the exact
   * true-RMS definition reduces to:
   *
   *              Vrms = sqrt(0.5 * sum(A_m^2)).
   *
   * This is not a sine-only shortcut: every separated component contributes
   * its measured peak amplitude.  Relative phase affects Vpp but correctly
   * cancels from RMS.
   */
  for (component = 0U;
       component < raw_wave_component_count;
       component++)
  {
    const float amplitude =
        raw_wave_components[component].amplitude_peak;

    if ((!isfinite(amplitude)) || (amplitude < 0.0F))
    {
      return false;
    }

    mean_square += 0.5F * amplitude * amplitude;
    oscillator_sine[component] = sinf(
        raw_wave_components[component].relative_phase_radians);
    oscillator_cosine[component] = cosf(
        raw_wave_components[component].relative_phase_radians);
    step_sine[component] = sinf(
        APP_TWO_PI *
        (float)raw_wave_components[component].harmonic_order /
        (float)APP_RAW_WAVE_METRIC_POINTS);
    step_cosine[component] = cosf(
        APP_TWO_PI *
        (float)raw_wave_components[component].harmonic_order /
        (float)APP_RAW_WAVE_METRIC_POINTS);
  }

  /*
   * Peak-to-peak is defined on the complete reconstructed input period, not
   * as twice the largest FFT line and not as the noisiest pair of ADC
   * samples.  32768 phase points bound the numerical peak error far below
   * the 5 mV judging tolerance even at the highest legal harmonic order.
   */
  for (point = 0U;
       point < APP_RAW_WAVE_METRIC_POINTS;
       point++)
  {
    float voltage = 0.0F;

    for (component = 0U;
         component < raw_wave_component_count;
         component++)
    {
      float next_sine;

      voltage += raw_wave_components[component].amplitude_peak *
                 oscillator_sine[component];
      next_sine =
          oscillator_sine[component] * step_cosine[component] +
          oscillator_cosine[component] * step_sine[component];
      oscillator_cosine[component] =
          oscillator_cosine[component] * step_cosine[component] -
          oscillator_sine[component] * step_sine[component];
      oscillator_sine[component] = next_sine;

      if ((point & 0xFFU) == 0xFFU)
      {
        const float inverse_length = 1.0F / sqrtf(
            oscillator_sine[component] *
                oscillator_sine[component] +
            oscillator_cosine[component] *
                oscillator_cosine[component]);

        oscillator_sine[component] *= inverse_length;
        oscillator_cosine[component] *= inverse_length;
      }
    }

    if (voltage < minimum_voltage)
    {
      minimum_voltage = voltage;
    }

    if (voltage > maximum_voltage)
    {
      maximum_voltage = voltage;
    }
  }

  /* The public Vpp is the robust statistic from eighteen independent
   * spectral reconstructions: discard four high and four low estimates and
   * average the middle ten.  Do not overwrite it with this single aggregate
   * reconstruction. */
  if ((!isfinite(measurement_trimmed_vpp)) ||
      (measurement_trimmed_vpp <= 0.0F))
  {
    return false;
  }
  result->voltage_peak_to_peak = measurement_trimmed_vpp;
  result->voltage_rms = sqrtf(mean_square);

  return isfinite(result->voltage_peak_to_peak) &&
         isfinite(result->voltage_rms);
}

static bool App_CalculateCaptureSpectralVpp(
    signal_fft_result_t *result)
{
  float minimum_voltage = FLT_MAX;
  float maximum_voltage = -FLT_MAX;
  float component_amplitude[SIGNAL_FFT_MAX_PEAKS];
  float oscillator_sine[SIGNAL_FFT_MAX_PEAKS];
  float oscillator_cosine[SIGNAL_FFT_MAX_PEAKS];
  float step_sine[SIGNAL_FFT_MAX_PEAKS];
  float step_cosine[SIGNAL_FFT_MAX_PEAKS];
  uint8_t component_count = 0U;
  uint32_t point;
  uint8_t peak;

  if ((result == NULL) ||
      (result->peak_count == 0U) ||
      (!isfinite(result->fundamental_frequency_hz)) ||
      (result->fundamental_frequency_hz <= 0.0F))
  {
    return false;
  }

  /* Prepare one oscillator per valid fitted component.  The former nested
   * implementation evaluated sinf() for every component at every one of the
   * 8192 phase points.  This recurrence is mathematically equivalent, with a
   * periodic unit-length normalization to bound floating-point drift. */
  for (peak = 0U; peak < result->peak_count; peak++)
  {
    const signal_fft_peak_t *component = &result->peaks[peak];
    const float correction =
        App_GetFrontendAmplitudeCorrection(component->frequency_hz);
    float angular_step;

    if ((component->harmonic_order == 0U) ||
        (!isfinite(component->amplitude_peak)) ||
        (!isfinite(component->phase_radians)) ||
        (!isfinite(correction)) ||
        (correction <= 0.0F))
    {
      continue;
    }

    angular_step =
        APP_TWO_PI * (float)component->harmonic_order /
        (float)APP_CAPTURE_VPP_PHASE_POINTS;
    component_amplitude[component_count] =
        component->amplitude_peak * correction;
    oscillator_sine[component_count] =
        sinf(component->phase_radians);
    oscillator_cosine[component_count] =
        cosf(component->phase_radians);
    step_sine[component_count] = sinf(angular_step);
    step_cosine[component_count] = cosf(angular_step);
    component_count++;
  }

  if (component_count == 0U)
  {
    return false;
  }

  /* Calculate one independent Vpp estimate from the fitted spectral
   * components of this capture. Unlike a raw max-min pair, this estimate is
   * not biased upward by two isolated ADC/noise samples. Absolute acquisition
   * phase cancels from Vpp; the fitted inter-component phase is retained. */
  for (point = 0U;
       point < APP_CAPTURE_VPP_PHASE_POINTS;
       point++)
  {
    float voltage = 0.0F;

    for (peak = 0U; peak < component_count; peak++)
    {
      float next_sine;

      voltage += component_amplitude[peak] * oscillator_sine[peak];
      next_sine = oscillator_sine[peak] * step_cosine[peak] +
                  oscillator_cosine[peak] * step_sine[peak];
      oscillator_cosine[peak] =
          oscillator_cosine[peak] * step_cosine[peak] -
          oscillator_sine[peak] * step_sine[peak];
      oscillator_sine[peak] = next_sine;

      if ((point & 0xFFU) == 0xFFU)
      {
        const float inverse_length = 1.0F / sqrtf(
            oscillator_sine[peak] * oscillator_sine[peak] +
            oscillator_cosine[peak] * oscillator_cosine[peak]);

        oscillator_sine[peak] *= inverse_length;
        oscillator_cosine[peak] *= inverse_length;
      }
    }

    if (voltage < minimum_voltage)
    {
      minimum_voltage = voltage;
    }
    if (voltage > maximum_voltage)
    {
      maximum_voltage = voltage;
    }
  }

  if ((!isfinite(minimum_voltage)) ||
      (!isfinite(maximum_voltage)) ||
      (maximum_voltage < minimum_voltage))
  {
    return false;
  }

  result->voltage_peak_to_peak =
      maximum_voltage - minimum_voltage;
  return isfinite(result->voltage_peak_to_peak);
}

static bool App_FinalizeMeasurementResults(void)
{
  uint8_t valid_count = 0U;
  uint8_t reference_index = 0U;
  uint8_t capture;
  float input_mean_sum = 0.0F;
  float input_rms_energy_sum = 0.0F;
  float voltage_rms_energy_sum = 0.0F;
  float fundamental_frequency_sum = 0.0F;
  float noise_floor_sum = 0.0F;
  float frequency_reference = 0.0F;
  float vpp_candidates[APP_MEASUREMENT_CAPTURE_COUNT];
  float retained_vpp_sum = 0.0F;

  for (capture = 0U;
       capture < measurement_capture_count;
       capture++)
  {
    const signal_fft_result_t *result =
        &measurement_results[capture];

    if (result->peak_count == 0U)
    {
      continue;
    }

    if (valid_count == 0U)
    {
      frequency_reference =
          result->fundamental_frequency_hz;
    }
    else if (fabsf(result->fundamental_frequency_hz -
                   frequency_reference) >
             APP_CAPTURE_FREQUENCY_CONSISTENCY_HZ)
    {
      return false;
    }

    reference_index = capture;
    vpp_candidates[valid_count] =
        result->voltage_peak_to_peak;
    valid_count++;
    input_mean_sum += result->input_mean;
    input_rms_energy_sum +=
        result->input_rms * result->input_rms;
    voltage_rms_energy_sum +=
        result->voltage_rms * result->voltage_rms;
    fundamental_frequency_sum +=
        result->fundamental_frequency_hz;
    noise_floor_sum += result->estimated_noise_floor;

  }

  /* Eighteen independent captures are requested. Require every record before
   * publishing so scalar values, spectrum power and folded time wave always
   * describe the same complete measurement. */
  if ((valid_count < APP_MEASUREMENT_CAPTURE_COUNT) ||
      (measurement_capture_count <
       APP_MEASUREMENT_CAPTURE_COUNT))
  {
    return false;
  }

  App_SortFloatAscending(vpp_candidates, valid_count);
  for (capture = APP_MEASUREMENT_TRIM_COUNT;
       capture <
           (valid_count - APP_MEASUREMENT_TRIM_COUNT);
       capture++)
  {
    retained_vpp_sum += vpp_candidates[capture];
  }
  measurement_trimmed_vpp =
      retained_vpp_sum /
      (float)(valid_count - 2U * APP_MEASUREMENT_TRIM_COUNT);

  latest_fft_result =
      measurement_results[reference_index];
  latest_fft_result.input_mean =
      input_mean_sum / (float)valid_count;
  latest_fft_result.input_peak_to_peak =
      measurement_trimmed_vpp;
  latest_fft_result.input_rms =
      sqrtf(input_rms_energy_sum / (float)valid_count);
  latest_fft_result.voltage_peak_to_peak =
      measurement_trimmed_vpp;
  latest_fft_result.voltage_rms =
      sqrtf(voltage_rms_energy_sum / (float)valid_count);
  latest_fft_result.fundamental_frequency_hz =
      fundamental_frequency_sum / (float)valid_count;
  latest_fft_result.estimated_noise_floor =
      noise_floor_sum / (float)valid_count;

  /* Keep all actual spectral components and their phase from one complete
   * capture.  Cross-capture joining by an inferred harmonic number would
   * merge unrelated peaks in an arbitrary waveform and corrupt command 1/3. */
  latest_fft_result.square_wave_detected = 0U;

  return true;
}

static void App_SetMeasurementUnavailable(void)
{
  calibration_result_output_pending = 0U;
  calibration_measurement_active = 0U;
  measurement_capture_count = 0U;
  memset(&fft_work_result, 0, sizeof(fft_work_result));
  memset(measurement_results, 0, sizeof(measurement_results));
  memset(&latest_fft_result, 0, sizeof(latest_fft_result));
  memset(spectrum_power_accumulator,
         0,
         sizeof(spectrum_power_accumulator));
  spectrum_accumulation_count = 0U;
  memset(saved_one_period_wave, 0, sizeof(saved_one_period_wave));
  memset(saved_three_period_wave, 0, sizeof(saved_three_period_wave));
  memset(saved_spectrum_graph, 0, sizeof(saved_spectrum_graph));
  memset(hmi_work_buffer, 0, sizeof(hmi_work_buffer));
  memset(hmi_folded_cycle_buffer,
         0,
         sizeof(hmi_folded_cycle_buffer));
  memset(hmi_fold_weight_buffer,
         0,
         sizeof(hmi_fold_weight_buffer));
  memset(raw_wave_components,
         0,
         sizeof(raw_wave_components));
  raw_wave_component_count = 0U;
  memset(coherent_harmonic_sine_sum,
         0,
         sizeof(coherent_harmonic_sine_sum));
  memset(coherent_harmonic_cosine_sum,
         0,
         sizeof(coherent_harmonic_cosine_sum));
  memset(coherent_harmonic_amplitude_sum,
         0,
         sizeof(coherent_harmonic_amplitude_sum));
  memset(coherent_harmonic_capture_count,
         0,
         sizeof(coherent_harmonic_capture_count));
  memset(coherent_harmonic_evidence_count,
         0,
         sizeof(coherent_harmonic_evidence_count));
  hmi_folded_cycle_valid = 0U;

  latest_fft_result.voltage_peak_to_peak = 5.5F;
  latest_fft_result.voltage_rms = 5.5F;
  latest_fft_result.fundamental_frequency_hz = 5.5F;
  latest_fft_valid = 0U;
  saved_spectrum_valid = 1U;
  measurement_result_ready = 1U;
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
  if (hadc->Instance == ADC1)
  {
    /*
     * Stop through HAL rather than only clearing ADON.  This disables DDS
     * and the OVR interrupt, aborts the circular DMA stream, and returns all
     * handles to READY so a later '0' can start a fresh acquisition.
     */
    (void)ADC_Capture_Stop();
    __HAL_ADC_CLEAR_FLAG(
        &hadc1,
        ADC_FLAG_EOC | ADC_FLAG_EOS | ADC_FLAG_OVR);
    __HAL_ADC_CLEAR_FLAG(
        &hadc2,
        ADC_FLAG_EOC | ADC_FLAG_EOS | ADC_FLAG_OVR);
    HAL_NVIC_ClearPendingIRQ(ADC_IRQn);
    adc_block_ready = 1U;
  }
}

void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc)
{
  if (hadc->Instance == ADC1)
  {
    (void)ADC_Capture_Stop();
    __HAL_ADC_CLEAR_FLAG(
        &hadc1,
        ADC_FLAG_EOC | ADC_FLAG_EOS | ADC_FLAG_OVR);
    __HAL_ADC_CLEAR_FLAG(
        &hadc2,
        ADC_FLAG_EOC | ADC_FLAG_EOS | ADC_FLAG_OVR);
    adc_capture_error = 1U;
  }
}

void fft_porc(void)
{
#if APP_ADC_SIMULATION_MODE
  uint32_t processing_start_tick;
#endif

  if (measurement_start_request != 0U)
  {
    measurement_start_request = 0U;
    if (calibration_measurement_active != 0U)
    {
      calibration_capture_count = 0U;
      memset(calibration_gain_candidates,
             0,
             sizeof(calibration_gain_candidates));
      memset(calibration_bias_candidates,
             0,
             sizeof(calibration_bias_candidates));
    }
    measurement_capture_count = 0U;
    measurement_trimmed_vpp = 0.0F;
    memset(measurement_results, 0, sizeof(measurement_results));
    memset(spectrum_power_accumulator,
           0,
           sizeof(spectrum_power_accumulator));
    spectrum_accumulation_count = 0U;
    memset(raw_wave_components,
           0,
           sizeof(raw_wave_components));
    raw_wave_component_count = 0U;
    memset(coherent_harmonic_sine_sum,
           0,
           sizeof(coherent_harmonic_sine_sum));
    memset(coherent_harmonic_cosine_sum,
           0,
           sizeof(coherent_harmonic_cosine_sum));
    memset(coherent_harmonic_amplitude_sum,
           0,
           sizeof(coherent_harmonic_amplitude_sum));
    memset(coherent_harmonic_capture_count,
           0,
           sizeof(coherent_harmonic_capture_count));
    memset(coherent_harmonic_evidence_count,
           0,
           sizeof(coherent_harmonic_evidence_count));
    memset(hmi_work_buffer, 0, sizeof(hmi_work_buffer));
    memset(hmi_folded_cycle_buffer,
           0,
           sizeof(hmi_folded_cycle_buffer));
    memset(hmi_fold_weight_buffer,
           0,
           sizeof(hmi_fold_weight_buffer));
    hmi_folded_cycle_valid = 0U;
#if APP_ADC_SIMULATION_MODE
    app_debug_processing_ms = 0U;
#endif

    if (FFT_StartMeasurement() != HAL_OK)
    {
      App_SetMeasurementUnavailable();
    }

    return;
  }

  if (fft_measurement_active == 0U)
  {
    return;
  }

  if (adc_capture_error != 0U)
  {
    adc_capture_error = 0U;
    adc_block_ready = 0U;

    if (adc_capture_retry_count == 0U)
    {
      adc_capture_retry_count = 1U;

      if (ADC_Capture_Start() == HAL_OK)
      {
        return;
      }
    }

    fft_measurement_active = 0U;
    App_SetMeasurementUnavailable();
    return;
  }

  if (adc_block_ready == 0U)
  {
    return;
  }

  adc_block_ready = 0U;
  fft_measurement_active = 0U;

  if (ADC_BlockIsClipped())
  {
    App_SetMeasurementUnavailable();
    return;
  }

#if APP_ADC_SIMULATION_MODE
  processing_start_tick = HAL_GetTick();
#endif

  if (!App_AnalyzeCapturedBlock(&fft_work_result))
  {
    App_SetMeasurementUnavailable();
    return;
  }

  if (calibration_measurement_active != 0U)
  {
    if (!App_CollectFrontendCalibration(&fft_work_result))
    {
      App_SetMeasurementUnavailable();
      return;
    }

    if (calibration_capture_count <
        APP_CALIBRATION_CAPTURE_COUNT)
    {
      adc_capture_retry_count = 0U;

      if (ADC_Capture_Start() != HAL_OK)
      {
        App_SetMeasurementUnavailable();
        return;
      }

      fft_measurement_active = 1U;
      return;
    }

    calibration_measurement_active = 0U;

#if !APP_ADC_SIMULATION_MODE
    /* The trimmed eighteen-capture values are already live in RAM. Persistence
     * is transactional; a flash failure keeps the previous valid sector. */
    (void)CalibrationStore_Save(adc_frontend_gain,
                                adc_dc_bias_voltage);
#endif

    /* Calibration frames were converted with the old coefficients and must
     * never leak into the reported result. Start a completely fresh eighteen-
     * capture measurement using the newly averaged gain and bias. */
    measurement_start_request = 1U;
    return;
  }

  if (!App_CalculateCaptureSpectralVpp(&fft_work_result))
  {
    App_SetMeasurementUnavailable();
    return;
  }
  if (!App_AccumulateSpectrum())
  {
    App_SetMeasurementUnavailable();
    return;
  }
  if (!App_AccumulateCoherentComponents(
          &fft_work_result))
  {
    App_SetMeasurementUnavailable();
    return;
  }
  if (!App_AccumulateFilteredFoldedCapture(
          &fft_work_result))
  {
    App_SetMeasurementUnavailable();
    return;
  }
#if APP_ADC_SIMULATION_MODE
  app_debug_processing_ms +=
      HAL_GetTick() - processing_start_tick;
#endif
  measurement_results[measurement_capture_count] =
      fft_work_result;
  measurement_capture_count++;

  if (measurement_capture_count <
      APP_MEASUREMENT_CAPTURE_COUNT)
  {
    adc_capture_retry_count = 0U;

    if (ADC_Capture_Start() != HAL_OK)
    {
      App_SetMeasurementUnavailable();
      return;
    }

    fft_measurement_active = 1U;
    return;
  }

#if APP_ADC_SIMULATION_MODE
  processing_start_tick = HAL_GetTick();
#endif

  if (!App_FinalizeMeasurementResults())
  {
    App_SetMeasurementUnavailable();
    return;
  }

  if (!App_BuildSeparatedWaveComponents(
          &latest_fft_result))
  {
    App_SetMeasurementUnavailable();
    return;
  }

  if (!App_CalculateSeparatedVoltageMetrics(
          &latest_fft_result))
  {
    App_SetMeasurementUnavailable();
    return;
  }

  if (!App_FinalizeFoldedCycle())
  {
    App_SetMeasurementUnavailable();
    return;
  }

  if (!App_CalculateFoldedVoltageMetrics(
          &latest_fft_result))
  {
    App_SetMeasurementUnavailable();
    return;
  }

  /* Board-level high-amplitude correction requested for a true single-tone
   * input only.  Apply it after all eighteen captures and the folded-cycle
   * metric are finalized so it changes only the reported Vpp, exactly once.
   * Composite/harmonic signals, RMS, component amplitudes and wave data keep
   * their definition-based values. */
  if ((raw_wave_component_count == 1U) &&
      (raw_wave_components[0].harmonic_order == 1U) &&
      (latest_fft_result.voltage_peak_to_peak >
       APP_SINGLE_TONE_HIGH_VPP_THRESHOLD))
  {
    latest_fft_result.voltage_peak_to_peak +=
        APP_SINGLE_TONE_HIGH_VPP_CORRECTION;
  }

  latest_fft_valid = 1U;

  App_PrepareTimeWave(1U, saved_one_period_wave);
  App_PrepareTimeWave(3U, saved_three_period_wave);
  App_SaveSpectrumGraph();
#if APP_ADC_SIMULATION_MODE
  app_debug_processing_ms +=
      HAL_GetTick() - processing_start_tick;
#endif
  measurement_result_ready = 1U;
}

static float App_EstimateFundamentalHz(void)
{
  if ((latest_fft_valid == 0U) ||
      (latest_fft_result.peak_count == 0U))
  {
    return 0.0F;
  }

  return latest_fft_result.fundamental_frequency_hz;
}

static float App_GetSeparatedFundamentalAmplitude(void)
{
  float best_amplitude = 0.0F;
  uint8_t component;

  for (component = 0U;
       component < raw_wave_component_count;
       component++)
  {
    if ((isfinite(raw_wave_components[component].amplitude_peak)) &&
        (raw_wave_components[component].amplitude_peak > 0.0F) &&
        ((raw_wave_components[component].harmonic_order == 1U) ||
         (fabsf(raw_wave_components[component].frequency_ratio -
                1.0F) < 0.01F)))
    {
      best_amplitude =
          raw_wave_components[component].amplitude_peak;
      break;
    }
  }

  return best_amplitude;
}

static bool App_GetSeparatedHarmonic(
    uint8_t separated_harmonic_index,
    float *frequency_hz,
    float *amplitude_peak)
{
  uint8_t found_count = 0U;
  uint8_t component;

  if ((frequency_hz == NULL) || (amplitude_peak == NULL) ||
      (latest_fft_valid == 0U) ||
      (latest_fft_result.fundamental_frequency_hz <= 0.0F))
  {
    return false;
  }

  *frequency_hz = 0.0F;
  *amplitude_peak = 0.0F;

  for (component = 0U;
       component < raw_wave_component_count;
       component++)
  {
    const app_raw_wave_component_t *candidate =
        &raw_wave_components[component];

    if ((!isfinite(candidate->frequency_ratio)) ||
        (!isfinite(candidate->amplitude_peak)) ||
        (candidate->harmonic_order <= 1U) ||
        (candidate->amplitude_peak <
         APP_RAW_COMPONENT_MIN_AMPLITUDE_VOLTAGE))
    {
      continue;
    }

    if (found_count == separated_harmonic_index)
    {
      *frequency_hz =
          candidate->frequency_ratio *
          latest_fft_result.fundamental_frequency_hz;
      *amplitude_peak = candidate->amplitude_peak;
      return true;
    }

    found_count++;
  }

  return false;
}

static bool App_AccumulateFilteredFoldedCapture(
    const signal_fft_result_t *result)
{
  float fundamental_hz;
  float fundamental_phase_radians;
  float phase;
  float phase_step;
  float smallest_frequency_error = FLT_MAX;
  uint32_t sample;
  uint8_t peak;

  if ((result == NULL) ||
      (result->peak_count == 0U) ||
      (!isfinite(result->fundamental_frequency_hz)) ||
      (result->fundamental_frequency_hz <= 0.0F))
  {
    return false;
  }

  fundamental_hz = result->fundamental_frequency_hz;

  if ((!isfinite(fundamental_hz)) ||
      (fundamental_hz <= 0.0F) ||
      (fundamental_hz >=
       (0.5F * SIGNAL_ANALYSIS_SAMPLE_RATE_HZ)))
  {
    return false;
  }

  fundamental_phase_radians = 0.0F;

  /*
   * Each DMA acquisition starts at an unrelated waveform phase.  Find the
   * fitted FFT component nearest the selected fundamental and use its real
   * phase to align this complete 16384-point capture with the other records.
   */
  for (peak = 0U; peak < result->peak_count; peak++)
  {
    const float frequency_error =
        fabsf(result->peaks[peak].frequency_hz -
              fundamental_hz);

    if (isfinite(result->peaks[peak].phase_radians) &&
        (frequency_error < smallest_frequency_error))
    {
      smallest_frequency_error = frequency_error;
      fundamental_phase_radians =
          result->peaks[peak].phase_radians;
    }
  }

  if (smallest_frequency_error == FLT_MAX)
  {
    return false;
  }

  phase_step =
      fundamental_hz / SIGNAL_ANALYSIS_SAMPLE_RATE_HZ;
  phase = fundamental_phase_radians / APP_TWO_PI;
  phase -= floorf(phase);

  /*
   * Equivalent-time phase folding with no waveform classification: this
   * function is called for all eighteen acquisitions, so all 18 x 16384 filtered
   * samples add into the same 1024 phase bins.
   */
  for (sample = 0U; sample < SIGNAL_FFT_SIZE; sample++)
  {
    const float bin_position =
        phase * (float)HMI_WAVE_POINT_COUNT;
    const float bin_floor = floorf(bin_position);
    const uint32_t first_bin =
        (uint32_t)bin_floor % HMI_WAVE_POINT_COUNT;
    const uint32_t second_bin =
        (first_bin + 1U) % HMI_WAVE_POINT_COUNT;
    const float second_weight =
        bin_position - bin_floor;
    const float first_weight = 1.0F - second_weight;
    const float voltage = filtered_sample_buffer[
        ADC_FILTER_WARMUP_SAMPLES + sample];

    hmi_work_buffer[first_bin] +=
        voltage * first_weight;
    hmi_fold_weight_buffer[first_bin] += first_weight;
    hmi_work_buffer[second_bin] +=
        voltage * second_weight;
    hmi_fold_weight_buffer[second_bin] += second_weight;

    phase += phase_step;
    phase -= floorf(phase);
  }

  return true;
}

static bool App_FinalizeFoldedCycle(void)
{
  uint32_t point;

  /*
   * Usually all 1024 phase bins contain samples from the eighteen captures.
   * For an exact rational ADC/fundamental ratio, fill only genuinely empty
   * bins by circular interpolation between the nearest measured bins.
   */
  for (point = 0U; point < HMI_WAVE_POINT_COUNT; point++)
  {
    if (hmi_fold_weight_buffer[point] > 1.0e-6F)
    {
      hmi_folded_cycle_buffer[point] =
          hmi_work_buffer[point] /
          hmi_fold_weight_buffer[point];
    }
    else
    {
      uint32_t previous_distance;
      uint32_t next_distance;
      uint32_t previous_bin = point;
      uint32_t next_bin = point;

      for (previous_distance = 1U;
           previous_distance < HMI_WAVE_POINT_COUNT;
           previous_distance++)
      {
        previous_bin =
            (point + HMI_WAVE_POINT_COUNT -
             previous_distance) %
            HMI_WAVE_POINT_COUNT;
        if (hmi_fold_weight_buffer[previous_bin] >
            1.0e-6F)
        {
          break;
        }
      }

      for (next_distance = 1U;
           next_distance < HMI_WAVE_POINT_COUNT;
           next_distance++)
      {
        next_bin =
            (point + next_distance) %
            HMI_WAVE_POINT_COUNT;
        if (hmi_fold_weight_buffer[next_bin] >
            1.0e-6F)
        {
          break;
        }
      }

      if ((previous_distance >= HMI_WAVE_POINT_COUNT) ||
          (next_distance >= HMI_WAVE_POINT_COUNT))
      {
        hmi_folded_cycle_valid = 0U;
        return false;
      }

      {
        const float previous_value =
            hmi_work_buffer[previous_bin] /
            hmi_fold_weight_buffer[previous_bin];
        const float next_value =
            hmi_work_buffer[next_bin] /
            hmi_fold_weight_buffer[next_bin];
        const float interpolation =
            (float)previous_distance /
            (float)(previous_distance + next_distance);

        hmi_folded_cycle_buffer[point] =
            previous_value +
            interpolation * (next_value - previous_value);
      }
    }
  }

  /*
   * The folded record retains every in-band component, including components
   * that are intentionally not placed in the two public harmonic fields.
   * Apply the measured front-end correction only to components for which a
   * reliable coherent amplitude and phase are available; leave the residual
   * waveform intact instead of discarding it.
   */
  {
    uint8_t component;

    for (component = 0U;
         component < raw_wave_component_count;
         component++)
    {
      const float frequency_hz =
          raw_wave_components[component].frequency_ratio *
          latest_fft_result.fundamental_frequency_hz;
      const float correction =
          App_GetFrontendAmplitudeCorrection(frequency_hz);

      if (isfinite(correction) && (correction > 1.0e-6F))
      {
        const float corrected_amplitude =
            raw_wave_components[component].amplitude_peak;
        const float measured_amplitude =
            corrected_amplitude / correction;
        const float amplitude_delta =
            corrected_amplitude - measured_amplitude;

        for (point = 0U;
             point < HMI_WAVE_POINT_COUNT;
             point++)
        {
          const float base_phase =
              APP_TWO_PI * (float)point /
              (float)HMI_WAVE_POINT_COUNT;

          hmi_folded_cycle_buffer[point] +=
              amplitude_delta *
              sinf(raw_wave_components[component].frequency_ratio *
                       base_phase +
                   raw_wave_components[component]
                       .relative_phase_radians);
        }
      }
    }
  }

  /* Remove the small finite-record residual DC after all eighteen captures have
   * been combined.  Vpp is unchanged, while RMS now follows its strict AC
   * definition and is calculated from the same waveform sent to the HMI. */
  {
    float folded_mean = 0.0F;

    for (point = 0U; point < HMI_WAVE_POINT_COUNT; point++)
    {
      folded_mean += hmi_folded_cycle_buffer[point];
    }
    folded_mean /= (float)HMI_WAVE_POINT_COUNT;

    for (point = 0U; point < HMI_WAVE_POINT_COUNT; point++)
    {
      hmi_folded_cycle_buffer[point] -= folded_mean;
    }
  }

  hmi_folded_cycle_valid = 1U;
  return true;
}

static bool App_CalculateFoldedVoltageMetrics(
    signal_fft_result_t *result)
{
  float lowest_values[APP_FOLDED_EXTREME_CANDIDATE_COUNT];
  float highest_values[APP_FOLDED_EXTREME_CANDIDATE_COUNT];
  float minimum_voltage = 0.0F;
  float maximum_voltage = 0.0F;
  float sum_of_squares = 0.0F;
  const uint32_t retained_extreme_count =
      APP_FOLDED_EXTREME_CANDIDATE_COUNT -
      APP_FOLDED_EXTREME_DISCARD_COUNT;
  uint32_t point;
  uint32_t rank;

  if ((result == NULL) ||
      (hmi_folded_cycle_valid == 0U))
  {
    return false;
  }

  for (rank = 0U;
       rank < APP_FOLDED_EXTREME_CANDIDATE_COUNT;
       rank++)
  {
    lowest_values[rank] = FLT_MAX;
    highest_values[rank] = -FLT_MAX;
  }

  for (point = 0U; point < HMI_WAVE_POINT_COUNT; point++)
  {
    const float voltage = hmi_folded_cycle_buffer[point];

    if (!isfinite(voltage))
    {
      return false;
    }

    for (rank = 0U;
         rank < APP_FOLDED_EXTREME_CANDIDATE_COUNT;
         rank++)
    {
      if (voltage < lowest_values[rank])
      {
        uint32_t shift;

        for (shift = APP_FOLDED_EXTREME_CANDIDATE_COUNT - 1U;
             shift > rank;
             shift--)
        {
          lowest_values[shift] = lowest_values[shift - 1U];
        }
        lowest_values[rank] = voltage;
        break;
      }
    }

    for (rank = 0U;
         rank < APP_FOLDED_EXTREME_CANDIDATE_COUNT;
         rank++)
    {
      if (voltage > highest_values[rank])
      {
        uint32_t shift;

        for (shift = APP_FOLDED_EXTREME_CANDIDATE_COUNT - 1U;
             shift > rank;
             shift--)
        {
          highest_values[shift] = highest_values[shift - 1U];
        }
        highest_values[rank] = voltage;
        break;
      }
    }

    sum_of_squares += voltage * voltage;
  }

  /* The folded cycle already averages 18 x 16384 real samples into 1024
   * phase bins.  Suppress a remaining isolated interpolation/noise spike by
   * discarding only the single most extreme bin on each side, then average
   * the next eight extrema.  At the configured 600 kHz bandwidth even the
   * narrowest legal feature spans enough phase bins for this not to erase a
   * genuine peak. */
  for (rank = APP_FOLDED_EXTREME_DISCARD_COUNT;
       rank < APP_FOLDED_EXTREME_CANDIDATE_COUNT;
       rank++)
  {
    minimum_voltage += lowest_values[rank];
    maximum_voltage += highest_values[rank];
  }
  minimum_voltage /= (float)retained_extreme_count;
  maximum_voltage /= (float)retained_extreme_count;

  /* Folded metrics validate the waveform buffer only.  They must not replace
   * the eighteen-capture Vpp or the strict separated-component RMS already
   * stored in result. */
  {
    const float folded_vpp = maximum_voltage - minimum_voltage;
    const float folded_rms =
        sqrtf(sum_of_squares / (float)HMI_WAVE_POINT_COUNT);

    return isfinite(folded_vpp) &&
           isfinite(folded_rms) &&
           (folded_vpp >= 0.0F) &&
           (folded_rms >= 0.0F);
  }
}

static bool App_PrepareTimeWave(uint8_t cycle_count,
                                int *wave_buffer)
{
  uint32_t point;
  float minimum_voltage = FLT_MAX;
  float maximum_voltage = -FLT_MAX;

  if ((wave_buffer == NULL) ||
      ((cycle_count != 1U) && (cycle_count != 3U)))
  {
    return false;
  }

  if (hmi_folded_cycle_valid == 0U)
  {
    memset(wave_buffer,
           0,
           HMI_WAVE_POINT_COUNT * sizeof(wave_buffer[0]));
    return false;
  }

  /* Use the same complete, eighteen-capture folded input used for display
   * RMS.  FFT components remain responsible for the numeric harmonic fields,
   * but no unreported in-band waveform component is removed from commands
   * '1' and '3'. */
  for (point = 0U; point < HMI_WAVE_POINT_COUNT; point++)
  {
    const float cycle_position =
        (float)cycle_count * (float)point /
        (float)(HMI_WAVE_POINT_COUNT - 1U);
    const float wrapped_position =
        cycle_position - floorf(cycle_position);
    const float bin_position =
        wrapped_position * (float)HMI_WAVE_POINT_COUNT;
    const float bin_floor = floorf(bin_position);
    const uint32_t first_bin =
        (uint32_t)bin_floor % HMI_WAVE_POINT_COUNT;
    const uint32_t second_bin =
        (first_bin + 1U) % HMI_WAVE_POINT_COUNT;
    const float fraction = bin_position - bin_floor;
    const float voltage =
        hmi_folded_cycle_buffer[first_bin] +
        fraction *
        (hmi_folded_cycle_buffer[second_bin] -
         hmi_folded_cycle_buffer[first_bin]);

    hmi_work_buffer[point] = voltage;
    if (voltage < minimum_voltage)
    {
      minimum_voltage = voltage;
    }
    if (voltage > maximum_voltage)
    {
      maximum_voltage = voltage;
    }
  }

  if ((maximum_voltage - minimum_voltage) < 1.0e-6F)
  {
    memset(wave_buffer,
           0,
           HMI_WAVE_POINT_COUNT * sizeof(wave_buffer[0]));
    return true;
  }

  for (point = 0U; point < HMI_WAVE_POINT_COUNT; point++)
  {
    const float normalized =
        (hmi_work_buffer[point] - minimum_voltage) /
        (maximum_voltage - minimum_voltage);
    int display_value = 5 + (int)lrintf(
        normalized * (float)(HMI_WAVE_HEIGHT - 10));

    if (display_value < 5)
    {
      display_value = 5;
    }
    else if (display_value > (HMI_WAVE_HEIGHT - 5))
    {
      display_value = HMI_WAVE_HEIGHT - 5;
    }

    /* The HMI draws transparent-transfer points from left to right.  Store
     * time-domain points in reverse order so commands '1' and '3' display
     * the measured waveform with the required horizontal orientation. */
    wave_buffer[HMI_WAVE_POINT_COUNT - 1U - point] = display_value;
  }

  return true;
}

static void App_SaveSpectrumGraph(void)
{
  uint32_t point;
  const signal_fft_config_t *config = Signal_FFT_GetConfig();
  float maximum_amplitude = 0.0F;
  uint8_t component;

  if ((latest_fft_valid == 0U) ||
      (raw_wave_component_count == 0U) ||
      (config == NULL) ||
      (spectrum_accumulation_count !=
       APP_MEASUREMENT_CAPTURE_COUNT))
  {
    memset(saved_spectrum_graph, 0, sizeof(saved_spectrum_graph));
    saved_spectrum_valid = 1U;
    return;
  }

  for (component = 0U;
       component < raw_wave_component_count;
       component++)
  {
    const float amplitude =
        raw_wave_components[component].amplitude_peak;

    if (isfinite(amplitude) &&
        (amplitude > maximum_amplitude))
    {
      maximum_amplitude = amplitude;
    }
  }

  if (maximum_amplitude < 1.0e-12F)
  {
    memset(saved_spectrum_graph, 0, sizeof(saved_spectrum_graph));
    saved_spectrum_valid = 1U;
    return;
  }

  /*
   * The judged input is a discrete line spectrum containing one fundamental
   * and at most two harmonics.  Draw only the same confirmed components used
   * for x3/x5/x7, instead of turning Blackman-Harris skirts and ADC noise
   * inside a 72 dB raw display range into many false-looking spectral lines.
   */
  for (point = 0U; point < HMI_WAVE_POINT_COUNT; point++)
  {
    saved_spectrum_graph[point] = 5;
  }

  for (component = 0U;
       component < raw_wave_component_count;
       component++)
  {
    const float frequency_hz =
        raw_wave_components[component].frequency_ratio *
        latest_fft_result.fundamental_frequency_hz;
    const float normalized_frequency =
        (frequency_hz - config->minimum_frequency_hz) /
        (config->maximum_frequency_hz -
         config->minimum_frequency_hz);
    const float normalized_amplitude =
        raw_wave_components[component].amplitude_peak /
        maximum_amplitude;
    int32_t graph_point;
    int display_value;

    if ((!isfinite(normalized_frequency)) ||
        (!isfinite(normalized_amplitude)) ||
        (normalized_frequency < 0.0F) ||
        (normalized_frequency > 1.0F))
    {
      continue;
    }

    graph_point = (int32_t)lrintf(
        normalized_frequency *
        (float)(HMI_WAVE_POINT_COUNT - 1U));
    display_value = 5 + (int)lrintf(
        fminf(1.0F, fmaxf(0.0F, normalized_amplitude)) *
        (float)(HMI_WAVE_HEIGHT - 10));

    saved_spectrum_graph[(uint32_t)graph_point] =
        display_value;
  }

  saved_spectrum_valid = 1U;
}

void uart_proc(void)
{
  uint8_t received_command;

  if (measurement_result_ready != 0U)
  {
    float fundamental_display_value;
    float harmonic_1_frequency_hz = 0.0F;
    float harmonic_1_amplitude = 0.0F;
    float harmonic_2_frequency_hz = 0.0F;
    float harmonic_2_amplitude = 0.0F;

    measurement_result_ready = 0U;
    (void)App_GetSeparatedHarmonic(
        0U,
        &harmonic_1_frequency_hz,
        &harmonic_1_amplitude);
    (void)App_GetSeparatedHarmonic(
        1U,
        &harmonic_2_frequency_hz,
        &harmonic_2_amplitude);
    HMI_send_float(HMI_VPP_ADDRESS,
                   latest_fft_result.voltage_peak_to_peak);
    HMI_send_float(HMI_RMS_ADDRESS,
                   latest_fft_result.voltage_rms);

    /*
     * A four-decimal Hz value can overflow the HMI's signed 32-bit .val
     * above 214.7483 kHz.  Valid measurements are therefore displayed in
     * kHz.  Preserve the user-defined 5.5 sentinel when no peak is found.
     */
    fundamental_display_value =
        (latest_fft_result.peak_count > 0U) ?
            (latest_fft_result.fundamental_frequency_hz / 1000.0F +
             APP_FREQUENCY_DISPLAY_OFFSET_KHZ) :
            latest_fft_result.fundamental_frequency_hz;
    HMI_send_float(HMI_FUNDAMENTAL_ADDRESS,
                   fundamental_display_value);
    HMI_send_float(
        HMI_FUNDAMENTAL_AMPLITUDE_ADDRESS,
        App_GetSeparatedFundamentalAmplitude());
    HMI_send_float(
        HMI_HARMONIC_1_FREQUENCY_ADDRESS,
        (harmonic_1_frequency_hz > 0.0F) ?
            (harmonic_1_frequency_hz / 1000.0F +
             APP_FREQUENCY_DISPLAY_OFFSET_KHZ) :
            0.0F);
    HMI_send_float(
        HMI_HARMONIC_1_AMPLITUDE_ADDRESS,
        harmonic_1_amplitude);
    HMI_send_float(
        HMI_HARMONIC_2_FREQUENCY_ADDRESS,
        (harmonic_2_frequency_hz > 0.0F) ?
            (harmonic_2_frequency_hz / 1000.0F +
             APP_FREQUENCY_DISPLAY_OFFSET_KHZ) :
            0.0F);
    HMI_send_float(
        HMI_HARMONIC_2_AMPLITUDE_ADDRESS,
        harmonic_2_amplitude);

#if APP_ADC_SIMULATION_MODE
    HMI_send_number("x9.val", (int)app_debug_processing_ms);
#endif

    if (calibration_result_output_pending != 0U)
    {
      /* The calibration frames themselves use the previous coefficients and
       * are never displayed.  The scalar fields above come from the fresh
       * eighteen-capture measurement started after calibration. */
      calibration_result_output_pending = 0U;
    }
  }

  if (!HMI_UART_TakeCommand(&received_command))
  {
    return;
  }

  if ((received_command == (uint8_t)'\r') ||
      (received_command == (uint8_t)'\n'))
  {
    return;
  }

  if (received_command == (uint8_t)'0')
  {
    calibration_result_output_pending = 0U;
    calibration_measurement_active = 0U;
    measurement_start_request = 1U;
  }

  if (received_command == (uint8_t)'9')
  {
    calibration_result_output_pending = 1U;
    HMI_send_float(HMI_VPP_ADDRESS,
                   APP_CALIBRATION_BUSY_DISPLAY_VALUE);
    HMI_send_float(HMI_RMS_ADDRESS,
                   APP_CALIBRATION_BUSY_DISPLAY_VALUE);
    HMI_send_float(HMI_FUNDAMENTAL_ADDRESS,
                   APP_CALIBRATION_BUSY_DISPLAY_VALUE);
    HMI_send_float(HMI_FUNDAMENTAL_AMPLITUDE_ADDRESS,
                   APP_CALIBRATION_BUSY_DISPLAY_VALUE);
    HMI_send_float(HMI_HARMONIC_1_FREQUENCY_ADDRESS,
                   APP_CALIBRATION_BUSY_DISPLAY_VALUE);
    HMI_send_float(HMI_HARMONIC_1_AMPLITUDE_ADDRESS,
                   APP_CALIBRATION_BUSY_DISPLAY_VALUE);
    HMI_send_float(HMI_HARMONIC_2_FREQUENCY_ADDRESS,
                   APP_CALIBRATION_BUSY_DISPLAY_VALUE);
    HMI_send_float(HMI_HARMONIC_2_AMPLITUDE_ADDRESS,
                   APP_CALIBRATION_BUSY_DISPLAY_VALUE);
    calibration_measurement_active = 1U;
    measurement_start_request = 1U;
  }

  if (received_command == (uint8_t)'1')
  {
    HMI_Wave_Clear(HMI_WAVE_ADDRESS, 0);
    HMI_Wave_Fast(HMI_WAVE_ADDRESS,
                  0,
                  HMI_WAVE_POINT_COUNT,
                  saved_one_period_wave);
  }

  if (received_command == (uint8_t)'3')
  {
    HMI_Wave_Clear(HMI_WAVE_ADDRESS, 0);
    HMI_Wave_Fast(HMI_WAVE_ADDRESS,
                  0,
                  HMI_WAVE_POINT_COUNT,
                  saved_three_period_wave);
  }

  if (received_command == (uint8_t)'P')
  {
    HMI_Wave_Clear(HMI_WAVE_ADDRESS, 0);
    HMI_Wave_Fast(HMI_WAVE_ADDRESS,
                  0,
                  HMI_WAVE_POINT_COUNT,
                  saved_spectrum_graph);
  }

  if (received_command == (uint8_t)'6')
  {
    (void)ADC_Capture_Stop();

    measurement_start_request = 0U;
    calibration_measurement_active = 0U;
    measurement_capture_count = 0U;
    fft_measurement_active = 0U;
    adc_capture_retry_count = 0U;
    adc_block_ready = 0U;
    adc_capture_error = 0U;
    measurement_result_ready = 0U;
    calibration_result_output_pending = 0U;
    latest_fft_valid = 0U;
    saved_spectrum_valid = 0U;

    memset(adc_sample_buffer, 0, sizeof(adc_sample_buffer));
    memset(adc_float_buffer, 0, sizeof(adc_float_buffer));
    memset(filtered_sample_buffer, 0, sizeof(filtered_sample_buffer));
    memset(spectrum_power_accumulator,
           0,
           sizeof(spectrum_power_accumulator));
    spectrum_accumulation_count = 0U;
    memset(&fft_work_result, 0, sizeof(fft_work_result));
    memset(measurement_results, 0, sizeof(measurement_results));
    memset(&latest_fft_result, 0, sizeof(latest_fft_result));
    memset(saved_one_period_wave, 0, sizeof(saved_one_period_wave));
    memset(saved_three_period_wave, 0, sizeof(saved_three_period_wave));
    memset(saved_spectrum_graph, 0, sizeof(saved_spectrum_graph));
    memset(hmi_work_buffer, 0, sizeof(hmi_work_buffer));
    memset(hmi_folded_cycle_buffer,
           0,
           sizeof(hmi_folded_cycle_buffer));
    memset(hmi_fold_weight_buffer,
           0,
           sizeof(hmi_fold_weight_buffer));
    memset(raw_wave_components,
           0,
           sizeof(raw_wave_components));
    raw_wave_component_count = 0U;
    memset(coherent_harmonic_sine_sum,
           0,
           sizeof(coherent_harmonic_sine_sum));
    memset(coherent_harmonic_cosine_sum,
           0,
           sizeof(coherent_harmonic_cosine_sum));
    memset(coherent_harmonic_amplitude_sum,
           0,
           sizeof(coherent_harmonic_amplitude_sum));
    memset(coherent_harmonic_capture_count,
           0,
           sizeof(coherent_harmonic_capture_count));
    memset(coherent_harmonic_evidence_count,
           0,
           sizeof(coherent_harmonic_evidence_count));
    hmi_folded_cycle_valid = 0U;
    Signal_Filter_Reset();

    HMI_send_float(HMI_VPP_ADDRESS, 0.0F);
    HMI_send_float(HMI_RMS_ADDRESS, 0.0F);
    HMI_send_float(HMI_FUNDAMENTAL_ADDRESS, 0.0F);
    HMI_send_float(HMI_FUNDAMENTAL_AMPLITUDE_ADDRESS, 0.0F);
    HMI_send_float(HMI_HARMONIC_1_FREQUENCY_ADDRESS, 0.0F);
    HMI_send_float(HMI_HARMONIC_1_AMPLITUDE_ADDRESS, 0.0F);
    HMI_send_float(HMI_HARMONIC_2_FREQUENCY_ADDRESS, 0.0F);
    HMI_send_float(HMI_HARMONIC_2_AMPLITUDE_ADDRESS, 0.0F);
    HMI_Wave_Clear(HMI_WAVE_ADDRESS, 0);
  }

}

/* USER CODE END 4 */

/* MPU Configuration */
static void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct = {0};

  HAL_MPU_Disable();

  /*
   * Keep the CubeMX default background guard, then override the first
   * 256 KiB of D2 SRAM for the ADC DMA buffer as non-cacheable and shareable.
   * The 16384-point full-rate analysis frame needs 16,896 16-bit raw ADC
   * samples (33 KiB) including the FIR warm-up interval.
   */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.BaseAddress = 0x00000000U;
  MPU_InitStruct.Size = MPU_REGION_SIZE_4GB;
  MPU_InitStruct.SubRegionDisable = 0x87U;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_NO_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;
  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  MPU_InitStruct.Number = MPU_REGION_NUMBER1;
  MPU_InitStruct.BaseAddress = 0x30000000U;
  MPU_InitStruct.Size = MPU_REGION_SIZE_256KB;
  MPU_InitStruct.SubRegionDisable = 0x00U;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;
  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
