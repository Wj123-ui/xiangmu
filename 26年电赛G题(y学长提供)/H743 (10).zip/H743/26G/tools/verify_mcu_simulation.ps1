[CmdletBinding()]
param(
    [string]$Port = "COM14",
    [int]$BaudRate = 115200,
    [switch]$SkipTargetReset,
    [switch]$EnableBoardAccess,
    [string[]]$DetailedCases = @(),
    [string]$OutputPath = ""
)

$ErrorActionPreference = "Stop"
$WavePointCount = 1024

if (-not $EnableBoardAccess) {
    throw "Board access is locked. Re-run only after explicit user authorization, with -EnableBoardAccess."
}

$cases = @(
    [pscustomobject]@{ Name = "sine_100k"; F0 = 100000.0; Vpp = 1.0000; Rms = 0.35355; Peaks = @(
        [pscustomobject]@{ Frequency = 100000.0; Amplitude = 0.5000 }) },
    [pscustomobject]@{ Name = "square_100k"; F0 = 100000.0; Vpp = 1.1842; Rms = 0.48724; Peaks = @(
        [pscustomobject]@{ Frequency = 100000.0; Amplitude = 0.63662 },
        [pscustomobject]@{ Frequency = 300000.0; Amplitude = 0.21221 },
        [pscustomobject]@{ Frequency = 500000.0; Amplitude = 0.12732 }) },
    [pscustomobject]@{ Name = "square_200k"; F0 = 200000.0; Vpp = 0.2961; Rms = 0.12181; Peaks = @(
        [pscustomobject]@{ Frequency = 200000.0; Amplitude = 0.15915 }) },
    [pscustomobject]@{ Name = "square_400k"; F0 = 400000.0; Vpp = 0.2961; Rms = 0.12181; Peaks = @(
        [pscustomobject]@{ Frequency = 400000.0; Amplitude = 0.15915 }) },
    [pscustomobject]@{ Name = "square_500k"; F0 = 500000.0; Vpp = 0.2961; Rms = 0.12181; Peaks = @(
        [pscustomobject]@{ Frequency = 500000.0; Amplitude = 0.15915 }) },
    [pscustomobject]@{ Name = "harmonics_10k5"; F0 = 10500.0; Vpp = 0.1122; Rms = 0.03869; Peaks = @(
        [pscustomobject]@{ Frequency = 10500.0; Amplitude = 0.0500 },
        [pscustomobject]@{ Frequency = 31500.0; Amplitude = 0.0200 },
        [pscustomobject]@{ Frequency = 42000.0; Amplitude = 0.0100 }); WaveComponents = @(
        [pscustomobject]@{ Order = 1.0; Amplitude = 0.0500; Phase = 0.0 },
        [pscustomobject]@{ Order = 3.0; Amplitude = 0.0200; Phase = -0.35 },
        [pscustomobject]@{ Order = 4.0; Amplitude = 0.0100; Phase = 0.55 }) },
    [pscustomobject]@{ Name = "sine_550k"; F0 = 550000.0; Vpp = 0.2000; Rms = 0.07071; Peaks = @(
        [pscustomobject]@{ Frequency = 550000.0; Amplitude = 0.1000 }) },
    [pscustomobject]@{ Name = "harmonics_100k_1m2"; F0 = 100000.0; Vpp = 0.1225; Rms = 0.03873; Peaks = @(
        [pscustomobject]@{ Frequency = 100000.0; Amplitude = 0.0500 },
        [pscustomobject]@{ Frequency = 200000.0; Amplitude = 0.0200 },
        [pscustomobject]@{ Frequency = 300000.0; Amplitude = 0.0100 }); WaveComponents = @(
        [pscustomobject]@{ Order = 1.0; Amplitude = 0.0500; Phase = 0.0 },
        [pscustomobject]@{ Order = 2.0; Amplitude = 0.0200; Phase = -0.35 },
        [pscustomobject]@{ Order = 3.0; Amplitude = 0.0100; Phase = 0.55 }) },
    [pscustomobject]@{ Name = "sine_10k"; F0 = 10000.0; Vpp = 0.0500; Rms = 0.01768; Peaks = @(
        [pscustomobject]@{ Frequency = 10000.0; Amplitude = 0.0250 }) },
    [pscustomobject]@{ Name = "sine_200k"; F0 = 200000.0; Vpp = 0.2500; Rms = 0.08839; Peaks = @(
        [pscustomobject]@{ Frequency = 200000.0; Amplitude = 0.1250 }) },
    [pscustomobject]@{ Name = "sine_500k_small"; F0 = 500000.0; Vpp = 0.0500; Rms = 0.01768; Peaks = @(
        [pscustomobject]@{ Frequency = 500000.0; Amplitude = 0.0250 }) },
    [pscustomobject]@{ Name = "sine_500k_large"; F0 = 500000.0; Vpp = 0.2500; Rms = 0.08839; Peaks = @(
        [pscustomobject]@{ Frequency = 500000.0; Amplitude = 0.1250 }) },
    [pscustomobject]@{ Name = "sine_599k"; F0 = 599000.0; Vpp = 0.2500; Rms = 0.08839; Peaks = @(
        [pscustomobject]@{ Frequency = 599000.0; Amplitude = 0.1250 }) },
    [pscustomobject]@{ Name = "third_harmonic"; F0 = 100000.0; Vpp = 0.1075; Rms = 0.03808; Peaks = @(
        [pscustomobject]@{ Frequency = 100000.0; Amplitude = 0.0500 },
        [pscustomobject]@{ Frequency = 300000.0; Amplitude = 0.0200 }) },
    [pscustomobject]@{ Name = "upper_band_harmonics"; F0 = 200000.0; Vpp = 0.1225; Rms = 0.03873; Peaks = @(
        [pscustomobject]@{ Frequency = 200000.0; Amplitude = 0.0500 },
        [pscustomobject]@{ Frequency = 400000.0; Amplitude = 0.0200 }) },
    [pscustomobject]@{ Name = "truncated_square"; F0 = 100000.0; Vpp = 0.1120; Rms = 0.04552; Peaks = @(
        [pscustomobject]@{ Frequency = 100000.0; Amplitude = 0.0600 },
        [pscustomobject]@{ Frequency = 300000.0; Amplitude = 0.0200 },
        [pscustomobject]@{ Frequency = 500000.0; Amplitude = 0.0120 }) },
    [pscustomobject]@{ Name = "triangle"; F0 = 100000.0; Vpp = 0.2333; Rms = 0.07216; Peaks = @(
        [pscustomobject]@{ Frequency = 100000.0; Amplitude = 0.10132 },
        [pscustomobject]@{ Frequency = 300000.0; Amplitude = 0.01126 },
        [pscustomobject]@{ Frequency = 500000.0; Amplitude = 0.00405 }) },
    [pscustomobject]@{ Name = "sawtooth"; F0 = 80000.0; Vpp = 0.2066; Rms = 0.05541; Peaks = @(
        [pscustomobject]@{ Frequency = 80000.0; Amplitude = 0.06366 },
        [pscustomobject]@{ Frequency = 160000.0; Amplitude = 0.03183 },
        [pscustomobject]@{ Frequency = 240000.0; Amplitude = 0.02122 }) },
    [pscustomobject]@{ Name = "pulse_25"; F0 = 60000.0; Vpp = 0.2315; Rms = 0.08464; Peaks = @(
        [pscustomobject]@{ Frequency = 60000.0; Amplitude = 0.09003 },
        [pscustomobject]@{ Frequency = 120000.0; Amplitude = 0.06366 },
        [pscustomobject]@{ Frequency = 180000.0; Amplitude = 0.03001 }) },
    [pscustomobject]@{ Name = "clipped_sine"; F0 = 120000.0; Vpp = 0.2054; Rms = 0.08502; Peaks = @(
        [pscustomobject]@{ Frequency = 120000.0; Amplitude = 0.11859 },
        [pscustomobject]@{ Frequency = 360000.0; Amplitude = 0.02020 }) },
    [pscustomobject]@{ Name = "asymmetric_phase"; F0 = 75000.0; Vpp = 0.1689; Rms = 0.05324; Peaks = @(
        [pscustomobject]@{ Frequency = 75000.0; Amplitude = 0.0700 },
        [pscustomobject]@{ Frequency = 150000.0; Amplitude = 0.0250 },
        [pscustomobject]@{ Frequency = 375000.0; Amplitude = 0.0120 }); WaveComponents = @(
        [pscustomobject]@{ Order = 1.0; Amplitude = 0.0700; Phase = 0.0 },
        [pscustomobject]@{ Order = 2.0; Amplitude = 0.0250; Phase = -0.35 },
        [pscustomobject]@{ Order = 5.0; Amplitude = 0.0120; Phase = 0.55 }) },
    [pscustomobject]@{ Name = "g_low_10k_h2_h5"; F0 = 10000.0; Vpp = 0.10824; Rms = 0.02612; Peaks = @(
        [pscustomobject]@{ Frequency = 10000.0; Amplitude = 0.0080 },
        [pscustomobject]@{ Frequency = 20000.0; Amplitude = 0.0300 },
        [pscustomobject]@{ Frequency = 50000.0; Amplitude = 0.0200 }); WaveComponents = @(
        [pscustomobject]@{ Order = 1.0; Amplitude = 0.0080; Phase = 0.0 },
        [pscustomobject]@{ Order = 2.0; Amplitude = 0.0300; Phase = 1.10 },
        [pscustomobject]@{ Order = 5.0; Amplitude = 0.0200; Phase = -0.80 }) },
    [pscustomobject]@{ Name = "g_12k5_h3_h7"; F0 = 12500.0; Vpp = 0.14154; Rms = 0.03500; Peaks = @(
        [pscustomobject]@{ Frequency = 12500.0; Amplitude = 0.0400 },
        [pscustomobject]@{ Frequency = 37500.0; Amplitude = 0.0250 },
        [pscustomobject]@{ Frequency = 87500.0; Amplitude = 0.0150 }); WaveComponents = @(
        [pscustomobject]@{ Order = 1.0; Amplitude = 0.0400; Phase = 0.0 },
        [pscustomobject]@{ Order = 3.0; Amplitude = 0.0250; Phase = 0.90 },
        [pscustomobject]@{ Order = 7.0; Amplitude = 0.0150; Phase = -1.20 }) },
    [pscustomobject]@{ Name = "g_37k5_h2_h5"; F0 = 37500.0; Vpp = 0.15729; Rms = 0.04031; Peaks = @(
        [pscustomobject]@{ Frequency = 37500.0; Amplitude = 0.0450 },
        [pscustomobject]@{ Frequency = 75000.0; Amplitude = 0.0300 },
        [pscustomobject]@{ Frequency = 187500.0; Amplitude = 0.0180 }); WaveComponents = @(
        [pscustomobject]@{ Order = 1.0; Amplitude = 0.0450; Phase = 0.0 },
        [pscustomobject]@{ Order = 2.0; Amplitude = 0.0300; Phase = -1.10 },
        [pscustomobject]@{ Order = 5.0; Amplitude = 0.0180; Phase = 0.75 }) },
    [pscustomobject]@{ Name = "g_83k_h2_h4"; F0 = 83000.0; Vpp = 0.17565; Rms = 0.04295; Peaks = @(
        [pscustomobject]@{ Frequency = 83000.0; Amplitude = 0.0350 },
        [pscustomobject]@{ Frequency = 166000.0; Amplitude = 0.0280 },
        [pscustomobject]@{ Frequency = 332000.0; Amplitude = 0.0410 }); WaveComponents = @(
        [pscustomobject]@{ Order = 1.0; Amplitude = 0.0350; Phase = 0.0 },
        [pscustomobject]@{ Order = 2.0; Amplitude = 0.0280; Phase = 1.25 },
        [pscustomobject]@{ Order = 4.0; Amplitude = 0.0410; Phase = -0.65 }) },
    [pscustomobject]@{ Name = "g_125k_h2_h4"; F0 = 125000.0; Vpp = 0.15093; Rms = 0.04093; Peaks = @(
        [pscustomobject]@{ Frequency = 125000.0; Amplitude = 0.0500 },
        [pscustomobject]@{ Frequency = 250000.0; Amplitude = 0.0250 },
        [pscustomobject]@{ Frequency = 500000.0; Amplitude = 0.0150 }); WaveComponents = @(
        [pscustomobject]@{ Order = 1.0; Amplitude = 0.0500; Phase = 0.0 },
        [pscustomobject]@{ Order = 2.0; Amplitude = 0.0250; Phase = -0.90 },
        [pscustomobject]@{ Order = 4.0; Amplitude = 0.0150; Phase = 1.40 }) },
    [pscustomobject]@{ Name = "g_160k_h2_h3"; F0 = 160000.0; Vpp = 0.13502; Rms = 0.04198; Peaks = @(
        [pscustomobject]@{ Frequency = 160000.0; Amplitude = 0.0250 },
        [pscustomobject]@{ Frequency = 320000.0; Amplitude = 0.0500 },
        [pscustomobject]@{ Frequency = 480000.0; Amplitude = 0.0200 }); WaveComponents = @(
        [pscustomobject]@{ Order = 1.0; Amplitude = 0.0250; Phase = 0.0 },
        [pscustomobject]@{ Order = 2.0; Amplitude = 0.0500; Phase = 0.60 },
        [pscustomobject]@{ Order = 3.0; Amplitude = 0.0200; Phase = -1.00 }) },
    [pscustomobject]@{ Name = "g_250k_h2"; F0 = 250000.0; Vpp = 0.15820; Rms = 0.05099; Peaks = @(
        [pscustomobject]@{ Frequency = 250000.0; Amplitude = 0.0600 },
        [pscustomobject]@{ Frequency = 500000.0; Amplitude = 0.0400 }); WaveComponents = @(
        [pscustomobject]@{ Order = 1.0; Amplitude = 0.0600; Phase = 0.0 },
        [pscustomobject]@{ Order = 2.0; Amplitude = 0.0400; Phase = 1.30 }) },
    [pscustomobject]@{ Name = "g_interference_50k_h3_h7"; F0 = 50000.0; Vpp = 0.12917; Rms = 0.03500; Peaks = @(
        [pscustomobject]@{ Frequency = 50000.0; Amplitude = 0.0400 },
        [pscustomobject]@{ Frequency = 150000.0; Amplitude = 0.0250 },
        [pscustomobject]@{ Frequency = 350000.0; Amplitude = 0.0150 }); WaveComponents = @(
        [pscustomobject]@{ Order = 1.0; Amplitude = 0.0400; Phase = 0.0 },
        [pscustomobject]@{ Order = 3.0; Amplitude = 0.0250; Phase = -0.45 },
        [pscustomobject]@{ Order = 7.0; Amplitude = 0.0150; Phase = 1.10 }) }
)

function Read-UntilQuiet {
    param(
        [System.IO.Ports.SerialPort]$SerialPort,
        [int]$TimeoutMilliseconds = 6000,
        # HMI_Wave_Fast deliberately waits 100 ms after its addt header.  Give
        # the 1024-byte 115200-baud payload enough margin between USB serial
        # driver chunks before treating a frame as complete.
        [int]$QuietMilliseconds = 300
    )

    $bytes = [System.Collections.Generic.List[byte]]::new()
    $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMilliseconds)
    $lastData = [DateTime]::UtcNow

    while ([DateTime]::UtcNow -lt $deadline) {
        $available = $SerialPort.BytesToRead
        if ($available -gt 0) {
            $buffer = [byte[]]::new($available)
            $read = $SerialPort.Read($buffer, 0, $buffer.Length)
            for ($index = 0; $index -lt $read; $index++) {
                $bytes.Add($buffer[$index])
            }
            $lastData = [DateTime]::UtcNow
        }
        elseif (($bytes.Count -gt 0) -and
                (([DateTime]::UtcNow - $lastData).TotalMilliseconds -ge
                 $QuietMilliseconds)) {
            break
        }

        Start-Sleep -Milliseconds 3
    }

    if ($bytes.Count -eq 0) {
        throw "USART2 timed out without a response"
    }

    return $bytes.ToArray()
}

function Send-Command {
    param(
        [System.IO.Ports.SerialPort]$SerialPort,
        [byte]$Command
    )

    $SerialPort.Write([byte[]]@($Command), 0, 1)
}

function Discard-AutomaticSuite {
    param([System.IO.Ports.SerialPort]$SerialPort)

    $started = [DateTime]::UtcNow
    $deadline = $started.AddSeconds(30)
    $lastData = $started

    while ([DateTime]::UtcNow -lt $deadline) {
        if ($SerialPort.BytesToRead -gt 0) {
            $SerialPort.DiscardInBuffer()
            $lastData = [DateTime]::UtcNow
        }
        elseif ((([DateTime]::UtcNow - $started).TotalSeconds -ge 2.0) -and
                (([DateTime]::UtcNow - $lastData).TotalMilliseconds -ge
                 750.0)) {
            return
        }

        Start-Sleep -Milliseconds 10
    }

    throw "Automatic simulation suite did not become quiet within 30 seconds"
}

function Parse-Metrics {
    param(
        [byte[]]$Raw,
        [object]$ExpectedCase
    )

    $text = [Text.Encoding]::ASCII.GetString($Raw)
    $values = @{}
    foreach ($match in [regex]::Matches($text, "x([0-7])\.val=(-?\d+)")) {
        $values[[int]$match.Groups[1].Value] =
            [int64]$match.Groups[2].Value
    }

    foreach ($index in 0..7) {
        if (-not $values.ContainsKey($index)) {
            $unusedPeakField =
                (($index -eq 4) -or ($index -eq 5)) -and
                ($ExpectedCase.Peaks.Count -lt 2)
            $unusedThirdPeakField =
                (($index -eq 6) -or ($index -eq 7)) -and
                ($ExpectedCase.Peaks.Count -lt 3)
            if ($unusedPeakField -or $unusedThirdPeakField) {
                $values[$index] = 0
            }
            else {
                throw "Incomplete HMI metric frame: $text"
            }
        }
    }

    $vppRaw = [int64]($values[0])
    $rmsRaw = [int64]($values[1])
    $fundamentalRaw = [int64]($values[2])
    $amplitudeRaw = @(
        [int64]($values[3]),
        [int64]($values[5]),
        [int64]($values[7])
    )
    $frequencyRaw = @(
        [int64]($values[2]),
        [int64]($values[4]),
        [int64]($values[6])
    )
    $vpp = [double]($vppRaw) / 10000.0
    $rms = [double]($rmsRaw) / 10000.0
    $fundamentalHz = [double]($fundamentalRaw) / 10.0
    $amplitudes = @(
        [double]($amplitudeRaw[0]) / 10000.0
        [double]($amplitudeRaw[1]) / 10000.0
        [double]($amplitudeRaw[2]) / 10000.0
    )
    $frequenciesHz = @(
        [double]($frequencyRaw[0]) / 10.0
        [double]($frequencyRaw[1]) / 10.0
        [double]($frequencyRaw[2]) / 10.0
    )

    return [pscustomobject]@{
        Vpp = $vpp
        Rms = $rms
        FundamentalHz = $fundamentalHz
        PeakAmplitudes = $amplitudes
        PeakFrequenciesHz = $frequenciesHz
    }
}

function Extract-Wave {
    param(
        [byte[]]$Raw,
        [string]$ExpectedHeader
    )

    $headerBytes = [Text.Encoding]::ASCII.GetBytes($ExpectedHeader)
    $data = [byte[]]::new($WavePointCount)
    $headerStart = -1
    for ($index = 0;
         $index -le ($Raw.Length - $headerBytes.Length);
         $index++) {
        $matches = $true
        for ($headerIndex = 0;
             $headerIndex -lt $headerBytes.Length;
             $headerIndex++) {
            if ($Raw[$index + $headerIndex] -ne
                $headerBytes[$headerIndex]) {
                $matches = $false
                break
            }
        }
        if ($matches) {
            $headerStart = $index
            break
        }
    }

    if ($headerStart -lt 0) {
        throw "Missing HMI header '$ExpectedHeader'"
    }

    $delimiterStart = $headerStart + $headerBytes.Length
    $dataStart = $delimiterStart + 3
    $dataEnd = $dataStart + $WavePointCount
    if (($dataEnd + 3) -gt $Raw.Length) {
        throw "${ExpectedHeader}: incomplete ${WavePointCount}-point payload"
    }
    foreach ($position in @(
        $delimiterStart,
        ($delimiterStart + 1),
        ($delimiterStart + 2),
        $dataEnd,
        ($dataEnd + 1),
        ($dataEnd + 2))) {
        if ($Raw[$position] -ne 0xFF) {
            throw "${ExpectedHeader}: invalid HMI delimiter at byte $position"
        }
    }

    [Array]::Copy($Raw, $dataStart, $data, 0, $data.Length)
    return $data
}

function Read-WaveWithRetry {
    param(
        [System.IO.Ports.SerialPort]$SerialPort,
        [byte]$Command,
        [string]$ExpectedHeader
    )

    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            $SerialPort.DiscardInBuffer()
            Send-Command $SerialPort $Command
            return Extract-Wave (Read-UntilQuiet $SerialPort) `
                $ExpectedHeader
        }
        catch {
            if ($attempt -eq 3) {
                throw
            }
            Start-Sleep -Milliseconds 100
        }
    }
}

function Assert-Near {
    param(
        [double]$Actual,
        [double]$Expected,
        [double]$Tolerance,
        [string]$Label
    )

    if ([Math]::Abs($Actual - $Expected) -gt $Tolerance) {
        throw "${Label}: actual=$Actual expected=$Expected tolerance=$Tolerance"
    }
}

function Assert-HarmonicWaveShape {
    param(
        [byte[]]$Actual,
        [int]$CycleCount,
        [object[]]$Components,
        [string]$Label
    )

    $expectedVoltage = [double[]]::new($WavePointCount)
    for ($point = 0; $point -lt $WavePointCount; $point++) {
        $basePhase =
            2.0 * [Math]::PI * $CycleCount * $point /
            ($WavePointCount - 1)
        $voltage = 0.0
        foreach ($component in $Components) {
            $voltage +=
                [double]$component.Amplitude *
                [Math]::Sin(
                    [double]$component.Order * $basePhase +
                    [double]$component.Phase)
        }
        $expectedVoltage[$point] = $voltage
    }

    $minimum = ($expectedVoltage | Measure-Object -Minimum).Minimum
    $maximum = ($expectedVoltage | Measure-Object -Maximum).Maximum
    $span = $maximum - $minimum
    if ($span -le 1.0e-9) {
        throw "${Label}: expected waveform is constant"
    }

    $sumAbsoluteError = 0.0
    $maximumError = 0.0
    for ($point = 0; $point -lt $WavePointCount; $point++) {
        $normalized =
            ($expectedVoltage[$point] - $minimum) / $span
        $expectedDisplay =
            5.0 + [Math]::Round($normalized * 170.0)
        $error =
            [Math]::Abs([double]$Actual[$point] - $expectedDisplay)
        $sumAbsoluteError += $error
        if ($error -gt $maximumError) {
            $maximumError = $error
        }
    }

    $meanAbsoluteError =
        $sumAbsoluteError / $WavePointCount
    if (($meanAbsoluteError -gt 4.0) -or
        ($maximumError -gt 18.0)) {
        throw "${Label}: waveform mismatch, " +
              "mean error=$meanAbsoluteError, max error=$maximumError"
    }

    return [Math]::Round($meanAbsoluteError, 2)
}

if (-not $SkipTargetReset) {
    $programmer = Get-Command "STM32_Programmer_CLI" -ErrorAction Stop
    & $programmer.Source -c port=SWD freq=4000 -rst -run | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "STM32 target reset failed with exit code $LASTEXITCODE"
    }
    Start-Sleep -Milliseconds 400
}

$serial = [System.IO.Ports.SerialPort]::new(
    $Port,
    $BaudRate,
    [System.IO.Ports.Parity]::None,
    8,
    [System.IO.Ports.StopBits]::One)
$serial.ReadTimeout = 200
$serial.WriteTimeout = 500
$results = @()

try {
    $serial.Open()
    $serial.DiscardInBuffer()
    $serial.DiscardOutBuffer()
    Discard-AutomaticSuite $serial

    for ($caseIndex = 0; $caseIndex -lt $cases.Count; $caseIndex++) {
        $expected = $cases[$caseIndex]

        Send-Command $serial ([byte][char]"0")
        $metrics = Parse-Metrics (Read-UntilQuiet $serial) $expected

        Assert-Near $metrics.FundamentalHz $expected.F0 `
            ([Math]::Max(20.0, $expected.F0 * 0.0002)) `
            "$($expected.Name) fundamental"
        Assert-Near $metrics.Vpp $expected.Vpp `
            ([Math]::Max(0.0015, $expected.Vpp * 0.08)) `
            "$($expected.Name) Vpp"
        Assert-Near $metrics.Rms $expected.Rms `
            ([Math]::Max(0.0010, $expected.Rms * 0.10)) `
            "$($expected.Name) RMS"

        for ($peakIndex = 0; $peakIndex -lt 3; $peakIndex++) {
            if ($peakIndex -lt $expected.Peaks.Count) {
                $expectedFrequency =
                    [double]$expected.Peaks[$peakIndex].Frequency
                $expectedAmplitude =
                    [double]$expected.Peaks[$peakIndex].Amplitude
                Assert-Near $metrics.PeakFrequenciesHz[$peakIndex] `
                    $expectedFrequency `
                    ([Math]::Max(20.0, $expectedFrequency * 0.0002)) `
                    "$($expected.Name) peak $($peakIndex + 1) frequency"
                Assert-Near $metrics.PeakAmplitudes[$peakIndex] `
                    $expectedAmplitude `
                    ([Math]::Max(0.0007, $expectedAmplitude * 0.03)) `
                    "$($expected.Name) peak $($peakIndex + 1) amplitude"
            }
            else {
                Assert-Near $metrics.PeakFrequenciesHz[$peakIndex] 0.0 0.0 `
                    "$($expected.Name) unused peak frequency"
                Assert-Near $metrics.PeakAmplitudes[$peakIndex] 0.0 0.0 `
                    "$($expected.Name) unused peak amplitude"
            }
        }

        $oneCycle = Read-WaveWithRetry $serial `
            ([byte][char]"1") "addt s2.id,0,$WavePointCount"
        $threeCycle = Read-WaveWithRetry $serial `
            ([byte][char]"3") "addt s2.id,0,$WavePointCount"
        $spectrum = Read-WaveWithRetry $serial `
            ([byte][char]"P") "addt s2.id,0,$WavePointCount"

        $oneMinimum = ($oneCycle | Measure-Object -Minimum).Minimum
        $oneMaximum = ($oneCycle | Measure-Object -Maximum).Maximum
        if (($oneMinimum -lt 0) -or ($oneMaximum -gt 180) -or
            (($oneMaximum - $oneMinimum) -lt 100)) {
            throw "$($expected.Name): invalid one-cycle range $oneMinimum..$oneMaximum"
        }

        $threeMinimum = ($threeCycle | Measure-Object -Minimum).Minimum
        $threeMaximum = ($threeCycle | Measure-Object -Maximum).Maximum
        if (($threeMinimum -lt 0) -or ($threeMaximum -gt 180) -or
            (($threeMaximum - $threeMinimum) -lt 100)) {
            throw "$($expected.Name): invalid three-cycle range $threeMinimum..$threeMaximum"
        }

        $oneWaveMeanError = $null
        $threeWaveMeanError = $null
        if ($expected.PSObject.Properties.Name -contains
            "WaveComponents") {
            $oneWaveMeanError = Assert-HarmonicWaveShape `
                $oneCycle 1 $expected.WaveComponents `
                "$($expected.Name) one-cycle"
            $threeWaveMeanError = Assert-HarmonicWaveShape `
                $threeCycle 3 $expected.WaveComponents `
                "$($expected.Name) three-cycle"
        }

        $spectrumMaximum = ($spectrum | Measure-Object -Maximum).Maximum
        if ($spectrumMaximum -le 0) {
            throw "$($expected.Name): spectrum graph is empty"
        }
        $spectrumTopPoint = [Array]::IndexOf(
            $spectrum, [byte]$spectrumMaximum)
        $spectrumTopHz =
            10000.0 + (($spectrumTopPoint + 0.5) / $WavePointCount) * 590000.0
        $expectedStrongestPeak =
            $expected.Peaks |
            Sort-Object -Property Amplitude -Descending |
            Select-Object -First 1
        if ([Math]::Abs(
                $spectrumTopHz -
                [double]$expectedStrongestPeak.Frequency) -gt 1300.0) {
            throw "$($expected.Name): spectrum top at $spectrumTopHz Hz, " +
                  "strongest component is " +
                  "$($expectedStrongestPeak.Frequency) Hz"
        }

        $detailComponents = $null
        $detailOneCycle = $null
        $detailThreeCycle = $null
        $detailSpectrum = $null
        if ($DetailedCases -contains $expected.Name) {
            if ($expected.PSObject.Properties.Name -contains
                "WaveComponents") {
                $detailComponents = @($expected.WaveComponents)
            }
            $detailOneCycle = @($oneCycle)
            $detailThreeCycle = @($threeCycle)
            $detailSpectrum = @($spectrum)
        }

        $results += [pscustomobject]@{
            case = $caseIndex + 1
            name = $expected.Name
            vpp_v = [Math]::Round($metrics.Vpp, 4)
            rms_v = [Math]::Round($metrics.Rms, 4)
            fundamental_hz = [Math]::Round($metrics.FundamentalHz, 2)
            peak_amplitudes_v = @(
                $metrics.PeakAmplitudes |
                    ForEach-Object { [Math]::Round($_, 4) })
            peak_frequencies_hz = @(
                $metrics.PeakFrequenciesHz |
                    ForEach-Object { [Math]::Round($_, 2) })
            one_cycle_range = @($oneMinimum, $oneMaximum)
            three_cycle_range = @($threeMinimum, $threeMaximum)
            one_cycle_shape_mean_error = $oneWaveMeanError
            three_cycle_shape_mean_error = $threeWaveMeanError
            spectrum_maximum = $spectrumMaximum
            spectrum_top_hz = [Math]::Round($spectrumTopHz, 1)
            expected_wave_components = $detailComponents
            one_cycle_points = $detailOneCycle
            three_cycle_points = $detailThreeCycle
            spectrum_points = $detailSpectrum
        }
    }
}
finally {
    if ($serial.IsOpen) {
        $serial.Close()
    }
    $serial.Dispose()
}

$report = [pscustomobject]@{
    status = "PASS"
    serial = "$Port $BaudRate-8-N-1"
    cases_checked = $results.Count
    checks = @(
        "Vpp",
        "RMS",
        "fundamental frequency",
        "first three peak amplitudes and frequencies",
        "1024-point one-cycle waveform",
        "1024-point three-cycle waveform",
        "phase-aligned harmonic waveform shape",
        "1024-point spectrum waveform"
    )
    results = $results
}
$json = $report | ConvertTo-Json -Depth 9

if ($OutputPath -ne "") {
    $absoluteOutputPath =
        [IO.Path]::GetFullPath(
            (Join-Path (Get-Location) $OutputPath))
    [IO.File]::WriteAllText(
        $absoluteOutputPath,
        $json,
        [Text.UTF8Encoding]::new($false))
}

$json
