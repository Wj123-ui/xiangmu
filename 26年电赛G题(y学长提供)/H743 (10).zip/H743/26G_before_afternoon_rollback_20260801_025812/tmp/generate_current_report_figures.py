import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import lfilter


ROOT = Path(r"C:\Users\yqh\Desktop\H743\26G")
OUT = ROOT / "docs" / "report-assets-current"
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

FS = 6_000_000.0
FFT_SIZE = 16_384
RAW_COUNT = 16_896
WARMUP = 512
FOLD_POINTS = 1_024
CAPTURES = 18
VREF = 3.3
BIAS = 2.080224
GAIN = 8.444958


def fir_coefficients(taps=513, cutoff=650_000.0):
    n = np.arange(taps, dtype=np.float64)
    center = (taps - 1) / 2.0
    phase = 2.0 * np.pi * n / (taps - 1)
    window = (
        0.35875
        - 0.48829 * np.cos(phase)
        + 0.14128 * np.cos(2.0 * phase)
        - 0.01168 * np.cos(3.0 * phase)
    )
    h = 2.0 * cutoff / FS * np.sinc(2.0 * cutoff / FS * (n - center))
    h *= window
    return h / np.sum(h)


H = fir_coefficients()


def response_at(frequency):
    n = np.arange(len(H), dtype=np.float64)
    return abs(np.sum(H * np.exp(-2j * np.pi * frequency * n / FS)))


frequencies = np.linspace(0.0, 1_500_000.0, 6001)
n = np.arange(len(H), dtype=np.float64)
response = np.abs(np.exp(-2j * np.pi * frequencies[:, None] * n[None, :] / FS) @ H)
response_db = 20.0 * np.log10(np.maximum(response, 1.0e-9))

fig, ax = plt.subplots(figsize=(10.8, 5.2), constrained_layout=True)
ax.plot(frequencies / 1000.0, response_db, color="#1479d1", lw=1.4)
ax.axvspan(10, 600, color="#1479d1", alpha=0.08, label="有效测量频带 10–600 kHz")
ax.axvspan(1000, 1500, color="#d73a49", alpha=0.06, label="题设干扰频带 ≥1 MHz")
ax.set_xlim(0, 1500)
ax.set_ylim(-160, 5)
ax.set_xlabel("频率 / kHz")
ax.set_ylabel("幅频响应 / dB")
ax.set_title("6 MSPS、513 tap 线性相位 FIR 幅频响应")
ax.grid(True, alpha=0.25)
ax.legend(loc="lower left")
for f in (600_000.0, 650_000.0, 1_000_000.0, 1_200_000.0):
    value = 20.0 * math.log10(max(response_at(f), 1.0e-12))
    ax.annotate(f"{f/1000:.0f} kHz: {value:.3f} dB",
                xy=(f / 1000.0, max(-158, value)),
                xytext=(8, 12), textcoords="offset points", fontsize=8)
fig.savefig(OUT / "filter-response-6msps.svg")
plt.close(fig)


CASES = [
    ("10.5 kHz + 3、4 次谐波", 10_500.0,
     [(1, 0.050, 0.0), (3, 0.020, 0.65), (4, 0.010, -0.80)]),
    ("83 kHz + 2、4 次谐波", 83_000.0,
     [(1, 0.035, 0.0), (2, 0.028, -0.45), (4, 0.041, 0.90)]),
    ("160 kHz + 2、3 次谐波", 160_000.0,
     [(1, 0.025, 0.0), (2, 0.050, 0.55), (3, 0.020, -1.10)]),
    ("125 kHz + 2、4 次谐波", 125_000.0,
     [(1, 0.050, 0.0), (2, 0.025, -0.30), (4, 0.015, 1.20)]),
]


def expected_cycle(components, cycles=1):
    phase = 2.0 * np.pi * cycles * np.arange(FOLD_POINTS) / (FOLD_POINTS - 1)
    result = np.zeros(FOLD_POINTS)
    for order, amplitude, relative_phase in components:
        result += amplitude * np.sin(order * phase + relative_phase)
    return result


def to_hmi(values):
    lo = float(np.min(values))
    hi = float(np.max(values))
    if hi - lo < 1.0e-12:
        return np.zeros(len(values))
    return np.clip(np.rint(5.0 + (values - lo) * 170.0 / (hi - lo)), 5, 175)


def folded_cycle(f0, components):
    sums = np.zeros(FOLD_POINTS)
    weights = np.zeros(FOLD_POINTS)
    raw_index = np.arange(RAW_COUNT, dtype=np.float64)
    group_delay = (len(H) - 1) // 2

    for capture in range(CAPTURES):
        start_phase = 2.0 * np.pi * ((0.173 * capture + 0.031 * capture * capture) % 1.0)
        vin = np.zeros(RAW_COUNT)
        for order, amplitude, relative_phase in components:
            vin += amplitude * np.sin(
                2.0 * np.pi * order * f0 * raw_index / FS
                + order * start_phase + relative_phase
            )
        adc_voltage = np.clip(BIAS + GAIN * vin, 0.0, VREF)
        code = np.rint(adc_voltage * 4095.0 / VREF)
        recovered = (code * VREF / 4095.0 - BIAS) / GAIN
        filtered = lfilter(H, [1.0], recovered)[WARMUP:WARMUP + FFT_SIZE]

        phase = (start_phase + 2.0 * np.pi * f0 * (WARMUP - group_delay) / FS) / (2.0 * np.pi)
        phase = phase % 1.0
        phase_step = f0 / FS
        phases = (phase + phase_step * np.arange(FFT_SIZE)) % 1.0
        positions = phases * FOLD_POINTS
        first = np.floor(positions).astype(np.int64) % FOLD_POINTS
        second = (first + 1) % FOLD_POINTS
        second_weight = positions - np.floor(positions)
        first_weight = 1.0 - second_weight
        np.add.at(sums, first, filtered * first_weight)
        np.add.at(weights, first, first_weight)
        np.add.at(sums, second, filtered * second_weight)
        np.add.at(weights, second, second_weight)

    folded = sums / np.maximum(weights, 1.0e-12)
    folded -= np.mean(folded)
    return folded


results = []
fig1, axes1 = plt.subplots(2, 2, figsize=(11.2, 6.8), constrained_layout=True)
fig3, axes3 = plt.subplots(2, 1, figsize=(11.2, 6.6), constrained_layout=True)
figs, axess = plt.subplots(2, 2, figsize=(11.2, 6.8), constrained_layout=True)

for idx, (title, f0, components) in enumerate(CASES):
    folded = folded_cycle(f0, components)
    expected = expected_cycle(components, 1)
    expected_hmi = to_hmi(expected)
    folded_hmi = to_hmi(folded)
    mean_error = float(np.mean(np.abs(expected_hmi - folded_hmi)))
    max_error = float(np.max(np.abs(expected_hmi - folded_hmi)))
    results.append({"case": title, "mean_hmi_error": mean_error,
                    "max_hmi_error": max_error})

    ax = axes1.flat[idx]
    x = np.linspace(0.0, 1.0, FOLD_POINTS)
    ax.plot(x, expected_hmi, "--", color="#1479d1", lw=1.1, label="理论输入")
    ax.plot(x, folded_hmi, color="#e45a2a", lw=0.9, label="量化、FIR及18轮折叠")
    ax.set_title(title, fontsize=10)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 180)
    ax.grid(True, alpha=0.22)
    ax.text(0.99, 0.04, f"平均误差 {mean_error:.2f}/180",
            ha="right", va="bottom", transform=ax.transAxes, fontsize=8)
    if idx == 0:
        ax.legend(fontsize=8)

    axs = axess.flat[idx]
    maximum = max(amplitude for _, amplitude, _ in components)
    axs.set_xlim(10, 600)
    axs.set_ylim(0, 1.08)
    for order, amplitude, _ in components:
        frequency_khz = order * f0 / 1000.0
        height = amplitude / maximum
        axs.vlines(frequency_khz, 0, height, color="#168a5b", lw=2.0)
        axs.text(frequency_khz + 4, height, f"{frequency_khz:.1f} kHz\n{amplitude*1000:.0f} mV",
                 fontsize=7, va="top")
    axs.set_title(title, fontsize=10)
    axs.grid(True, alpha=0.22)

    if idx < 2:
        ax3 = axes3[idx]
        x3 = np.linspace(0.0, 3.0, FOLD_POINTS)
        expected3 = to_hmi(expected_cycle(components, 3))
        base = np.arange(FOLD_POINTS) * 3.0 / (FOLD_POINTS - 1)
        wrapped = base % 1.0
        source_x = np.arange(FOLD_POINTS) / FOLD_POINTS
        folded3 = to_hmi(np.interp(wrapped, source_x, folded, period=1.0))
        ax3.plot(x3, expected3, "--", color="#1479d1", lw=1.1, label="理论输入")
        ax3.plot(x3, folded3, color="#e45a2a", lw=0.9, label="18轮折叠后重采样")
        ax3.set_title(title, fontsize=10)
        ax3.set_xlim(0, 3)
        ax3.set_ylim(0, 180)
        ax3.grid(True, alpha=0.22)
        if idx == 0:
            ax3.legend(fontsize=8)

fig1.suptitle("1024 点单周期输入与当前算法输出对比", fontsize=14)
fig1.supxlabel("周期位置")
fig1.supylabel("HMI 波形值")
fig1.savefig(OUT / "waveform-one-cycle-18capture.svg")
plt.close(fig1)

fig3.suptitle("1024 点三周期输入与当前算法输出对比", fontsize=14)
fig3.supxlabel("周期位置")
fig3.supylabel("HMI 波形值")
fig3.savefig(OUT / "waveform-three-cycle-18capture.svg")
plt.close(fig3)

figs.suptitle("当前离散频谱显示：基波与两组确认谐波", fontsize=14)
figs.supxlabel("频率 / kHz")
figs.supylabel("相对峰值幅度")
figs.savefig(OUT / "spectrum-confirmed-components.svg")
plt.close(figs)

(OUT / "figure-verification.json").write_text(
    json.dumps({
        "sample_rate_hz": FS,
        "fft_size": FFT_SIZE,
        "capture_count": CAPTURES,
        "raw_samples_per_capture": RAW_COUNT,
        "warmup_samples": WARMUP,
        "fold_points": FOLD_POINTS,
        "fir_gain": {
            str(int(f)): response_at(f)
            for f in (600_000.0, 650_000.0, 1_000_000.0, 1_200_000.0)
        },
        "waveform_cases": results,
    }, ensure_ascii=False, indent=2),
    encoding="utf-8",
)

print(json.dumps({"status": "PASS", "output": str(OUT),
                  "waveform_cases": results}, ensure_ascii=False))
