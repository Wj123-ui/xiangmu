#include "signal_filter.h"

#include "arm_math.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

/*
 * Two-stage linear-phase low-pass chain:
 *
 *   1. 513-tap FIR at 6.000 MSPS with no sample-rate reduction.
 *      Its 650 kHz midpoint keeps 600 kHz flat while strongly attenuating
 *      >= 1 MHz interference while retaining every ADC sample.
 *
 *   2. The former post-decimation FIR is compiled only when the configured
 *      decimation factor is greater than one.  At 1:1 it is bypassed so it
 *      cannot introduce needless passband loss or computation.
 *
 * Both stages are symmetric FIRs, so their phase delay is linear. Relative
 * harmonic phase, and therefore the reconstructed waveform shape, is
 * preserved. An analog anti-alias filter before PA6 is still mandatory for
 * signals that can alias during the initial 6.000 MSPS ADC acquisition.
 */
#define SIGNAL_FILTER_TWO_PI 6.28318530717958647692f
#define SIGNAL_FILTER_FFT_SIZE 1024U
#define SIGNAL_FILTER_OVERLAP_COUNT (SIGNAL_FILTER_TAP_COUNT - 1U)

static float32_t signal_filter_coefficients[SIGNAL_FILTER_TAP_COUNT];
#if SIGNAL_DECIMATION_FACTOR > 1U
static float32_t signal_post_filter_coefficients[
    SIGNAL_POST_FILTER_TAP_COUNT];
#endif

#if SIGNAL_DECIMATION_FACTOR > 1U
static arm_fir_decimate_instance_f32 signal_filter_instance;
static arm_fir_instance_f32 signal_post_filter_instance;
static float32_t signal_filter_state[
    SIGNAL_FILTER_TAP_COUNT + SIGNAL_FILTER_MAX_BLOCK_SIZE - 1U];
static float32_t signal_post_filter_state[
    SIGNAL_POST_FILTER_TAP_COUNT +
    SIGNAL_FILTER_OUTPUT_BLOCK_SIZE - 1U];
static float32_t signal_filter_decimated_block[
    SIGNAL_FILTER_OUTPUT_BLOCK_SIZE];
#else
static arm_rfft_fast_instance_f32 signal_filter_fft_instance;
static float32_t signal_filter_overlap[SIGNAL_FILTER_OVERLAP_COUNT];
static float32_t signal_filter_fft_time[SIGNAL_FILTER_FFT_SIZE];
static float32_t signal_filter_fft_work[SIGNAL_FILTER_FFT_SIZE];
static float32_t signal_filter_fft_coefficients[SIGNAL_FILTER_FFT_SIZE];
#endif
static bool signal_filter_initialized;

#if SIGNAL_DECIMATION_FACTOR == 1U
static void Signal_Filter_ProcessFullRate(const float32_t *input,
                                          float32_t *output,
                                          uint32_t sample_count)
{
    uint32_t bin;

    memcpy(signal_filter_fft_time,
           signal_filter_overlap,
           sizeof(signal_filter_overlap));
    memcpy(&signal_filter_fft_time[SIGNAL_FILTER_OVERLAP_COUNT],
           input,
           sample_count * sizeof(input[0]));
    memset(&signal_filter_fft_time[
               SIGNAL_FILTER_OVERLAP_COUNT + sample_count],
           0,
           (SIGNAL_FILTER_FFT_SIZE -
            SIGNAL_FILTER_OVERLAP_COUNT - sample_count) *
               sizeof(signal_filter_fft_time[0]));

    /* Preserve the last 512 real input samples before the inverse transform
     * reuses the time buffer. */
    memcpy(signal_filter_overlap,
           &signal_filter_fft_time[sample_count],
           sizeof(signal_filter_overlap));

    arm_rfft_fast_f32(&signal_filter_fft_instance,
                      signal_filter_fft_time,
                      signal_filter_fft_work,
                      0U);

    signal_filter_fft_work[0] *= signal_filter_fft_coefficients[0];
    signal_filter_fft_work[1] *= signal_filter_fft_coefficients[1];
    for (bin = 1U; bin < (SIGNAL_FILTER_FFT_SIZE / 2U); bin++)
    {
        const float32_t input_real = signal_filter_fft_work[2U * bin];
        const float32_t input_imaginary =
            signal_filter_fft_work[2U * bin + 1U];
        const float32_t filter_real =
            signal_filter_fft_coefficients[2U * bin];
        const float32_t filter_imaginary =
            signal_filter_fft_coefficients[2U * bin + 1U];

        signal_filter_fft_work[2U * bin] =
            input_real * filter_real -
            input_imaginary * filter_imaginary;
        signal_filter_fft_work[2U * bin + 1U] =
            input_real * filter_imaginary +
            input_imaginary * filter_real;
    }

    arm_rfft_fast_f32(&signal_filter_fft_instance,
                      signal_filter_fft_work,
                      signal_filter_fft_time,
                      1U);
    memcpy(output,
           &signal_filter_fft_time[SIGNAL_FILTER_OVERLAP_COUNT],
           sample_count * sizeof(output[0]));
}
#endif

static void Signal_Filter_GenerateLowPass(float32_t *coefficients,
                                          uint32_t tap_count,
                                          float cutoff_hz,
                                          float sample_rate_hz)
{
    const uint32_t last_index = tap_count - 1U;
    const uint32_t center_index = last_index / 2U;
    const float normalized_cutoff =
        cutoff_hz / sample_rate_hz;
    float coefficient_sum = 0.0f;
    uint32_t index;

    for (index = 0U; index < tap_count; index++)
    {
        const float offset =
            (float)((int32_t)index - (int32_t)center_index);
        const float phase =
            SIGNAL_FILTER_TWO_PI * (float)index /
            (float)last_index;
        const float window =
            0.35875f -
            (0.48829f * cosf(phase)) +
            (0.14128f * cosf(2.0f * phase)) -
            (0.01168f * cosf(3.0f * phase));
        float ideal_response;

        if (index == center_index)
        {
            ideal_response = 2.0f * normalized_cutoff;
        }
        else
        {
            ideal_response =
                sinf(SIGNAL_FILTER_TWO_PI *
                     normalized_cutoff * offset) /
                ((SIGNAL_FILTER_TWO_PI * 0.5f) * offset);
        }

        coefficients[index] = ideal_response * window;
        coefficient_sum += coefficients[index];
    }

    for (index = 0U; index < tap_count; index++)
    {
        coefficients[index] /= coefficient_sum;
    }
}

bool Signal_Filter_Init(void)
{
    Signal_Filter_GenerateLowPass(signal_filter_coefficients,
                                  SIGNAL_FILTER_TAP_COUNT,
                                  SIGNAL_FILTER_CUTOFF_HZ,
                                  SIGNAL_FILTER_SAMPLE_RATE_HZ);
#if SIGNAL_DECIMATION_FACTOR > 1U
    if (arm_fir_decimate_init_f32(
            &signal_filter_instance,
            SIGNAL_FILTER_TAP_COUNT,
            SIGNAL_DECIMATION_FACTOR,
            signal_filter_coefficients,
            signal_filter_state,
            SIGNAL_FILTER_MAX_BLOCK_SIZE) != ARM_MATH_SUCCESS)
    {
        signal_filter_initialized = false;
        return false;
    }
#else
    _Static_assert(
        SIGNAL_FILTER_MAX_BLOCK_SIZE <=
            (SIGNAL_FILTER_FFT_SIZE - SIGNAL_FILTER_OVERLAP_COUNT),
        "FFT FIR block is too large for overlap-save");
    if (arm_rfft_fast_init_f32(&signal_filter_fft_instance,
                               SIGNAL_FILTER_FFT_SIZE) != ARM_MATH_SUCCESS)
    {
        signal_filter_initialized = false;
        return false;
    }
    memset(signal_filter_fft_time,
           0,
           sizeof(signal_filter_fft_time));
    memcpy(signal_filter_fft_time,
           signal_filter_coefficients,
           sizeof(signal_filter_coefficients));
    arm_rfft_fast_f32(&signal_filter_fft_instance,
                      signal_filter_fft_time,
                      signal_filter_fft_coefficients,
                      0U);
#endif

#if SIGNAL_DECIMATION_FACTOR > 1U
    Signal_Filter_GenerateLowPass(signal_post_filter_coefficients,
                                  SIGNAL_POST_FILTER_TAP_COUNT,
                                  SIGNAL_POST_FILTER_CUTOFF_HZ,
                                  SIGNAL_POST_FILTER_SAMPLE_RATE_HZ);
    arm_fir_init_f32(&signal_post_filter_instance,
                     SIGNAL_POST_FILTER_TAP_COUNT,
                     signal_post_filter_coefficients,
                     signal_post_filter_state,
                     SIGNAL_FILTER_OUTPUT_BLOCK_SIZE);
#endif

    signal_filter_initialized = true;
    return true;
}

void Signal_Filter_Reset(void)
{
#if SIGNAL_DECIMATION_FACTOR > 1U
    memset(signal_filter_state, 0, sizeof(signal_filter_state));
    memset(signal_post_filter_state,
           0,
           sizeof(signal_post_filter_state));
#else
    memset(signal_filter_overlap,
           0,
           sizeof(signal_filter_overlap));
#endif
}

bool Signal_Filter_ProcessDecimate(const float *input,
                                   float *output,
                                   uint32_t input_sample_count)
{
    if ((!signal_filter_initialized) ||
        (input == NULL) ||
        (output == NULL) ||
        (input_sample_count == 0U) ||
        (input_sample_count > SIGNAL_FILTER_MAX_BLOCK_SIZE) ||
        ((input_sample_count % SIGNAL_DECIMATION_FACTOR) != 0U))
    {
        return false;
    }

#if SIGNAL_DECIMATION_FACTOR > 1U
    arm_fir_decimate_f32(&signal_filter_instance,
                         input,
                         signal_filter_decimated_block,
                         input_sample_count);
    arm_fir_f32(&signal_post_filter_instance,
                signal_filter_decimated_block,
                output,
                input_sample_count / SIGNAL_DECIMATION_FACTOR);
#else
    Signal_Filter_ProcessFullRate(input,
                                  output,
                                  input_sample_count);
#endif
    return true;
}

float Signal_Filter_AdcToFloat(const uint16_t *adc_samples,
                               float *output,
                               uint32_t sample_count,
                               float units_per_adc_code)
{
    float mean_code = 0.0f;
    uint32_t index;

    if ((adc_samples == NULL) ||
        (output == NULL) ||
        (sample_count == 0U))
    {
        return 0.0f;
    }

    for (index = 0U; index < sample_count; index++)
    {
        mean_code += (float)adc_samples[index];
    }

    mean_code /= (float)sample_count;

    for (index = 0U; index < sample_count; index++)
    {
        output[index] =
            ((float)adc_samples[index] - mean_code) * units_per_adc_code;
    }

    return mean_code;
}

float Signal_Filter_RemoveDc(float *samples, uint32_t sample_count)
{
    float mean = 0.0f;
    uint32_t index;

    if ((samples == NULL) || (sample_count == 0U))
    {
        return 0.0f;
    }

    for (index = 0U; index < sample_count; index++)
    {
        mean += samples[index];
    }

    mean /= (float)sample_count;

    for (index = 0U; index < sample_count; index++)
    {
        samples[index] -= mean;
    }

    return mean;
}

float Signal_Filter_CalculateRms(const float *samples,
                                 uint32_t sample_count)
{
    float sum_of_squares = 0.0f;
    uint32_t index;

    if ((samples == NULL) || (sample_count == 0U))
    {
        return 0.0f;
    }

    for (index = 0U; index < sample_count; index++)
    {
        sum_of_squares += samples[index] * samples[index];
    }

    return sqrtf(sum_of_squares / (float)sample_count);
}
