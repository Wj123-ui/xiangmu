from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon


OUT = Path(__file__).resolve().parent
FONT_PATH = Path(r"C:\Windows\Fonts\msyh.ttc")
if not FONT_PATH.exists():
    FONT_PATH = Path(r"C:\Windows\Fonts\simhei.ttf")
CN = font_manager.FontProperties(fname=str(FONT_PATH))
plt.rcParams["axes.unicode_minus"] = False


def add_box(ax, x, y, w, h, text, *, face="#F5F9FD", edge="#284B63",
            rounded=True, fontsize=11):
    style = "round,pad=0.018,rounding_size=0.018" if rounded else "square,pad=0.01"
    patch = FancyBboxPatch(
        (x - w / 2, y - h / 2), w, h,
        boxstyle=style, linewidth=1.3, edgecolor=edge, facecolor=face,
    )
    ax.add_patch(patch)
    ax.text(x, y, text, ha="center", va="center", fontsize=fontsize,
            fontproperties=CN, color="#152B3C")
    return patch


def arrow(ax, start, end, *, color="#284B63"):
    ax.add_patch(FancyArrowPatch(
        start, end, arrowstyle="-|>", mutation_scale=13,
        linewidth=1.15, color=color, shrinkA=3, shrinkB=3,
    ))


def overall_flow():
    fig, ax = plt.subplots(figsize=(11.2, 5.2), dpi=180)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    xs = [0.08, 0.23, 0.39, 0.55, 0.71, 0.88]
    labels = [
        "信号源\n10~500 kHz",
        "前级抗混叠滤波\n抑制高频泄漏",
        "偏置与增益\n1.65 V / 约6倍",
        "ADC1/ADC2\n12位交错6 MSPS",
        "89抽头线性相位FIR\n保留全部采样点",
        "16384点FFT\n幅值与相位估计",
    ]
    widths = [0.12, 0.16, 0.15, 0.16, 0.16, 0.14]
    for x, label, width in zip(xs, labels, widths):
        add_box(ax, x, 0.72, width, 0.18, label, fontsize=9.5)
    for left, right in zip(xs[:-1], xs[1:]):
        arrow(ax, (left + 0.07, 0.72), (right - 0.08, 0.72))

    lower = [
        (0.24, "18轮采集\n频谱功率与相干分量累加", 0.24),
        (0.52, "500 Hz网格保护校准\n基波与最多两组谐波确认", 0.24),
        (0.79, "统一重构Vpp与真有效值\n生成1/3周期波形及离散谱", 0.25),
    ]
    for x, label, width in lower:
        add_box(ax, x, 0.35, width, 0.18, label, face="#F3FAF7",
                edge="#2E6F5E", fontsize=9.5)
    arrow(ax, (0.88, 0.62), (0.36, 0.44), color="#2E6F5E")
    arrow(ax, (0.36, 0.35), (0.40, 0.35), color="#2E6F5E")
    arrow(ax, (0.64, 0.35), (0.665, 0.35), color="#2E6F5E")

    add_box(ax, 0.79, 0.10, 0.25, 0.13, "USART2触摸屏显示\n数值、单周期、三周期、频谱",
            face="#FFF8EE", edge="#9A5B13", fontsize=9.5)
    arrow(ax, (0.79, 0.26), (0.79, 0.18), color="#9A5B13")
    add_box(ax, 0.24, 0.10, 0.23, 0.13, "命令9：500 kHz标定\n增益/偏置写入W25Q64",
            face="#FFF8EE", edge="#9A5B13", fontsize=9.5)
    arrow(ax, (0.36, 0.27), (0.28, 0.17), color="#9A5B13")

    ax.set_title("系统信号链与数据处理流程", fontproperties=CN,
                 fontsize=15, weight="bold", pad=8)
    fig.tight_layout(pad=0.5)
    fig.savefig(OUT / "overall_flow.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def coefficients(taps=89, cutoff=800_000.0, fs=6_000_000.0):
    n = np.arange(taps, dtype=float)
    m = (taps - 1) / 2
    window = (
        0.35875 - 0.48829 * np.cos(2 * np.pi * n / (taps - 1))
        + 0.14128 * np.cos(4 * np.pi * n / (taps - 1))
        - 0.01168 * np.cos(6 * np.pi * n / (taps - 1))
    )
    h = 2 * cutoff / fs * np.sinc(2 * cutoff / fs * (n - m)) * window
    return h / h.sum()


def filter_response():
    fs = 6_000_000.0
    h = coefficients()
    f = np.linspace(0, 3_000_000, 30001)
    n = np.arange(h.size)
    mag = np.abs(np.exp(-2j * np.pi * f[:, None] * n / fs) @ h)
    db = 20 * np.log10(np.maximum(mag, 1e-10))

    fig, ax = plt.subplots(figsize=(10.8, 4.9), dpi=180)
    ax.axvspan(10, 500, color="#DCEAF7", alpha=0.75, label="有效信号 10~500 kHz")
    ax.axvspan(1000, 2400, color="#F7E3E3", alpha=0.65,
               label="软件抑制 1~2.4 MHz")
    ax.plot(f / 1000, db, color="#1261A0", lw=1.5, label="89抽头FIR")
    ax.set_xlim(0, 3000)
    ax.set_ylim(-150, 3)
    ax.set_xlabel("频率 / kHz", fontproperties=CN)
    ax.set_ylabel("幅频响应 / dB", fontproperties=CN)
    ax.grid(True, alpha=0.28)
    ax.set_title("单级89抽头线性相位FIR幅频响应", fontproperties=CN,
                 fontsize=14, weight="bold")
    ax.legend(prop=CN, loc="lower left", frameon=False, ncol=3)
    ax.annotate("500 kHz带内误差 < 0.00003 dB", xy=(500, -0.00003),
                xytext=(650, -23), arrowprops=dict(arrowstyle="->", color="#333"),
                fontproperties=CN, fontsize=9)
    ax.annotate("1 MHz：200 mVpp干扰残留约0.363 mVpp", xy=(1000, -54.82),
                xytext=(1250, -42), arrowprops=dict(arrowstyle="->", color="#333"),
                fontproperties=CN, fontsize=9)
    fig.tight_layout()
    fig.savefig(OUT / "filter_response.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def program_flow():
    fig, ax = plt.subplots(figsize=(8.6, 7.0), dpi=180)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    center = 0.48
    ys = [0.92, 0.79, 0.65, 0.51, 0.37, 0.23, 0.09]
    labels = [
        "等待USART2命令",
        "命令0：启动测量\n清零18轮累加器",
        "DMA采集16512点\n去128点FIR预热，保留16384点",
        "89抽头FIR + 16384点FFT\n估计频率、峰值与相位",
        "累计频谱和相干分量\n未满18轮则继续采集",
        "18轮平均、谐波确认\n500 Hz网格保护校准",
        "重构Vpp/RMS与波形\n锁存结果并发送HMI",
    ]
    widths = [0.30, 0.36, 0.45, 0.45, 0.44, 0.42, 0.42]
    for y, label, width in zip(ys, labels, widths):
        add_box(ax, center, y, width, 0.09, label, fontsize=9.6)
    for y1, y2 in zip(ys[:-1], ys[1:]):
        arrow(ax, (center, y1 - 0.05), (center, y2 + 0.05))

    add_box(ax, 0.82, 0.79, 0.27, 0.10, "命令9：标定增益/偏置\nCRC校验写入W25Q64",
            face="#FFF8EE", edge="#9A5B13", fontsize=9.2)
    arrow(ax, (0.64, 0.88), (0.76, 0.83), color="#9A5B13")
    arrow(ax, (0.82, 0.73), (0.70, 0.65), color="#9A5B13")

    ax.set_title("主程序测量与标定流程", fontproperties=CN,
                 fontsize=15, weight="bold", pad=8)
    fig.tight_layout(pad=0.5)
    fig.savefig(OUT / "program_flow.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def simulation_figure():
    fs = 6_000_000.0
    n = np.arange(36_000)
    t = n / fs
    wanted = (
        0.050 * np.sin(2 * np.pi * 100_000 * t + 0.2)
        + 0.020 * np.sin(2 * np.pi * 200_000 * t + 0.05)
        + 0.010 * np.sin(2 * np.pi * 300_000 * t + 1.15)
    )
    raw = wanted + 0.100 * np.sin(2 * np.pi * 1_200_000 * t - 0.7)
    gain, bias, vref = 6.0, 1.65, 3.3
    codes = np.clip(np.rint((bias + gain * raw) / vref * 4095), 0, 4095)
    adc_input = (codes / 4095 * vref - bias) / gain
    h = coefficients()
    filtered = np.convolve(adc_input, h, mode="full")[:adc_input.size]
    delay = (h.size - 1) // 2

    start = 12_000
    count = 120
    tx = np.arange(count) / fs * 1e6
    raw_seg = adc_input[start:start + count]
    filtered_seg = filtered[start + delay:start + delay + count]
    wanted_seg = wanted[start:start + count]

    fig, axes = plt.subplots(2, 1, figsize=(10.8, 6.7), dpi=180,
                             gridspec_kw={"height_ratios": [1.35, 1.0]})
    axes[0].plot(tx, raw_seg * 1000, color="#9AA4AE", lw=0.9,
                 label="12位ADC输入（含1.2 MHz、200 mVpp干扰）")
    axes[0].plot(tx, wanted_seg * 1000, "--", color="#1261A0", lw=1.4,
                 label="理论有效信号")
    axes[0].plot(tx, filtered_seg * 1000, color="#D1495B", lw=1.1,
                 label="89抽头FIR输出")
    axes[0].set_xlabel("时间 / μs", fontproperties=CN)
    axes[0].set_ylabel("输入电压 / mV", fontproperties=CN)
    axes[0].grid(True, alpha=0.25)
    axes[0].legend(prop=CN, frameon=False, ncol=3, fontsize=8)
    axes[0].set_title("干扰抑制后的有效波形恢复", fontproperties=CN,
                      fontsize=12, weight="bold")

    frequencies = np.array([100, 200, 300])
    expected = np.array([50.0, 20.0, 10.0])
    measured = np.array([49.73793, 19.71972, 10.10762])
    width = 12
    axes[1].bar(frequencies - width / 2, expected, width=width,
                color="#8CC2E5", label="理论峰值")
    axes[1].bar(frequencies + width / 2, measured, width=width,
                color="#2E6F5E", label="MCU同路径仿真测得")
    for x, y in zip(frequencies + width / 2, measured):
        axes[1].text(x, y + 1.0, f"{y:.3f}", ha="center", va="bottom", fontsize=8)
    axes[1].set_xlim(50, 350)
    axes[1].set_ylim(0, 58)
    axes[1].set_xlabel("频率 / kHz", fontproperties=CN)
    axes[1].set_ylabel("峰值幅度 / mV", fontproperties=CN)
    axes[1].grid(True, axis="y", alpha=0.25)
    axes[1].legend(prop=CN, frameon=False)
    axes[1].set_title("100/200/300 kHz分量识别结果", fontproperties=CN,
                      fontsize=12, weight="bold")
    fig.tight_layout()
    fig.savefig(OUT / "simulation_validation.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    overall_flow()
    filter_response()
    program_flow()
    simulation_figure()
    print("generated", *(p.name for p in sorted(OUT.glob("*.png"))))
