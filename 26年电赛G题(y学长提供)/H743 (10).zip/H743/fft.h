#ifndef FFT_H
#define FFT_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#include "arm_math.h"
#include "lpf.h"

#ifndef FFT_MAX_SIZE
#define FFT_MAX_SIZE          4096U
#endif

#ifndef FFT_MAX_WAVE_POINTS
#define FFT_MAX_WAVE_POINTS   800U
#endif

#ifndef FFT_MAX_SPECTRUM_POINTS
#define FFT_MAX_SPECTRUM_POINTS   800U
#endif

#ifndef FFT_MAX_PEAKS
#define FFT_MAX_PEAKS             8U
#endif

#define FFT_MAX_BINS  ((FFT_MAX_SIZE / 2U) + 1U)

typedef enum
{
  FFT_OK = 0,
  FFT_BAD_ARGUMENT,
  FFT_BAD_CONFIG,
  FFT_INIT_FAILED,
  FFT_FILTER_FAILED,
  FFT_NO_SIGNAL,
  FFT_CAPTURE_TOO_SHORT
} FFT_Status;

typedef struct
{
  float32_t sample_rate_hz;
  uint16_t fft_size;

  /*
   * ADC conversion:
   * input_voltage = (adc_code - adc_zero_code) * adc_volts_per_count
   * adc_volts_per_count should already include analog front-end gain.
   */
  float32_t adc_zero_code;
  float32_t adc_volts_per_count;
  uint8_t remove_dc;

  uint8_t lowpass_enabled;
  uint8_t lowpass_order;
  uint8_t correct_lowpass_gain;
  float32_t lowpass_cutoff_hz;

  float32_t analysis_min_frequency_hz;
  float32_t analysis_max_frequency_hz;
  float32_t minimum_peak_amplitude_v;
  float32_t relative_peak_threshold;
  uint8_t maximum_peak_count;
  uint8_t peak_separation_bins;

  uint16_t waveform_display_points;
  uint16_t spectrum_display_points;
} FFT_Config;

typedef struct
{
  uint16_t bin_index;
  float32_t bin_offset;
  float32_t frequency_hz;
  float32_t amplitude_v;
  float32_t phase_rad;
} FFT_Peak;

/*
 * Result arrays are embedded so the module never allocates memory.
 * Allocate this structure statically or globally, not on a small task stack.
 *
 * spectrum_amplitude_v is a one-sided peak-amplitude spectrum. It is not RMS.
 */
typedef struct
{
  FFT_Status status;
  uint16_t fft_size;
  uint16_t spectrum_bin_count;
  uint16_t waveform_display_count;
  uint16_t spectrum_display_count;
  uint8_t peak_count;

  float32_t sample_period_s;
  float32_t spectrum_bin_width_hz;
  float32_t dc_offset_v;
  float32_t peak_to_peak_v;
  float32_t true_rms_v;
  float32_t fundamental_hz;
  float32_t samples_per_period;
  float32_t one_cycle_duration_s;
  float32_t three_cycle_duration_s;

  FFT_Peak peaks[FFT_MAX_PEAKS];

  /* Full filtered capture used for measurements and arbitrary waveform views. */
  float32_t waveform_v[FFT_MAX_SIZE];

  /* Stable, phase-aligned screen arrays spanning exactly 1 or 3 periods. */
  float32_t one_cycle_v[FFT_MAX_WAVE_POINTS];
  float32_t three_cycle_v[FFT_MAX_WAVE_POINTS];

  /* Full positive-frequency-axis spectrum, including DC and Nyquist. */
  float32_t spectrum_frequency_hz[FFT_MAX_BINS];
  float32_t spectrum_amplitude_v[FFT_MAX_BINS];

  /*
   * Max-pooled display spectrum. Narrow spectral lines are retained when the
   * number of FFT bins is larger than the horizontal screen resolution.
   */
  float32_t spectrum_display_frequency_hz
      [FFT_MAX_SPECTRUM_POINTS];
  float32_t spectrum_display_amplitude_v
      [FFT_MAX_SPECTRUM_POINTS];
} FFT_Result;

/*
 * Internal workspace. Like FFT_Result, this should normally be a
 * static/global object. The initialized object must not be copied.
 */
typedef struct
{
  FFT_Config config;
  LPF_Handle lowpass;
  arm_rfft_fast_instance_f32 rfft;
  float32_t input_work[FFT_MAX_SIZE];
  float32_t fft_output[FFT_MAX_SIZE];
  uint8_t initialized;
} FFT_Handle;

/*
 * Returns a ready-to-edit configuration for the contest's 0-500 kHz mode.
 * At 2.048 MSPS and 4096 points the FFT bin width is exactly 500 Hz.
 */
FFT_Config FFT_DefaultConfig(float32_t sample_rate_hz);

FFT_Status FFT_Init(FFT_Handle *fft, const FFT_Config *config);

void FFT_ResetFilter(FFT_Handle *fft);

/*
 * Processes ADC codes. sample_count must be at least config.fft_size.
 * Only the first fft_size samples are consumed.
 */
FFT_Status FFT_ProcessADC(
    FFT_Handle *fft,
    const uint16_t *adc_samples,
    uint32_t sample_count,
    FFT_Result *result);

/*
 * Processes input-referred volt samples. DC bias may be present when
 * config.remove_dc is nonzero.
 */
FFT_Status FFT_Process(
    FFT_Handle *fft,
    const float32_t *input_volts,
    uint32_t sample_count,
    FFT_Result *result);

#ifdef __cplusplus
}
#endif

#endif
