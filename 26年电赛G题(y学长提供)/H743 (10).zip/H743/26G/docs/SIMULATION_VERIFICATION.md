# H743 仿真验证说明

## 已完成

已完成两层离线验证；另已在 H743 实板上完成真实 ADC/DMA/USART2 输入验证。

1. `build\Simulation` 使用 `APP_ADC_SIMULATION_MODE=ON` 编译通过。该固件保留完整 H743 主程序、FIR、FFT、九次采集、实测分量表、Vpp/RMS、谐波和三种波形输出逻辑，只把 ADC DMA 输入替换为确定性样本。
2. `tools\verify_port.py` 用独立 Python/NumPy/SciPy 模型验证 ADC 量化、双 ADC 32-bit 打包顺序、两级 FIR、4 倍抽取、FFT 频率轴和 21 组源波形。

运行离线验证：

```powershell
py -3 tools\verify_port.py
py -3 tools\verify_logic_parity.py
py -3 tools\verify_f407_readonly.py
```

当前结果：

- 双重交错采样率：7.200000000 MSPS。
- 分析采样率：1.800000000 MSPS。
- 21 组源波形全部通过。
- 最大基波频率误差：0.4667 FFT bin。
- 最大基波幅值误差：约 0.514%。

## 固件构建状态

- 安全等待版：`build\SafeExternal\26G.hex`
- 真实双 ADC 版：`build\Actual\26G.hex`（已烧录实测）
- ADC 输入仿真版：`build\Simulation\26G.hex`

本轮已烧录 Simulation 固件、复位目标并通过 USART2/COM14 收集 20 个自动回归结果帧；随后已重新烧录 Actual 实采固件。`tools\verify_mcu_simulation.ps1` 仍可用于以后重复该板上回归。

## 板上仿真与真实输入的区别

板上 Simulation 固件可以验证：

- Cortex-M7 上实际执行的 CMSIS-DSP 代码。
- 九次采集状态机。
- Vpp、RMS、基波和两组谐波输出。
- 单周期、三周期、频谱三个 1024 点输出。
- USART2/HMI 帧格式和处理时间。

它不能验证：

- VREF+/VDDA 噪声。
- PA6 模拟前端增益、偏置、建立时间和抗混叠。
- ADC1/ADC2 的增益、偏置、时序失配。
- 真实 DMA 采样率、ENOB、SNR、THD。

这些项目必须在真实版启用后用信号源、示波器/逻辑分析和板上 DWT 计数完成。
