#include "lpf.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

#define LPF_PI_F  3.14159265358979323846f

LPF_Status LPF_Init(LPF_Handle *filter,
                                 float32_t sample_rate_hz,
                                 float32_t cutoff_hz,
                                 uint8_t order)
{
  uint32_t stage;
  uint32_t stage_count;
  float32_t omega;
  float32_t sine;
  float32_t cosine;

  if (filter == NULL)
  {
    return LPF_BAD_ARGUMENT;
  }

  if ((!isfinite(sample_rate_hz)) || (!isfinite(cutoff_hz)) ||
      (sample_rate_hz <= 0.0f) || (cutoff_hz <= 0.0f) ||
      (cutoff_hz >= (0.5f * sample_rate_hz)))
  {
    return LPF_BAD_FREQUENCY;
  }

  if ((order < 2U) || (order > LPF_MAX_ORDER) ||
      ((order & 1U) != 0U))
  {
    return LPF_BAD_ORDER;
  }

  memset(filter, 0, sizeof(*filter));
  stage_count = (uint32_t)order / 2U;
  omega = 2.0f * LPF_PI_F * cutoff_hz / sample_rate_hz;
  sine = sinf(omega);
  cosine = cosf(omega);

  /*
   * A Butterworth response is formed by cascading second-order sections.
   * Sections are ordered from low Q to high Q to reduce internal peaking.
   *
   * CMSIS-DSP uses:
   * y[n] = b0*x[n] + d1
   * d1   = b1*x[n] + a1*y[n] + d2
   * d2   = b2*x[n] + a2*y[n]
   *
   * Therefore the conventional denominator coefficients are negated when
   * stored in the CMSIS coefficient array.
   */
  for (stage = 0U; stage < stage_count; ++stage)
  {
    uint32_t pole_index = stage_count - 1U - stage;
    float32_t angle =
        ((2.0f * (float32_t)pole_index) + 1.0f) * LPF_PI_F /
        (2.0f * (float32_t)order);
    float32_t q = 1.0f / (2.0f * sinf(angle));
    float32_t alpha = sine / (2.0f * q);
    float32_t a0 = 1.0f + alpha;
    float32_t *c = &filter->coefficients[5U * stage];

    c[0] = (1.0f - cosine) / (2.0f * a0);
    c[1] = (1.0f - cosine) / a0;
    c[2] = c[0];
    c[3] = (2.0f * cosine) / a0;
    c[4] = -(1.0f - alpha) / a0;
  }

  filter->sample_rate_hz = sample_rate_hz;
  filter->cutoff_hz = cutoff_hz;
  filter->order = order;
  filter->stage_count = (uint8_t)stage_count;
  filter->initialized = 1U;

  arm_biquad_cascade_df2T_init_f32(&filter->cmsis,
                                   filter->stage_count,
                                   filter->coefficients,
                                   filter->states);
  return LPF_OK;
}

void LPF_Reset(LPF_Handle *filter)
{
  if ((filter == NULL) || (filter->initialized == 0U))
  {
    return;
  }

  memset(filter->states, 0,
         sizeof(float32_t) * 2U * (uint32_t)filter->stage_count);
}

LPF_Status LPF_Process(LPF_Handle *filter,
                                    const float32_t *input,
                                    float32_t *output,
                                    uint32_t sample_count)
{
  if ((filter == NULL) || (input == NULL) || (output == NULL) ||
      (sample_count == 0U) || (filter->initialized == 0U))
  {
    return LPF_BAD_ARGUMENT;
  }

  arm_biquad_cascade_df2T_f32(&filter->cmsis,
                              input,
                              output,
                              sample_count);
  return LPF_OK;
}

float32_t LPF_GetGain(const LPF_Handle *filter,
                                float32_t frequency_hz)
{
  uint32_t stage;
  float32_t omega;
  float32_t z1_real;
  float32_t z1_imag;
  float32_t z2_real;
  float32_t z2_imag;
  float32_t gain = 1.0f;

  if ((filter == NULL) || (filter->initialized == 0U) ||
      (!isfinite(frequency_hz)) || (frequency_hz < 0.0f) ||
      (frequency_hz > (0.5f * filter->sample_rate_hz)))
  {
    return 0.0f;
  }

  omega = 2.0f * LPF_PI_F * frequency_hz / filter->sample_rate_hz;
  z1_real = cosf(omega);
  z1_imag = -sinf(omega);
  z2_real = cosf(2.0f * omega);
  z2_imag = -sinf(2.0f * omega);

  for (stage = 0U; stage < (uint32_t)filter->stage_count; ++stage)
  {
    const float32_t *c = &filter->coefficients[5U * stage];
    float32_t numerator_real =
        c[0] + (c[1] * z1_real) + (c[2] * z2_real);
    float32_t numerator_imag =
        (c[1] * z1_imag) + (c[2] * z2_imag);
    float32_t denominator_real =
        1.0f - (c[3] * z1_real) - (c[4] * z2_real);
    float32_t denominator_imag =
        -(c[3] * z1_imag) - (c[4] * z2_imag);
    float32_t numerator_power =
        (numerator_real * numerator_real) +
        (numerator_imag * numerator_imag);
    float32_t denominator_power =
        (denominator_real * denominator_real) +
        (denominator_imag * denominator_imag);

    if (denominator_power <= 0.0f)
    {
      return 0.0f;
    }

    gain *= sqrtf(numerator_power / denominator_power);
  }

  return gain;
}
